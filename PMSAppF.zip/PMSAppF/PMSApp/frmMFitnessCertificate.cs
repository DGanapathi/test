﻿using Spire.Doc;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmMFitnessCertificate : Form
    {
        List<string> lsgMFCImgs = null;
        int selectedImg = 0;
        string UncPath = Directory.GetParent(System.Configuration.ConfigurationManager.AppSettings["FilesPath"]).ToString() + Path.DirectorySeparatorChar + "PatientFitnessCerts";
        //word document object
        Document document = null;

        public frmMFitnessCertificate()
        {
            InitializeComponent();
        }

        private void frmMFitnessCertificate_Load(object sender, EventArgs e)
        {
            string ImgDir = Application.StartupPath + Path.DirectorySeparatorChar + "Images";
            if (Directory.Exists(ImgDir) && (Directory.GetFiles(ImgDir, "*.png", SearchOption.AllDirectories).Count() > 0 || Directory.GetFiles(ImgDir, "*.jpg", SearchOption.AllDirectories).Count() > 0 || Directory.GetFiles(ImgDir, "*.jpeg", SearchOption.AllDirectories).Count() > 0))
            {
                lsgMFCImgs = Directory.GetFiles(ImgDir, "*.*", SearchOption.TopDirectoryOnly).Where(file => Path.GetFileName(file).StartsWith("MFC") && new string[] { ".png", ".jpg", ".jpeg", ".gif" }.Contains(Path.GetExtension(file))).ToList();
            }
            txtPName.Text = !string.IsNullOrEmpty(frmHome.patientNameForMail) ? frmHome.patientNameForMail.ToUpper() : string.Empty;
            cmbBloodGrp.SelectedIndex = 0;
            cmbColor.SelectedIndex = 0;
            cmbGender.SelectedIndex = 0;
            timer1.Start();
            //txtPlace.SelectionLength = 0;
            txtPName.Focus();
            txtPName.Select();
        }

        private void showImage()
        {
            if (lsgMFCImgs == null || lsgMFCImgs.Count < 1)
                return;
            if (selectedImg >= lsgMFCImgs.Count)
                selectedImg = 0;
            pictureBox1.Image = Image.FromFile(lsgMFCImgs[selectedImg]);
            selectedImg += 1;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                showImage();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("MFC - timer1_Tick()-->" + ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearControls()
        {
            txtPName.Text = "";
            txtSDWOf.Text = "";
            txtSight.Text = "";
            txtStmtYrs.Text = "";
            txtWeight.Text = "";
            txtPlace.Text = "Hyderabad";
            txtLiverSpleen.Text = "";
            txtIdentMark2.Text = "";
            txtIdentMark1.Text = "";
            txtHeight.Text = "";
            txtHeartLungs.Text = "";
            txtChestExpire.Text = "";
            txtChestInspire.Text = "";
            txtAprYrs.Text = "";
            txtAge.Text = "";
            cmbBloodGrp.SelectedIndex = 0;
            cmbColor.SelectedIndex = 0;
            cmbGender.SelectedIndex = 0;
        }

        private void btnClear2_Click(object sender, EventArgs e)
        {
            clearControls();
        }
        Dictionary<string, string> GetReplaceDictionary()
        {
            try
            {
                string place = txtPlace.Text.Trim();
                string strDate = dtpIssueDt.Text.Trim();

                string pname = txtPName.Text.Trim();
                string SDWOf = txtSDWOf.Text.Trim();
                string age = txtAge.Text.Trim() + "Yrs";
                string gender = cmbGender.Text.Trim();
                string stmtYrs = txtStmtYrs.Text.Trim();
                string AprYrs = txtAprYrs.Text.Trim();

                string IndentMark1 = txtIdentMark1.Text.Trim();
                string IndentMark2 = txtIdentMark2.Text.Trim();

                string ht = txtHeight.Text.Trim() + "Cms";
                string wt = txtWeight.Text.Trim() + "Kgs";
                string chestExpire = txtChestExpire.Text.Trim() + "Cms";
                string chestInspire = txtChestInspire.Text.Trim() + "Cms";

                string LiverSpleen =txtLiverSpleen.Text.Trim();
                string heratLungs = txtHeartLungs.Text.Trim();
                string sight = txtSight.Text.Trim();
                string strColor = cmbColor.Text.Trim();
                string bloodGrp = cmbBloodGrp.Text.Trim();

                if (pname.Length < 16)
                    pname = pname.PadRight(16 - pname.Length);
                if (LiverSpleen.Length == 1)
                    LiverSpleen = char.ToUpper(LiverSpleen[0]).ToString();
                else if (LiverSpleen.Length > 1)
                    LiverSpleen = char.ToUpper(LiverSpleen[0]) + LiverSpleen.Substring(1);

                if (heratLungs.Length == 1)
                    heratLungs = char.ToUpper(heratLungs[0]).ToString();
                else if (heratLungs.Length > 1)
                    heratLungs = char.ToUpper(heratLungs[0]) + heratLungs.Substring(1);

                if (sight.Length == 1)
                    sight = char.ToUpper(sight[0]).ToString();
                else if (sight.Length > 1)
                    sight = char.ToUpper(sight[0]) + sight.Substring(1);

                Dictionary<string, string> replaceDict = new Dictionary<string, string>();

                replaceDict.Add("#place#", place);
                replaceDict.Add("#date#", strDate);
                replaceDict.Add("#pname#", pname);
                replaceDict.Add("#sdwOf#", SDWOf);
                replaceDict.Add("#age#", age);
                replaceDict.Add("#gender#", gender);

                replaceDict.Add("#stmtYrs#", stmtYrs);
                replaceDict.Add("#apprYrs#", AprYrs);

                replaceDict.Add("#IdentMark1#", IndentMark1);
                replaceDict.Add("#IdentMark2#", IndentMark2);

                replaceDict.Add("#ht#", ht);
                replaceDict.Add("#wt#", wt);
                replaceDict.Add("#chestInspire#", chestInspire);
                replaceDict.Add("#chestExpire#", chestExpire);

                replaceDict.Add("#liverSpleen#", LiverSpleen);
                replaceDict.Add("#heartLungs#", heratLungs);
                replaceDict.Add("#sight#", sight);

                replaceDict.Add("#recgColor#", strColor);
                replaceDict.Add("#bloodGrp#", bloodGrp);

                return replaceDict;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("frmMCert_GetReplaceDictionary()-->" + ex.Message);
                return null;
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {

            try
            {
                string pname = txtPName.Text.Trim();
                string strSex = cmbGender.Text.Trim();
                string bloodGrp = cmbBloodGrp.Text.Trim();

                if (string.IsNullOrEmpty(pname))
                {
                    MessageBox.Show("Please enter patient name.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (strSex == "- Select -")
                {
                    MessageBox.Show("Please select gender.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (bloodGrp.Contains("Select"))
                {
                    MessageBox.Show("Please select blood group.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                //initialize word object
                document = new Document();
                //close if the template is already opened
                if (GloabalFunctions.closeOpenedWord(GloabalFunctions.MFCTemplatePath))
                    System.Threading.Thread.Sleep(100);
                document.LoadFromFile(GloabalFunctions.MFCTemplatePath);
                //get strings to replace
                Dictionary<string, string> dictReplace = GetReplaceDictionary();
                //Replace text
                foreach (KeyValuePair<string, string> kvp in dictReplace)
                {
                    document.Replace(kvp.Key, kvp.Value, true, true);
                }
                //Save doc file.
                if (!Directory.Exists(UncPath))
                    Directory.CreateDirectory(UncPath);

                string docxPath = UncPath + "\\" + pname + "_" + dtpIssueDt.Value.ToString("ddMMyyyy") + ".docx";
                string printFilePath = docxPath;
                if (File.Exists(docxPath))
                {
                    MessageBox.Show("Physical fitness certificate already exists with name: \r\n" + docxPath, "GPApps :: PMS", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    return;
                }

                ////save to docx
                document.SaveToFile(docxPath, FileFormat.Docx);

                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    string pdfPath = docxPath.Replace(".docx", ".pdf");
                //    //Convert to PDF
                //    document.SaveToFile(pdfPath, FileFormat.PDF);
                //    printFilePath = pdfPath;
                //}

                document.Close();

                if (MessageBox.Show("Physical fitness certificate saved successfully. \r\n Do you want to give print?.", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    GloabalFunctions.printFile(printFilePath);

                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    EmailNotification.eMailNotification(strPName, strEmail, pdfPath);
                //    //System.Threading.Thread.Sleep(100);
                //}

                clearControls();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("MFC-Print_Click()-->" + ex.Message);
            }
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void txtLiverSpleen_TextChanged(object sender, EventArgs e)
        {
            string txt = txtLiverSpleen.Text;
            txt = CapitalizeFirstChar(txt);
            txtLiverSpleen.Text = txt;
            txtLiverSpleen.Select(txtLiverSpleen.Text.Length, 0);
        }

        private string CapitalizeFirstChar(string txt)
        {
            if (txt.Length == 1)
                txt = char.ToUpper(txt[0]).ToString();
            else if (txt.Length > 1)
                txt = char.ToUpper(txt[0]) + txt.Substring(1);
            return txt;
        }

        private void txtHeartLungs_TextChanged(object sender, EventArgs e)
        {
            string txt = txtHeartLungs.Text;
            txt = CapitalizeFirstChar(txt);
            txtHeartLungs.Text = txt;
            txtHeartLungs.Select(txtHeartLungs.Text.Length, 0);
        }

        private void txtSight_TextChanged(object sender, EventArgs e)
        {
            string txt = txtSight.Text;
            txt = CapitalizeFirstChar(txt);
            txtSight.Text = txt;
            txtSight.Select(txtSight.Text.Length, 0);
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                GloabalFunctions.BrowseFileToPrint(UncPath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("PFC-Browse_Click()-->" + ex.Message);
            }
        }
    }
}
