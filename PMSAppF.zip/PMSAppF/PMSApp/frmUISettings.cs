﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmUISettings : Form
    {
        public frmUISettings()
        {
            InitializeComponent();
        }
        private void frmUISettings_Load(object sender, EventArgs e)
        {
            FillColors();
            UISettings();
        }
        private void UISettings()
        {
            txtClinicName.Text = Properties.Settings.Default.ClinicName;
            pbClinic.BackColor = Color.FromName(Properties.Settings.Default.ClinicNameColor);
            pbBackground.BackColor = Color.FromName(Properties.Settings.Default.BackgroundColor);

            cmbFontSize.Text = Properties.Settings.Default.ClinicNameFontSize.ToString();

            cmbboxClr.Text = Properties.Settings.Default.ClinicNameColor;
            lblCColor.Text = Properties.Settings.Default.ClinicNameColor;

            cmbboxClr1.Text = Properties.Settings.Default.BackgroundColor;
            lblBColor.Text = Properties.Settings.Default.BackgroundColor;

            cmbColorInterval.Text = Properties.Settings.Default.ColorInterval.ToString();
        }
        private void pbClinic_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                pbClinic.BackColor = colorDialog1.Color;
                lblCColor.Text = pbClinic.BackColor.Name;
            }
        }

        private void pbBackground_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                pbBackground.BackColor = colorDialog1.Color;
                lblBColor.Text = pbBackground.BackColor.Name;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure, you want to reset?.", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                Properties.Settings.Default.ClinicName = "Sri Sai Kalpana Clinic";
                Properties.Settings.Default.ClinicNameColor = "Red";
                Properties.Settings.Default.BackgroundColor = "LightSteelBlue";
                Properties.Settings.Default.ClinicNameFontSize = 45;
                Properties.Settings.Default.ColorInterval = 1;
                Properties.Settings.Default.Save();

                UISettings();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Properties.Settings.Default.ClinicName = txtClinicName.Text.Trim();
                Properties.Settings.Default.ClinicNameColor = pbClinic.BackColor.Name;
                Properties.Settings.Default.BackgroundColor = pbBackground.BackColor.Name;
                Properties.Settings.Default.ClinicNameFontSize = Convert.ToInt32(cmbFontSize.Text);
                Properties.Settings.Default.ColorInterval = Convert.ToInt32(cmbColorInterval.Text);

                Properties.Settings.Default.Save();

                System.Threading.Thread.Sleep(500);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       private void FillColors()
        {
            //var webColors = Enum.GetValues(typeof(KnownColor))
            //        .Cast<KnownColor>()
            //        .Where(k => k >= KnownColor.Transparent && k < KnownColor.ButtonFace) //Exclude system colors
            //        .Select(k => Color.FromKnownColor(k))
            //        .OrderBy(c => c.GetHue()); //141

            var colors = Enum.GetValues(typeof(KnownColor))
             .Cast<KnownColor>()
             .Select(kc => Color.FromKnownColor(kc))
             .OrderBy(cr => cr.Name); //174

            //var colors2 = Enum.GetValues(typeof(KnownColor))
            // .Cast<KnownColor>()
            // .Select(kc => Color.FromKnownColor(kc).Name)
            // .OrderBy(cr => cr); //174
            //var ss = string.Join(",\r\n", colors2);

            //Type colorType = typeof(System.Drawing.Color);
            //PropertyInfo[] propInfoList = colorType.GetProperties(BindingFlags.Static |
            //                              BindingFlags.DeclaredOnly | BindingFlags.Public);

            foreach (var c in colors)
            {
                if (c.Name == "Transparent")
                    continue;
                this.cmbboxClr.Items.Add(c.Name);
                this.cmbboxClr1.Items.Add(c.Name);

                
            }

        }

        private void cmbboxClr_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle rect = e.Bounds;
            if (e.Index >= 0)
            {
                string n = ((ComboBox)sender).Items[e.Index].ToString();
                Font f = new Font("Arial", 9, FontStyle.Regular);
                Color c = Color.FromName(n);
                Brush b = new SolidBrush(c);
                g.DrawString(n, f, Brushes.Black, rect.X, rect.Top);
                g.FillRectangle(b, rect.X + 110, rect.Y + 5,
                                rect.Width - 10, rect.Height - 10);
            }
        }

        private void cmbboxClr_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(cmbboxClr.Text))
            {
                pbClinic.BackColor = Color.FromName(cmbboxClr.Text);
                lblCColor.Text = cmbboxClr.Text;
            }
        }

        private void cmbboxClr1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbboxClr1.Text))
            {
                pbBackground.BackColor = Color.FromName(cmbboxClr1.Text);
                lblBColor.Text = cmbboxClr1.Text;
            }
        }
    }
}
