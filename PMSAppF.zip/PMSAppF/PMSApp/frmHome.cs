﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Spire.Doc;
using System.Diagnostics;
using System.Data.OleDb;
using Spire.Doc.Documents;
using System.Text.RegularExpressions;
using System.Configuration;

namespace PMSApp
{
    public partial class frmHome : Form
    {
        string UncPath = System.Configuration.ConfigurationManager.AppSettings["FilesPath"].ToString();
        string bullet = System.Configuration.ConfigurationManager.AppSettings["BulletSymbol"].ToString();
        string emailNotification = System.Configuration.ConfigurationManager.AppSettings["SendEmailNotification"].ToString();
        string strToDay = "";
        
        //word document object
        Document document = null;

        AutoCompleteStringCollection emailCollection = new AutoCompleteStringCollection();
        AutoCompleteStringCollection newEmailCollection = new AutoCompleteStringCollection();
        AutoCompleteStringCollection UnitsCollection = new AutoCompleteStringCollection();

        int colorCount = 0;
        //List<string> lstColors1 = Enum.GetValues(typeof(KnownColor))
        //            .Cast<KnownColor>()
        //            //.Where(k => k >= KnownColor.Transparent && k < KnownColor.ButtonFace) //Exclude system colors
        //            .Select(k => Color.FromKnownColor(k).Name)
        //            .OrderBy(c => c).ToList(); //141

        List<string>  lstColors = new List<string>(){ "ActiveBorder", "ActiveCaption", "AppWorkspace", "Aqua", "Aquamarine",
            "Bisque", "BlanchedAlmond", "BlueViolet", "Brown", "BurlyWood", "ButtonShadow",
            "CadetBlue", "Chartreuse", "Chocolate", "ControlDark", "ControlDarkDark", "Coral", "CornflowerBlue", "Crimson", "Cyan",
            "DarkCyan", "DarkGoldenrod", "DarkGray", "DarkGreen", "DarkKhaki", "DarkMagenta", "DarkOliveGreen", "DarkOrange", "DarkOrchid", "DarkRed", "DarkSalmon", "DarkSeaGreen", "DarkSlateBlue", "DarkSlateGray", "DarkTurquoise", "DarkViolet", "DeepSkyBlue","DimGray", "DodgerBlue",
            "Firebrick", "ForestGreen", "Fuchsia", "Gold", "Goldenrod", "GradientActiveCaption", "GradientInactiveCaption", "Gray", "GrayText", "Green", "GreenYellow",
            "Highlight", "HotPink", "HotTrack", "InactiveCaption", "IndianRed", "Indigo", "Khaki",
            "LawnGreen", "LightBlue", "LightCoral", "LightGreen", "LightPink", "LightSalmon", "LightSeaGreen", "LightSkyBlue", "LightSlateGray", "LightSteelBlue", "Lime", "LimeGreen",
            "Magenta", "Maroon", "MediumAquamarine", "MediumOrchid", "MediumPurple", "MediumSeaGreen", "MediumSlateBlue", "MediumSpringGreen", "MediumTurquoise", "MediumVioletRed", "MenuHighlight", "NavajoWhite",
            "Olive", "OliveDrab", "Orange", "OrangeRed", "Orchid", "PaleGreen", "PaleTurquoise", "PaleVioletRed", "Peru", "Pink", "Plum", "PowderBlue", "Purple",
            "RosyBrown", "RoyalBlue", "SaddleBrown", "Salmon", "SandyBrown", "SeaGreen", "Sienna", "Silver", "SkyBlue", "SlateBlue", "SlateGray", "SpringGreen", "SteelBlue",
            "Tan", "Teal", "Thistle", "Tomato", "Transparent", "Turquoise", "Violet", "Wheat", "WindowFrame", "Yellow", "YellowGreen" };

        public frmHome()
        {
            InitializeComponent();
            txtSearch.ForeColor = Color.LightGray;
            txtSearch.Text = "Enter Patient Name";
            this.txtSearch.Leave += new System.EventHandler(this.txtSearch_Leave);
            this.txtSearch.Enter += new System.EventHandler(this.txtSearch_Enter);

            txtValue.ForeColor = Color.LightGray;
            txtValue.Text = "Value";
            this.txtValue.Leave += new System.EventHandler(this.txtValue_Leave);
            this.txtValue.Enter += new System.EventHandler(this.txtValue_Enter);

            txtUnits.ForeColor = Color.LightGray;
            txtUnits.Text = "Units";
            this.txtUnits.Leave += new System.EventHandler(this.txtUnits_Leave);
            this.txtUnits.Enter += new System.EventHandler(this.txtUnits_Enter);

            txtDiagSearch.ForeColor = Color.LightGray;
            txtDiagSearch.Text = "Clinical Diagnosis";
            this.txtDiagSearch.Leave += new System.EventHandler(this.txtDiagSearch_Leave);
            this.txtDiagSearch.Enter += new System.EventHandler(this.txtDiagSearch_Enter);


            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
        }
        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "Enter Patient Name";
                txtSearch.Font = new Font(txtSearch.Font, FontStyle.Italic);
                txtSearch.ForeColor = Color.Gray;
            }
        }

        private void txtSearch_Enter(object sender, EventArgs e)
        {
            if (txtSearch.Text == "Enter Patient Name")
            {
                txtSearch.Text = "";
                txtSearch.Font = new Font(txtSearch.Font, FontStyle.Regular);
                txtSearch.ForeColor = Color.Black;
            }
        }

        private void txtValue_Leave(object sender, EventArgs e)
        {
            if (txtValue.Text == "")
            {
                txtValue.Text = "Value";
                txtValue.Font = new Font(txtValue.Font, FontStyle.Italic);
                txtValue.ForeColor = Color.Gray;
            }
        }

        private void txtValue_Enter(object sender, EventArgs e)
        {
            if (txtValue.Text == "Value")
            {
                txtValue.Text = "";
                txtValue.Font = new Font(txtValue.Font, FontStyle.Regular);
                txtValue.ForeColor = Color.Black;
            }
        }
        private void txtUnits_Leave(object sender, EventArgs e)
        {
            if (txtUnits.Text == "")
            {
                txtUnits.Text = "Units";
                txtUnits.Font = new Font(txtUnits.Font, FontStyle.Italic);
                txtUnits.ForeColor = Color.Gray;
            }
        }

        private void txtUnits_Enter(object sender, EventArgs e)
        {
            if (txtUnits.Text == "Units")
            {
                txtUnits.Text = "";
                txtUnits.Font = new Font(txtUnits.Font, FontStyle.Regular);
                txtUnits.ForeColor = Color.Black;
            }
        }

        private void txtDiagSearch_Leave(object sender, EventArgs e)
        {
            if (txtDiagSearch.Text.Trim() == "")
            {
                txtDiagSearch.Text = "Clinical Diagnosis";
                txtDiagSearch.Font = new Font(txtDiagSearch.Font, FontStyle.Italic);
                txtDiagSearch.ForeColor = Color.Gray;
            }
        }

        private void txtDiagSearch_Enter(object sender, EventArgs e)
        {
            if (txtDiagSearch.Text == "Clinical Diagnosis")
            {
                txtDiagSearch.Text = "";
                txtDiagSearch.Font = new Font(txtDiagSearch.Font, FontStyle.Regular);
                txtDiagSearch.ForeColor = Color.Black;
            }
        }

        private void getMedicine()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.MedicineListExcelPath))
                {
                    MessageBox.Show("Medicine list: " + Path.GetFileName(GloabalFunctions.MedicineListExcelPath) + " not exists" + "\r\n" + "Please place medicine list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.MedicineListExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.MedicineListExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtMedicineSearch.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtMedicineSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtMedicineSearch.AutoCompleteCustomSource = MyCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getMedicine()-->" + ex.Message);
            }
        }

        private void getSymptoms()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.SymptomsExcelPath))
                {
                    MessageBox.Show("Symptoms list: " + Path.GetFileName(GloabalFunctions.SymptomsExcelPath) + " not exists" + "\r\n" + "Please place Symptoms list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.SymptomsExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.SymptomsExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtSymptoms.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtSymptoms.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtSymptoms.AutoCompleteCustomSource = MyCollection;
                }
                if (UnitsCollection != null && UnitsCollection.Count > 0)
                {
                    txtUnits.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtUnits.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtUnits.AutoCompleteCustomSource = UnitsCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getSymptoms()-->" + ex.Message);
            }
        }

        private void getAddress()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.AddressesExcelPath))
                {
                    MessageBox.Show("Addresses list: " + Path.GetFileName(GloabalFunctions.AddressesExcelPath) + " not exists" + "\r\n" + "Please place Addresses list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.AddressesExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.AddressesExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtAddress.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtAddress.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtAddress.AutoCompleteCustomSource = MyCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getAddress()-->" + ex.Message);
            }
        }

        private void getOccupations()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.OccupationsExcelPath))
                {
                    MessageBox.Show("Occupations list: " + Path.GetFileName(GloabalFunctions.OccupationsExcelPath) + " not exists" + "\r\n" + "Please place occupations list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.OccupationsExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.OccupationsExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtOccupation.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtOccupation.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtOccupation.AutoCompleteCustomSource = MyCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getOccupations()-->" + ex.Message);
            }
        }

        private void getEmailIDs()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.EmailsExcelPath))
                {
                    MessageBox.Show("Emails list: " + Path.GetFileName(GloabalFunctions.EmailsExcelPath) + " not exists" + "\r\n" + "Please place Emails list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.EmailsExcelPath))
                    System.Threading.Thread.Sleep(100);
                emailCollection = getAutoCompleteCollection(GloabalFunctions.EmailsExcelPath);
                if (emailCollection != null && emailCollection.Count > 0)
                {
                    txtEmail.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtEmail.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtEmail.AutoCompleteCustomSource = emailCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getEmailIDs()-->" + ex.Message);
            }
        }

        private AutoCompleteStringCollection getAutoCompleteCollection(string path)
        {
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            try
            {
                string connString = "";
                if (!File.Exists(path))
                {
                    GloabalFunctions.WriteLog("File not exists: " + path);
                    return null;
                }

                if (GloabalFunctions.closeOpenedExcel(path))
                    System.Threading.Thread.Sleep(100);
                string strFileType = Path.GetExtension(path).ToLower();
                string sheetName = "";
                string sheetName2 = "";
                if (strFileType.Trim() == ".xls")
                {
                    //connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=Excel 8.0;";
                }
                else if (strFileType.Trim() == ".xlsx")
                {
                    //connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 12.0;";
                }

                //Get the name of the First Sheet.
                using (OleDbConnection con = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmd = new OleDbCommand())
                    {
                        cmd.Connection = con;
                        con.Open();
                        DataTable dtExcelSchema = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                        if(path.Contains("Symptoms.xls"))
                            sheetName2 = dtExcelSchema.Rows[1]["TABLE_NAME"].ToString();
                        con.Close();
                    }
                }
                //Read Data from the First Sheet.
                using (OleDbConnection con = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmd = new OleDbCommand())
                    {
                        using (OleDbDataAdapter oda = new OleDbDataAdapter())
                        {
                            //string query = "SELECT [UserName],[Education],[Location] FROM [Sheet1$]";
                            DataTable dt = new DataTable();
                            cmd.CommandText = "SELECT * From [" + sheetName + "]";
                            cmd.Connection = con;
                            con.Open();
                            oda.SelectCommand = cmd;
                            oda.Fill(dt);
                            //DataSet ds = new DataSet();
                            //da.Fill(ds);

                            if (dt != null && dt.Rows.Count > 0)
                            {
                                //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (dr[0] != DBNull.Value)
                                        MyCollection.Add(dr[0].ToString().Trim());
                                }
                            }

                            if (path.Contains("Symptoms.xls"))
                            {
                                dt = new DataTable();
                                cmd.CommandText = "SELECT * From [" + sheetName2 + "]";
                                oda.SelectCommand = cmd;
                                oda.Fill(dt);
                                con.Close();

                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                                    foreach (DataRow dr in dt.Rows)
                                    {
                                        if (dr[0] != DBNull.Value)
                                            UnitsCollection.Add(dr[0].ToString().Trim());
                                    }
                                }
                            }

                            con.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getAutoCompleteCollection()-->" + ex.Message);
                return null;
            }
            return MyCollection;
        }

        private void UpdateEmailIDsInExcel()
        {
            string connString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " + GloabalFunctions.EmailsExcelPath + "; Extended Properties = Excel 12.0; ";
            try
            {
                if (newEmailCollection != null && newEmailCollection.Count > 0)
                {
                    string sheetName = "";
                    //Get the name of the First Sheet.
                    using (OleDbConnection con = new OleDbConnection(connString))
                    {
                        con.Open();
                        DataTable dtExcelSchema = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                        using (OleDbCommand cmd = new OleDbCommand())
                        {
                            cmd.Connection = con;
                            foreach (string strmail in newEmailCollection)
                            {
                                string query = "Select Count(*) from [" + sheetName + "] where [EmailID]='" + strmail + "'";
                                cmd.CommandText = query;
                                int recCount = (int)cmd.ExecuteScalar();
                                if (recCount == 0)
                                {
                                    query = "Insert into [" + sheetName + "](EmailID) values('" + strmail + "')";
                                    cmd.CommandText = query;
                                    cmd.ExecuteScalar();
                                }
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("UpdateEmailIDsInExcel()-->" + ex.Message);
                MessageBox.Show("Error occured while updating the Mail IDs." + Environment.NewLine + ex.Message, "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void getClinicalDiagnosis()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.ClinicalDiagnosisExcelPath))
                {
                    MessageBox.Show("Clinical Diagnosis list: " + Path.GetFileName(GloabalFunctions.ClinicalDiagnosisExcelPath) + " not exists" + "\r\n" + "Please place Clinical Diagnosis list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.ClinicalDiagnosisExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection CliDiagnosisCollection = getAutoCompleteCollection(GloabalFunctions.ClinicalDiagnosisExcelPath);
                if (CliDiagnosisCollection != null && CliDiagnosisCollection.Count > 0)
                {
                    txtDiagnosis.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtDiagnosis.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtDiagnosis.AutoCompleteCustomSource = CliDiagnosisCollection;

                    txtDiagSearch.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtDiagSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtDiagSearch.AutoCompleteCustomSource = CliDiagnosisCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getClinicalDiagnosis()-->" + ex.Message);
            }
        }


        private void frmHome_Load(object sender, EventArgs e)
        {
            try
            {
                getMedicine();
                getSymptoms();

                timer1.Start();
                cmbSex.SelectedIndex = 0;
                cmbMonth.SelectedIndex = 0;
                strToDay = DateTime.Now.Day.ToString("D2") + "-" + DateTime.Now.Month.ToString("D2") + "-" + DateTime.Now.Year.ToString("D4");
                if (!Directory.Exists(UncPath + "\\" + strToDay))
                    Directory.CreateDirectory(UncPath + "\\" + strToDay);
                getData(strToDay,"");

                //Adding auto complete for address text box
                getAddress();
                getOccupations();
                getEmailIDs();
                getClinicalDiagnosis();
                UISettings();
                if ((DateTime.Now.Month == 1 && DateTime.Now.Day == 1) || (DateTime.Now.Month == 1 && DateTime.Now.Day == 15) || (DateTime.Now.Month == 12 && DateTime.Now.Day == 25))
                    showWishes();

            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("frmHome_Load()-->" + ex.Message);
            }            
        }

        private void showWishes()
        {
            try
            {
                frmAdds frmObj = new frmAdds();
                frmObj.Show();
                //frmObj.Dispose();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("showWishes()-->" + ex.Message);
            }
        }
        private void clearControls()
        {
            txtPName.Text = "";
            txtAge.Text = "";
            txtMonth.Text = "";
            txtContact.Text = "";
            cmbSex.SelectedIndex = 0;
            txtWeight.Text = "";
            txtHeight.Text = "";
            txtAddress.Text = "";
            txtTemparature.Text = "";
            txtWeight.Text = "";
            txtBP.Text = "";
            txtPulse.Text = "";
            txtCO.Text = "";
            txtRx.Text = "";
            txtSymptoms.Text = "";
            txtMedicineSearch.Text = "";
            txtOccupation.Text = "";
            txtEmail.Text = "";
            txtBMI.Text = "";
            txtRR.Text = "";
            txtDays.Text = "";

            txtValue.Text = "Value";
            txtValue.Font = new Font(txtValue.Font, FontStyle.Italic);
            txtValue.ForeColor = Color.Gray;

            txtUnits.Text = "Units";
            txtUnits.Font = new Font(txtUnits.Font, FontStyle.Italic);
            txtUnits.ForeColor = Color.Gray;
            chkReVisit.Checked = false;
            txtDiagnosis.Text = "";

            //dgPatients.ClearSelection();

            //dtpSearchDate.Text = DateTime.Now.Date.ToString();
            //txtSearch.Text = "Enter Patient Name";
            //txtSearch.Font = new Font(txtSearch.Font, FontStyle.Italic);
            //txtSearch.ForeColor = Color.Gray;
            //btnDelete.Enabled = false;
            //btnPrint.Enabled = false;
            //btnOpen.Enabled = false;
            //btnEdit.Enabled = false;
            //btnEmail.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                lblTime.Text = "Date: " + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt");
                //if (chkRandomColors.Checked && DateTime.Now.Second % 4 == 0)
                if (chkRandomColors.Checked && DateTime.Now.Second == 0 && DateTime.Now.Minute % Properties.Settings.Default.ColorInterval == 0)
                {
                    this.BackColor = Color.FromName(lstColors[colorCount]);
                    lblCN.Text = lstColors[colorCount];
                    colorCount += 1;
                    if (colorCount >= lstColors.Count)
                        colorCount = 0;
                }
            }
            catch (Exception ex)
            {
               GloabalFunctions.WriteLog(ex.Message);
            }
        }
       
        private void getData(string searchOn, string searchText)
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("PatientName");
                dt.Columns.Add("FilePath");

                string monthSearch = "";
                
                string cliDiag = txtDiagSearch.Text.Trim().ToLower();
                if (cliDiag == "clinical diagnosis")
                    cliDiag = "";
                if(cmbMonth.Enabled && cmbMonth.SelectedIndex>0)
                {
                    monthSearch = cmbMonth.SelectedIndex.ToString("D2") + "-" + DateTime.Now.Year.ToString("D4");
                    searchOn = "";
                }

                string myDir = UncPath + "\\" + searchOn;

                if (Directory.Exists(myDir) && (Directory.GetFiles(myDir,"*.doc", SearchOption.AllDirectories).Count() > 0 || Directory.GetFiles(myDir,"*.docx", SearchOption.AllDirectories).Count() > 0))
                {
                    List<string> lstFiles = Directory.GetFiles(myDir, "*.*", SearchOption.AllDirectories).Where(file => new string[] { ".doc", ".docx" }.Contains(Path.GetExtension(file))).ToList();

                    DataRow dr;

                    foreach (string strFile in lstFiles)
                    {
                        if(File.GetAttributes(strFile).HasFlag(FileAttributes.Hidden))
                            continue;
                        if (!string.IsNullOrEmpty(searchText))
                        {
                            if (!Path.GetFileNameWithoutExtension(strFile).ToLower().Contains(searchText.ToLower()))
                                continue;
                        }
                        if (!string.IsNullOrEmpty(cliDiag))
                        {
                            if (!Path.GetFileNameWithoutExtension(strFile).Contains("$"))
                                continue;
                            if (!Path.GetFileNameWithoutExtension(strFile).ToLower().Split('$')[0].Contains(cliDiag.ToLower()))
                                continue;
                        }
                        if (!string.IsNullOrEmpty(monthSearch))
                        {
                            if (!strFile.ToLower().Contains(monthSearch.ToLower()))
                                continue;
                        }

                        dr = dt.NewRow();
                        string pname= Path.GetFileNameWithoutExtension(strFile);
                        pname = pname.Contains("$") ? pname.Split('$')[1].Trim() : pname;

                        dr["PatientName"] = pname;
                        dr["FilePath"] = strFile;
                        dt.Rows.Add(dr);
                    }
                    dt.CaseSensitive = false;
                    //DataRow[] dtrow;
                    //dtrow = dt.Select("PatientName LIKE  '%" + searchText + "%'");
                    //dgPatients.AutoGenerateColumns = false;
                    
                    dgPatients.DataSource = dt;
                    lblCount.Text = "No.of records : " + dgPatients.Rows.Count;
                }
                else
                {
                    //dgPatients.DataSource = null;
                    dgPatients.DataSource = dt;
                    lblCount.Text = "No data found";
                }
                dgPatients.ClearSelection();

                btnDelete.Enabled = false;
                btnPrint.Enabled = false;
                btnOpen.Enabled = false;
                btnEdit.Enabled = false;
                btnEmail.Enabled = false;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getData()-->" + ex.Message);
            }
        }

        Dictionary<string, string> GetReplaceDictionary()
        {
            try
            {
                string strPName = txtPName.Text.Trim();
                string strAge = txtAge.Text.Trim();
                if (string.IsNullOrEmpty(strAge))
                    strAge = "0";
                strAge = strAge + "Y";
                string strAgeM = txtMonth.Text.Trim();
                string strAgeD = txtDays.Text.Trim();
                if (!string.IsNullOrEmpty(strAgeM))
                    strAge = strAge + ", " + strAgeM + "M";
                if (!string.IsNullOrEmpty(strAgeD))
                    strAge = strAge + ", " + strAgeD + "D";

                string strSex = cmbSex.Text.Trim();
                if (strSex == "Female")
                    strSex = "F";
                else if (strSex == "Male")
                    strSex = "M";
                else if (strSex == "Trans")
                    strSex = "TG";
                else
                    strSex = "";
                string strWeight = txtWeight.Text.Trim() + "Kg";
                string strHeight = txtHeight.Text.Trim() + "Cm";
                string strTemp = txtTemparature.Text.Trim();
                string strBP = txtBP.Text.Trim() + "mmHg";
                string strPR = txtPulse.Text.Trim();
                string strBMI = txtBMI.Text.Trim();
                string strRR = txtRR.Text.Trim();
                string strAddr = txtAddress.Text.Trim();
                string strOccup = txtOccupation.Text.Trim();
                string strContact = txtContact.Text.Trim();
                string strEmail = txtEmail.Text.Trim();

                string strCO = txtCO.Text.Trim(); // "C/O." + Environment.NewLine + txtCO.Text.Trim();
                string strRx = txtRx.Text.Trim();

                string strDate = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"); // DateTime.Now.Day.ToString("D2") + "/" + DateTime.Now.Month.ToString("D2") + "/" + DateTime.Now.Year.ToString("D4");
                
                Dictionary<string, string> replaceDict = new Dictionary<string, string>();

                replaceDict.Add("#date#", strDate);
                replaceDict.Add("#pname#", strPName + " ");
                replaceDict.Add("#age#", strAge + " ");
                replaceDict.Add("#sex#", strSex);

                if (!chkReVisit.Checked)
                {
                    replaceDict.Add("#wt#", strWeight + " ");
                    replaceDict.Add("#ht#", strHeight + " ");
                    replaceDict.Add("#bmi#", strBMI);

                    replaceDict.Add("#addrs#", strAddr + " ");
                    replaceDict.Add("#cont#", strContact);

                    replaceDict.Add("#occup#", strOccup + " ");
                    replaceDict.Add("#email#", strEmail);
                }
                replaceDict.Add("#tp#", strTemp);
                replaceDict.Add("#bp#", strBP + " ");
                replaceDict.Add("#p#", strPR);
                replaceDict.Add("#r#", strRR);

                replaceDict.Add("#co#", strCO);
                replaceDict.Add("#rx#", strRx);

                return replaceDict;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("GetReplaceDictionary()-->" + ex.Message);
                return null;
            }            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string strPName = txtPName.Text.Trim();
                string strSex = cmbSex.Text.Trim();
                string strCO = txtCO.Text.Trim();
                string strRx = txtRx.Text.Trim();
                string strAddr = txtAddress.Text.Trim();
                string strEmail = txtEmail.Text.Trim();

                if (string.IsNullOrEmpty(strPName))
                {
                    MessageBox.Show("Please enter patient name.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (strSex == "- Select -")
                {
                    MessageBox.Show("Please select gender.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (string.IsNullOrEmpty(strCO))
                {
                    MessageBox.Show("Please enter mandatory data.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (string.IsNullOrEmpty(strRx))
                {
                    MessageBox.Show("Please enter mandatory data.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if(chkReVisit.Checked && !File.Exists(GloabalFunctions.RevisitTemplatePath))
                {
                    MessageBox.Show("Patient revisit template: " + Path.GetFileName(GloabalFunctions.RevisitTemplatePath) + " not exists" + "\r\n" + "Please place template file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (!File.Exists(GloabalFunctions.PMSTemplatePath))
                {
                    MessageBox.Show("Patient template: " + Path.GetFileName(GloabalFunctions.PMSTemplatePath) + " not exists" + "\r\n" + "Please place template file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (chkA4.Checked && !File.Exists(GloabalFunctions.PMSTemplatePathA4))
                {
                    MessageBox.Show("A4 template: " + Path.GetFileName(GloabalFunctions.PMSTemplatePathA4) + " not exists" + "\r\n" + "Please place template file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (!Directory.Exists(UncPath + "\\" + strToDay))
                    Directory.CreateDirectory(UncPath + "\\" + strToDay);

                //initialize word object
                document = new Document();
                if (chkReVisit.Checked)
                {
                    strPName = strPName.Replace(".", "_") + "_Rev";
                    //close if the template is already opened
                    if (GloabalFunctions.closeOpenedWord(GloabalFunctions.RevisitTemplatePath))
                        System.Threading.Thread.Sleep(100);
                    document.LoadFromFile(GloabalFunctions.RevisitTemplatePath);
                }
                else
                {
                    //close if the template is already opened
                    if (GloabalFunctions.closeOpenedWord(GloabalFunctions.PMSTemplatePath))
                        System.Threading.Thread.Sleep(100);
                    if (chkA4.Checked)
                        document.LoadFromFile(GloabalFunctions.PMSTemplatePathA4);
                    else
                        document.LoadFromFile(GloabalFunctions.PMSTemplatePath);
                }

                string cliDiag = txtDiagnosis.Text.Trim();
                cliDiag = !string.IsNullOrEmpty(cliDiag) ? cliDiag + "$" : "";

                string docxPath = UncPath + "\\" + strToDay + "\\" + cliDiag + strPName.Replace(".", "_") + ".docx";

                //get strings to replace
                Dictionary<string, string> dictReplace = GetReplaceDictionary();
                //Replace text
                foreach (KeyValuePair<string, string> kvp in dictReplace)
                {
                    document.Replace(kvp.Key, kvp.Value, true, true);
                }
                //Save doc file.

                if (File.Exists(docxPath))
                {
                    DialogResult res = MessageBox.Show("Patient file already exists with name " + strPName + ".\r\n" + "Click Yes to override No to save another file.", "GPApps :: PMS", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (res == DialogResult.Yes)
                    {
                        if (GloabalFunctions.closeOpenedWord(docxPath))
                            System.Threading.Thread.Sleep(100);

                        File.Delete(docxPath);
                    }
                    else if (res == DialogResult.No)
                    {
                        docxPath = UncPath + "\\" + strToDay + "\\" + cliDiag + strPName.Replace(".", "_") + "_1" + ".docx";
                        if (File.Exists(docxPath))
                            docxPath = UncPath + "\\" + strToDay + "\\" + cliDiag + strPName.Replace(".", "_") + "_2" + ".docx";
                        if (GloabalFunctions.closeOpenedWord(docxPath))
                            System.Threading.Thread.Sleep(100);
                    }
                    else
                        return;
                }

                string pdfPath = docxPath.Replace(".docx", ".pdf");

                //if (MessageBox.Show("Are you sure, you want to save the patient details?", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.No)
                //    return;

                document.SaveToFile(docxPath, FileFormat.Docx);
                if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                {
                    //Convert to PDF
                    document.SaveToFile(pdfPath, FileFormat.PDF);
                }
                document.Close();

                dtpSearchDate.Text = DateTime.Now.Date.ToString();
                //getData(strToDay, "");
                //MessageBox.Show("Patient data saved successfully.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (MessageBox.Show("Patient data saved successfully. \r\n Click on cancel to give print.", "GPApps :: PMS", MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1) == DialogResult.Cancel)
                    GloabalFunctions.printFile(docxPath);

                //Adding recently entered emailid to the autoCompleteAddress collection
                if (!string.IsNullOrEmpty(strEmail) && !emailCollection.Contains(strEmail))
                {
                    emailCollection.Add(strEmail);
                    newEmailCollection.Add(strEmail);
                }
                if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                {
                    EmailNotification.eMailNotification(strPName, strEmail, pdfPath);
                    //System.Threading.Thread.Sleep(100);
                    if (File.Exists(pdfPath))
                        File.Delete(pdfPath);
                }

                chkReVisit.Checked = false;

                getData(strToDay, "");
                clearControls();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnSave_Click()-->" + ex.Message);
                MessageBox.Show(ex.Message, "GPApps :: PMS");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearControls();
        }
        
        private void btnOpen_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                GloabalFunctions.ToViewFile(filePath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnOpen_Click()-->" + ex.Message);
            }
        }
        
        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Patient file not exists at this location." + "\r\n" + filePath, "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                GloabalFunctions.printFile(filePath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnPrint_Click()-->" + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1 )
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                if(MessageBox.Show("Are you sure you want to delete?", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.No)
                    return;
                if (File.Exists(filePath))
                {
                    GloabalFunctions.closeOpenedWord(filePath);
                    File.Delete(filePath);
                    string searchOn = dtpSearchDate.Text;
                    string searchText = txtSearch.Text.Trim().ToLower();
                    if (searchText == "enter patient name")
                        searchText = "";
                    DateTime dtSearchOn = new DateTime();
                    dtSearchOn = ConvertDate(searchOn);
                    searchOn = dtSearchOn.Day.ToString("D2") + "-" + dtSearchOn.Month.ToString("D2") + "-" + dtSearchOn.Year.ToString("D4");
                    getData(searchOn, searchText);
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnDelete_Click()-->" + ex.Message);
                MessageBox.Show(ex.Message, "GPApps :: PMS");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //UpdateEmailIDsInExcel();
            this.Close();            
        }

        #region "Edit functionality"        
        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Patient file not exists at this location." + "\r\n" + filePath, "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                editPatientFile(filePath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnEdit_Click()-->" + ex.Message);
            }
        }
        private bool editPatientFile(string strFilePath)
        {
            bool retVal = false;
            try
            {
                //Create word document
                Document document = new Document();
                document.LoadFromFile(strFilePath);
                string filename = Path.GetFileNameWithoutExtension(strFilePath);
                string cliDiag = filename.Contains("$") ? filename.Split('$')[0].Trim() : "";
                txtDiagnosis.Text = cliDiag;
                //Get a paragraph
                //Paragraph paragraph = document.Sections[0].AddParagraph();

                if (document.Sections.Count > 0)
                {
                    foreach (Section sec in document.Sections)
                    {
                        if (sec.Paragraphs.Count > 0)
                        {
                            string txtPara = "";
                            string strTemp = "";
                            string[] tempArr = new string[2];

                            //Getting patient name, age, add,...
                            foreach (Paragraph prgp in sec.Paragraphs)
                            {
                                txtPara = prgp.Text;
                                if (txtPara.Contains("Date:"))
                                    continue;
                                if (txtPara.Contains("Patient Name:"))
                                {
                                    tempArr = Regex.Split(txtPara, "Age:");
                                    //string Name = tempArr[0].Trim().Replace("Patient Name:", "");
                                    txtPName.Text = tempArr[0].Replace("Patient Name:", "").Trim();
                                    strTemp = tempArr[1].Trim();
                                    //string age = strTemp.Split(new string[] { "fdsf" },StringSplitOptions.None)[0];                                    
                                    tempArr = Regex.Split(strTemp, "Sex:");
                                    string age = tempArr[0].Trim(); 
                                    if (!string.IsNullOrEmpty(age) && age.Contains("M"))
                                    {
                                        txtAge.Text = age.Substring(0, age.IndexOf('Y'));
                                        string m = age.Substring(age.IndexOf('Y') + 2).Trim();
                                        txtMonth.Text = m.Substring(0, m.IndexOf('M')).Trim();
                                        if(m.Contains("D"))
                                            txtDays.Text = m.Substring(m.IndexOf('M') + 2).Replace("D", "").Trim();
                                    }
                                    else if(!age.Contains("M") && age.Contains("D"))
                                    {
                                        txtMonth.Text = "";
                                        txtAge.Text = age.Substring(0, age.IndexOf('Y'));
                                        txtDays.Text = age.Substring(age.IndexOf('Y') + 2).Replace("D", "").Trim();
                                    }
                                    else
                                    {
                                        txtAge.Text = age.Replace("Y", "").Trim();
                                        txtMonth.Text = "";
                                        txtDays.Text = "";
                                    }

                                    string sex = tempArr[1].Trim();
                                    if (sex.ToUpper() == "TRANS")
                                        cmbSex.SelectedIndex = 3;
                                    else if (sex.ToUpper() == "M")
                                        cmbSex.SelectedIndex = 2;
                                    else if (sex.ToUpper() == "F")
                                        cmbSex.SelectedIndex = 1;
                                    else
                                        cmbSex.SelectedIndex = 0;
                                }
                                else if (txtPara.Trim().Contains("Weight:"))
                                {
                                    tempArr = Regex.Split(txtPara, "Height:");
                                    txtWeight.Text = tempArr[0].Trim().Replace("Weight:", "").Replace("Kg", "").Trim();

                                    strTemp = tempArr[1].Trim();

                                    if (strTemp.Contains("BMI"))
                                    {
                                        tempArr = Regex.Split(strTemp, "BMI:");
                                        txtHeight.Text = tempArr[0].Replace("Cm", "").Trim();
                                        txtBMI.Text = tempArr[1].Trim();
                                    }
                                    else
                                    {
                                        tempArr = Regex.Split(strTemp, "Temp:");
                                        txtHeight.Text = tempArr[0].Replace("Cm", "").Trim();

                                        strTemp = tempArr[1].Trim();
                                        tempArr = Regex.Split(strTemp, "B.P:");
                                        string temparature = tempArr[0].Trim();
                                        txtTemparature.Text = temparature.Substring(0, temparature.IndexOf("F") - 1).Trim();
                                        string bp = tempArr[1].Trim();
                                        txtBP.Text = bp.Substring(0, bp.IndexOf("mmHg")).Trim();

                                        strTemp = tempArr[1].Trim();
                                        txtPulse.Text = Regex.Split(strTemp, "P:")[1].Replace("/Min", "").Trim();
                                        txtRR.Text = "";
                                        txtBMI.Text = "";
                                    }
                                }
                                else if(txtPara.Trim().Contains("Temp:")) //new block, it'll execute only for new template with RR,BMI 
                                {
                                    tempArr = Regex.Split(txtPara, "B.P:");
                                    string temparature = tempArr[0].Replace("Temp:", "").Trim();
                                    txtTemparature.Text = temparature.Substring(0, temparature.IndexOf("F") - 1).Trim();

                                    string bp = tempArr[1].Trim();
                                    txtBP.Text = bp.Substring(0, bp.IndexOf("mmHg")).Trim();

                                    strTemp = tempArr[1].Trim();
                                    strTemp = strTemp.Substring(strTemp.IndexOf("mmHg") + 4).Trim();

                                    string pr = "";
                                    string rr = "";
                                    if (strTemp.Contains("RR:"))
                                    {
                                        tempArr = Regex.Split(strTemp, "RR:");
                                        pr = tempArr[0];
                                        rr = tempArr[1].Trim().Replace("/Min", "").Replace("/M", "").Trim();
                                    }
                                    else
                                    {
                                        pr = strTemp;
                                    }

                                    pr = pr.Contains("P:") ? pr.Replace("P:", "").Trim() : pr.Replace("PR:", "").Trim();
                                    pr = pr.Replace("/Min", "").Replace("/M", "").Trim();

                                    txtPulse.Text = pr;
                                    txtRR.Text = rr;
                                }
                                else if (txtPara.Contains("Address:"))
                                {
                                    tempArr = Regex.Split(txtPara, "Contact#:");

                                    //txtAddress.Text = tempArr[0].Trim().Replace("Address:", "").Trim();
                                    //string Cont = tempArr[1].Trim();
                                    //txtContact.Text = Cont.Substring(0, Cont.IndexOf("Occupation")).Trim();
                                    //strTemp = tempArr[1].Trim();
                                    //txtOccupation.Text = Regex.Split(strTemp, "Occupation:")[1].Trim();

                                    if (tempArr.Length == 2)
                                    {
                                        txtAddress.Text = tempArr[0].Trim().Replace("Address:", "").Trim();
                                        txtContact.Text = tempArr[1].Trim();

                                    }
                                    else if (tempArr.Length == 1)
                                    {
                                        txtAddress.Text = tempArr[0].Trim().Replace("Address:", "").Trim();
                                        txtContact.Text = "";
                                    }
                                }
                                else if (txtPara.Contains("Occupation:"))
                                {
                                    txtOccupation.Text = txtPara.Replace("Occupation:", "").Trim();

                                    tempArr = Regex.Split(txtPara, "Email:");
                                    if (tempArr.Length == 2)
                                    {
                                        txtOccupation.Text = tempArr[0].Trim().Replace("Occupation:", "").Trim();
                                        txtEmail.Text = tempArr[1].Trim();

                                    }
                                    else if (tempArr.Length == 1)
                                    {
                                        txtOccupation.Text = tempArr[0].Trim().Replace("Occupation:", "").Trim();
                                        txtEmail.Text = "";
                                    }
                                    //break;
                                }
                            }
                        }
                        if (sec.Tables.Count > 0 && sec.Tables[0].Rows.Count > 0)
                        {
                            //Getting C/o & Rx details
                            StringBuilder sbCo = new StringBuilder();
                            StringBuilder sbRx = new StringBuilder();
                            Table table = sec.Tables[0] as Table;
                            if (table != null && table.Rows.Count > 0)
                            {
                                TableRow tr1 = table.Rows[0];
                                if (tr1 != null && tr1.Cells.Count > 0 && tr1.Cells.Count == 2)
                                {
                                    TableCell tc1 = tr1.Cells[0];
                                    TableCell tc2 = tr1.Cells[1];
                                    if (tc1.Paragraphs.Count > 0)
                                    {
                                        foreach (Paragraph pr in tc1.Paragraphs)
                                        {
                                            string strTxt = pr.Text;
                                            if (!string.IsNullOrEmpty(strTxt) && strTxt.Trim().ToLower() == "c/o.")
                                                continue;
                                            sbCo.AppendLine(strTxt);
                                        }
                                        txtCO.Text = Convert.ToString(sbCo);
                                    }
                                    if (tc2.Paragraphs.Count > 0)
                                    {
                                        foreach (Paragraph pr in tc2.Paragraphs)
                                        {
                                            string strTxt = pr.Text;
                                            if (!string.IsNullOrEmpty(strTxt) && strTxt.Trim().ToLower() == "rx,")
                                                continue;
                                            sbRx.AppendLine(strTxt);
                                        }
                                        txtRx.Text = Convert.ToString(sbRx);
                                    }
                                }
                            }
                        }
                    }
                }

                document.Close();
                if (strFilePath.Contains("_Rev"))
                    chkReVisit.Checked = true;
                else
                    chkReVisit.Checked = false;
                retVal = true;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("editPatientFile()-->" + ex.Message);
                retVal = false;
            }
            return retVal;
        }

        #endregion
        private void lbtnConfig_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                frmConfig frmCnf =new frmConfig();
                frmCnf.ShowDialog();
                Application.DoEvents();
                frmCnf.Dispose();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("lbtnConfig_LinkClicked()-->" + ex.Message);
            }
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1 || (sender as TextBox).Name == "txtAge"))
            {
                e.Handled = true;
            }
        }

        private void txtMonth_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                {
                    e.Handled = true;
                }

                //if (!string.IsNullOrEmpty(txtMonth.Text))
                //{
                //    string mm = txtMonth.Text.Trim() + "" + e.KeyChar.ToString();
                //    if (Convert.ToInt16(mm) > 11)
                //        e.Handled = true;
                //}
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }


        private void txtBP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '/'))
            {
                e.Handled = true;
            }

            // only allow one slash
            if ((e.KeyChar == '/') && ((sender as TextBox).Text.IndexOf('/') > -1))
            {
                e.Handled = true;
            }
        }
        public bool blConvertDate = true;
        public DateTime ConvertDate(string s)//Convert String to Date 
        {
            DateTime time = DateTime.Now;
            try
            {
                blConvertDate = true;
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
                DateTime time2 = Convert.ToDateTime(s);
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
                time = Convert.ToDateTime(time2);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("ConvertDate()-->" + ex.Message);
                blConvertDate = false;
            }
            return time;
        }
        
        private void dgPatients_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            dgPatients.ClearSelection();
            btnDelete.Enabled = false;
            btnPrint.Enabled = false;
            btnOpen.Enabled = false;
            btnEdit.Enabled = false;
            btnEmail.Enabled = false;
        }

        private void dgPatients_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count == 0)
                    return;
                btnDelete.Enabled = true;
                btnPrint.Enabled = true;
                btnOpen.Enabled = true;
                btnEdit.Enabled = true;
                btnEmail.Enabled = true;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("dgPatients_CellClick()-->" + ex.Message);
            }
        }

        private void btnClear2_Click(object sender, EventArgs e)
        {
            dtpSearchDate.Text = DateTime.Now.Date.ToString();
            dgPatients.ClearSelection();

            txtSearch.Text = "Enter Patient Name";
            txtSearch.Font = new Font(txtSearch.Font, FontStyle.Italic);
            txtSearch.ForeColor = Color.Gray;
            btnDelete.Enabled = false;
            btnPrint.Enabled = false;
            btnOpen.Enabled = false;
            btnEdit.Enabled = false;
            btnEmail.Enabled = false;
            chkSearchAll.Checked = false;

            chkMonth.Checked = false;
            cmbMonth.SelectedIndex = 0;
            cmbMonth.Enabled = false;
            txtDiagSearch.Text = "Clinical Diagnosis";
            txtDiagSearch.Font = new Font(txtDiagSearch.Font, FontStyle.Italic);
            txtDiagSearch.ForeColor = Color.Gray;
            txtDiagSearch.Enabled = false;
            getData(strToDay,"");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string strTxt = txtMedicineSearch.Text.Trim();
            //Bullet format
            //if (!string.IsNullOrEmpty(strTxt))
            //{
            //    if (strTxt.Length == 1)
            //        strTxt = char.ToUpper(strTxt[0]).ToString();
            //    else if (strTxt.Length > 1)
            //        strTxt = char.ToUpper(strTxt[0]) + strTxt.Substring(1);

            //    txtRx.AppendText("\u2022 " + strTxt + Environment.NewLine);
            //    txtMedicineSearch.Text = "";
            //}

//         1‣ \u2023 (TRIANGULAR BULLET)
//         2 ◦ \u25E6 (WHITE BULLET)
//         3 ◉ \u25C9 (FISHEYE)
//         4 ■ \u25A0 (BLACK SQUARE)
//         5 □ \u25A1 (WHITE SQUARE)
//         6 ❏ \u274F (LOWER RIGHT DROP-SHADOWED WHITE SQUARE)

            if (bullet == "1")
                bullet = "\u2023";
            else if (bullet == "2")
                bullet = "\u2022";
            else if (bullet == "3")
                bullet = "\u25C9";

            else if (bullet == "4")
                bullet = "\u25A0";
            else if (bullet == "5")
                bullet = "\u25A1";
            else if (bullet == "6")
                bullet = "\u274F";
            else if (bullet == "7")
                bullet = "\u25E6";


            //Number format
            if (!string.IsNullOrEmpty(strTxt))
            {
                if (strTxt.Length == 1)
                    strTxt = char.ToUpper(strTxt[0]).ToString();
                else if (strTxt.Length > 1)
                    strTxt = char.ToUpper(strTxt[0]) + strTxt.Substring(1);

                int n = 1;
                if (txtRx.Lines.Count() > 0)
                {
                    int noofLines = txtRx.Lines.Length;
                    string lastline = txtRx.Lines[noofLines - 1];
                    if (string.IsNullOrEmpty(lastline))
                    {
                        for (int i = 1; i <= noofLines; i++)
                        {
                            lastline = txtRx.Lines[noofLines - i];
                            if (!string.IsNullOrEmpty(lastline) && lastline.Contains(')'))
                                break;
                        }
                    }
                    string num = lastline.Split(')')[0].Replace(bullet, "");
                    //num = System.Text.RegularExpressions.Regex.Split(lastline, ")", System.Text.RegularExpressions.RegexOptions.None)[0];

                    if (int.TryParse(num, out n))
                        n = n + 1;
                    else
                        n = 1;

                    strTxt = bullet + n + ") " + strTxt;
                }
                else
                    strTxt = bullet + n + ") " + strTxt;

                txtRx.AppendText(strTxt + Environment.NewLine);
                txtMedicineSearch.Text = "";
                txtMedicineSearch.Focus();
            }
        }

        private void btnAddSymptom_Click(object sender, EventArgs e)
        {
            string strTxt = txtSymptoms.Text.Trim();
            if (!string.IsNullOrEmpty(strTxt))
            {
                if (strTxt.Length == 1)
                    strTxt = char.ToUpper(strTxt[0]).ToString();
                else if (strTxt.Length > 1)
                    strTxt = char.ToUpper(strTxt[0]) + strTxt.Substring(1);

                string val = txtValue.Text.Trim();
                if (!string.IsNullOrEmpty(val) && val != "Value")
                {
                    int indx = strTxt.LastIndexOf(':');
                    if (indx > 0)
                        strTxt = strTxt.Remove(indx, 1).Insert(indx, ": " + val + " ");
                    else
                        strTxt = strTxt + ": " + val;
                }

                string unit = txtUnits.Text.Trim();
                if (!string.IsNullOrEmpty(unit) && unit != "Units")
                {
                    strTxt = strTxt + " " + unit;
                }

                txtCO.AppendText("\u2022 " + strTxt + Environment.NewLine);
                txtSymptoms.Text = "";

                txtValue.Text = "Value";
                txtValue.Font = new Font(txtValue.Font, FontStyle.Italic);
                txtValue.ForeColor = Color.Gray;

                txtUnits.Text = "Units";
                txtUnits.Font = new Font(txtUnits.Font, FontStyle.Italic);
                txtUnits.ForeColor = Color.Gray;
                txtSymptoms.Focus();
            }
        }

        private void dgPatients_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right && e.RowIndex > -1)
            {
                dgPatients.ClearSelection();
                dgPatients.Rows[e.RowIndex].Selected =true;
                btnDelete.Enabled = true;
                btnPrint.Enabled = true;
                btnOpen.Enabled = true;
                btnEdit.Enabled = true;
                btnEmail.Enabled = true;
            }
        }

        private void dgPatients_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                btnOpen.PerformClick();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("dgPatients_CellDoubleClick()-->" + ex.Message);
            }
        }

        private void dgPatients_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                DataGridView.HitTestInfo ht;
                ht = dgPatients.HitTest(e.X, e.Y);
                dgPatients.ContextMenuStrip = null;

                if (ht.Type == DataGridViewHitTestType.RowHeader || ht.Type == DataGridViewHitTestType.Cell)
                    dgPatients.ContextMenuStrip = contextMenuStrip1;
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgPatients.SelectedRows.Count == 1)
                btnOpen.PerformClick();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgPatients.SelectedRows.Count == 1)
                btnPrint.PerformClick();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgPatients.SelectedRows.Count == 1)
                btnDelete.PerformClick();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string searchOn = dtpSearchDate.Text;
                string searchText = txtSearch.Text.Trim().ToLower();
                if (searchText == "enter patient name")
                    searchText = "";
                DateTime dtSearchOn = dtpSearchDate.Value; // new DateTime();
                //dtSearchOn = ConvertDate(searchOn);
                //if (blConvertDate)
                //{
                    searchOn = dtSearchOn.Day.ToString("D2") + "-" + dtSearchOn.Month.ToString("D2") + "-" + dtSearchOn.Year.ToString("D4");
                    if (chkSearchAll.Checked) // && (!string.IsNullOrEmpty(txtSearch.Text) && txtSearch.Text.Trim().ToLower() != "enter patient name") || (!string.IsNullOrEmpty(txtDiagSearch.Text.Trim()) && txtDiagSearch.Text.Trim().ToLower() != "clinical diagnosis"))
                        searchOn = "";


                    getData(searchOn, searchText);
                //}
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnSearch_Click()-->" + ex.Message);
            }
        }


        private void dtpSearchDate_ValueChanged(object sender, EventArgs e)
        {
            if (_dtpDropDown)
                return;
            btnSearch.PerformClick();
        }
        private bool _dtpDropDown = false;
        private void dtpSearchDate_DropDown(object sender, EventArgs e)
        {
            _dtpDropDown = true;
        }

        private void chkSearchAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkSearchAll.Checked)
                {
                    cmbMonth.SelectedIndex = 0;
                    cmbMonth.Enabled = false;
                    if ((!string.IsNullOrEmpty(txtSearch.Text.Trim()) && txtSearch.Text.Trim().ToLower() != "enter patient name") || (!string.IsNullOrEmpty(txtDiagSearch.Text.Trim()) && txtDiagSearch.Text.Trim().ToLower() != "clinical diagnosis"))
                    {
                        btnSearch.PerformClick();
                    }
                }
                else
                {
                    if (chkMonth.Checked)
                        cmbMonth.Enabled = true;
                    btnSearch.PerformClick();
                }
                //if ((!string.IsNullOrEmpty(txtSearch.Text.Trim()) && txtSearch.Text.Trim().ToLower() != "enter patient name") || (!string.IsNullOrEmpty(txtDiagSearch.Text.Trim()) && txtDiagSearch.Text.Trim().ToLower() != "clinical diagnosis"))
                //{
                //    btnSearch.PerformClick();
                //}
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("chkSearchAll_CheckedChanged()-->" + ex.Message);
            }
        }


        private void dtpSearchDate_CloseUp(object sender, EventArgs e)
        {
            _dtpDropDown = false;
            dtpSearchDate_ValueChanged(null, null);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(txtSearch.Text.Trim()) ) || cmbMonth.SelectedIndex>0 || (!string.IsNullOrEmpty(txtDiagSearch.Text.Trim()) && txtDiagSearch.Text.Trim().ToLower() != "clinical diagnosis"))
                btnSearch.PerformClick();
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtAddress.Text) && !Char.IsUpper(txtAddress.Text, 0))
            {
                txtAddress.Text = Char.ToUpper(txtAddress.Text[0]) + txtAddress.Text.Substring(1);
                txtAddress.Select(txtAddress.Text.Length, 1);
            }
        }

        private void SetFirstCharUpper(object sender, EventArgs e)
        {
            TextBox txt = (TextBox)sender;
            if (!string.IsNullOrEmpty(txt.Text) && !Char.IsUpper(txt.Text, 0))
            {
                txt.Text = Char.ToUpper(txt.Text[0]) + txt.Text.Substring(1);
                txt.Select(txt.Text.Length, 1);
            }
            if (txt.Name == "txtDiagSearch" && !string.IsNullOrEmpty(txt.Text))
                btnSearch.PerformClick();
        }

        private void btnClose2_Click(object sender, EventArgs e)
        {
            try
            {
                //UpdateEmailIDsInExcel();
                this.Close();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnClose2_Click()-->" + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //string filePath = @"D:\PatientData\24-12-2017\TEST.docx";
                //EmailNotification.eMailNotification("Ramesh", "ganapathi.bridgesol@gmail.com", filePath);

                string strEmail = txtEmail.Text.Trim();

                //Adding recently entered emailid to the autoCompleteAddress collection
                if (!string.IsNullOrEmpty(strEmail) && !emailCollection.Contains(strEmail))
                    emailCollection.Add(strEmail);
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {
            if (txtEmail.Text.Trim().Length > 0)
            {
                if (!GloabalFunctions.isValidMail(txtEmail.Text.Trim()))
                {
                    MessageBox.Show("Please provide valid email address.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtEmail.SelectAll();
                    txtEmail.Focus();
                }
            }
        }

        private void frmHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //if(e.CloseReason == CloseReason.UserClosing)
                UpdateEmailIDsInExcel();
                Application.Exit();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("frmHome_FormClosing()-->" + ex.Message);
            }
        }

        private void frmHome_Resize(object sender, EventArgs e)
        {
            int x, y;
            x = (this.Width - (grbMain.Width + 17)) / 2;
            y = (this.Height - (grbMain.Height + 44)) / 2;
            grbMain.Location = new Point(x, y);
        }

        public static string filepathForMail = "";
        public static string patientNameForMail = "";
        public static AutoCompleteStringCollection emailCollForNotification = new AutoCompleteStringCollection();
        private void btnEmail_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                filepathForMail = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                emailCollForNotification = emailCollection; 

                OpenForm(new frmEmail());
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnClose2_Click()-->" + ex.Message);
            }
        }

        private void btnBill_Click(object sender, EventArgs e)
        { 
            OpenForm(new frmBill());
        }
        private void btnMCert_Click(object sender, EventArgs e)
        { 
            OpenForm(new frmMCertificate());
        }

        private void btnInvestigations_Click(object sender, EventArgs e)
        {
            OpenForm(new frmInvestigations());
        }

        private void btnMFC_Click(object sender, EventArgs e)
        {
            OpenForm(new frmMFitnessCertificate());
        }

        private void btnVaccination_Click(object sender, EventArgs e)
        {
            OpenForm(new frmVaccinationCard());
        }

        private void OpenForm(Form frmObj)
        {
            try
            {
                if (dgPatients.SelectedRows.Count == 1)
                    patientNameForMail = dgPatients.SelectedRows[0].Cells[0].Value.ToString().Trim();
                else
                    patientNameForMail = "";

                frmObj.ShowDialog();
                Application.DoEvents();
                frmObj.Dispose();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("OpenForm()-->" + ex.Message);
            }
        }

        private void lbtnColor_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                OpenForm(new frmUISettings());
                System.Threading.Thread.Sleep(500);
                UISettings();

                //DialogResult result1 = MessageBox.Show("Click on Yes to set form back color" + "\r\n" + "Click No to set clinic name color", "GPApps :: PMS", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                //if (result1 == DialogResult.Cancel)
                //    return;
                //if(colorDialog1.ShowDialog() == DialogResult.OK)
                //{
                //    var res = (result1 == DialogResult.Yes) ? this.BackColor = colorDialog1.Color : this.lblClinic.ForeColor = colorDialog1.Color;
                //}

            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("lbtnColor_LinkClicked()-->" + ex.Message);
            }
        }
        private void UISettings()
        {
            lblClinic.Text = Properties.Settings.Default.ClinicName;
            lblClinic.ForeColor = Color.FromName(Properties.Settings.Default.ClinicNameColor);
            //lblClinic.Font.Size = Convert.ToInt32(Properties.Settings.Default.ClinicNameFontSize);
            lblClinic.Font = new Font("Microsoft Sans Serif", Convert.ToInt32(Properties.Settings.Default.ClinicNameFontSize), FontStyle.Bold);
            this.BackColor = Color.FromName(Properties.Settings.Default.BackgroundColor);
        }
        private void lbtnReVisit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenForm(new frmRevisit());
            getData(strToDay, "");
        }

        private void chkRandomColors_CheckedChanged(object sender, EventArgs e)
        {
            if(chkRandomColors.Checked)
            {
                this.BackColor = Color.FromName(lstColors[colorCount]);
                lblCN.Text = lstColors[colorCount];
                colorCount += 1;
                if (colorCount >= lstColors.Count)
                    colorCount = 0;
            }
            else
            {
                this.BackColor = Color.FromName(Properties.Settings.Default.BackgroundColor);
            }
        }

        private void lbtnLabReports_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenForm(new frmLabReports());
        }

        private void chkMonth_CheckedChanged(object sender, EventArgs e)
        {
            if(chkMonth.Checked)
            {
                if (chkSearchAll.Checked)
                    cmbMonth.Enabled = false;
                else
                    cmbMonth.Enabled = true;
                txtDiagSearch.Enabled = true;
            }
            else
            {
                cmbMonth.Enabled = false;
                txtDiagSearch.Text = "Clinical Diagnosis";
                txtDiagSearch.Font = new Font(txtDiagSearch.Font, FontStyle.Italic);
                txtDiagSearch.ForeColor = Color.Gray;
                txtDiagSearch.Enabled = false;
            }
            cmbMonth.SelectedIndex = 0;
        }

        private void cmbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cmbMonth.Enabled && (cmbMonth.SelectedIndex == 0 || (cmbMonth.SelectedIndex>0 && (!string.IsNullOrEmpty(txtDiagSearch.Text.Trim()) && txtDiagSearch.Text.Trim().ToLower() != "clinical diagnosis"))))
                btnSearch.PerformClick();

        }


        //private void txtMedicineSearch_KeyDown(object sender, KeyEventArgs e)
        //{
        //    if (e.KeyValue == 13)
        //    {
        //        btnAdd.PerformClick();
        //    }
        //}

        //private void txtMedicineSearch_KeyUp(object sender, KeyEventArgs e)
        //{

        //}
    }
}
