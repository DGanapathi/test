﻿using PMSApp.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmAdds : Form
    {
        public frmAdds()
        {
            InitializeComponent();
        }

        private void frmAdds_Load(object sender, EventArgs e)
        {
            if (DateTime.Now.Month == 1 && DateTime.Now.Day == 1)
                pictureBox1.Image = Resources.happy_new_year;
            else if (DateTime.Now.Month == 1 && DateTime.Now.Day == 15)
                pictureBox1.Image = Resources.pongal;
            else if (DateTime.Now.Month == 12 && DateTime.Now.Day == 25)
                pictureBox1.Image = Resources.christmas;
            else 
                pictureBox1.Image = Resources.animated;
        }
    }
}
