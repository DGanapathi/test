﻿using Spire.Doc;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmBill : Form
    {
        public frmBill()
        {
            InitializeComponent();
        }
        private int counter = 1;
        string UncPath = Directory.GetParent(System.Configuration.ConfigurationManager.AppSettings["FilesPath"]).ToString() + Path.DirectorySeparatorChar + "PatientBills";
        //word document object
        Document document = null;

        AutoCompleteStringCollection autoColl = new AutoCompleteStringCollection();

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (counter > 5)
                    return;
                string particulars = txtParticulars.Text.Trim();
                string amount = txtAmount.Text.Trim();
                int total = 0;
                if(!string.IsNullOrEmpty(txtTotal.Text.Trim()))
                    total = Convert.ToInt32(txtTotal.Text.Trim());
                if (string.IsNullOrEmpty(particulars) || string.IsNullOrEmpty(amount))
                {
                    MessageBox.Show("Please enter particulars and amount.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (particulars.Length == 1)
                    particulars = char.ToUpper(particulars[0]).ToString();
                else if (particulars.Length > 1)
                    particulars = char.ToUpper(particulars[0]) + particulars.Substring(1);

                if (counter == 1)
                {
                    txtParticulars1.Text = particulars;
                    txtAmount1.Text = amount;
                }
                else if (counter == 2)
                {
                    txtParticulars2.Text = particulars;
                    txtAmount2.Text = amount;
                }
                else if (counter == 3)
                {
                    txtParticulars3.Text = particulars;
                    txtAmount3.Text = amount;
                }
                else if (counter == 4)
                {
                    txtParticulars4.Text = particulars;
                    txtAmount4.Text = amount;
                }
                else if (counter == 5)
                {
                    txtParticulars5.Text = particulars;
                    txtAmount5.Text = amount;
                }

                counter++;
                txtTotal.Text = Convert.ToString(Convert.ToInt32(total) + Convert.ToInt32(amount));

                txtParticulars.Text = "";
                txtAmount.Text = "";
            }
            catch (Exception ex)
            {
               GloabalFunctions.WriteLog("btnAdd_Click()-->" + ex.Message);
            }
        }
        private void clearControls()
        {
            try
            {
                counter = 1;
                txtPName.Text = "";
                txtParticulars.Text = "";
                txtParticulars1.Text = "";
                txtParticulars2.Text = "";
                txtParticulars3.Text = "";
                txtParticulars4.Text = "";
                txtParticulars5.Text = "";

                txtAmount.Text = "";
                txtAmount1.Text = "";
                txtAmount2.Text = "";
                txtAmount3.Text = "";
                txtAmount4.Text = "";
                txtAmount5.Text = "";

                txtTotal.Text = "";
                dtpBillDate.Text = DateTime.Now.Date.ToString();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnAdd_Click()-->" + ex.Message);
            }
        }

        Dictionary<string, string> GetReplaceDictionary()
        {
            try
            {
                string strPName = txtPName.Text.Trim();
                string billDate = dtpBillDate.Text.Trim();
                string billNo = txtBillNo.Text.Trim();
                string tot = txtTotal.Text.Trim();
                string No1="", No2="", No3 = "", No4 = "", No5 = "";
                string amnt1, amnt2, amnt3, amnt4, amnt5;
                string part1, part2, part3, part4, part5 = "";

                amnt1 = txtAmount1.Text.Trim();
                amnt2 = txtAmount2.Text.Trim();
                amnt3 = txtAmount3.Text.Trim();
                amnt4 = txtAmount4.Text.Trim();
                amnt5 = txtAmount5.Text.Trim();

                part1 = txtParticulars1.Text.Trim();
                part2 = txtParticulars2.Text.Trim();
                part3 = txtParticulars3.Text.Trim();
                part4 = txtParticulars4.Text.Trim();
                part5 = txtParticulars5.Text.Trim();

                if (!string.IsNullOrEmpty(part1))
                    No1 = "1";
                if (!string.IsNullOrEmpty(part2))
                    No2 = "2";
                if (!string.IsNullOrEmpty(part3))
                    No3 = "3";
                if (!string.IsNullOrEmpty(part4))
                    No4 = "4";
                if (!string.IsNullOrEmpty(part5))
                    No5 = "5";

                Dictionary<string, string> replaceDict = new Dictionary<string, string>();

                replaceDict.Add("#date#", billDate);
                replaceDict.Add("#pname#", strPName);
                replaceDict.Add("#bno#", billNo);

                replaceDict.Add("#sn1#", No1);
                replaceDict.Add("#sn2#", No2);
                replaceDict.Add("#sn3#", No3);
                replaceDict.Add("#sn4#", No4);
                replaceDict.Add("#sn5#", No5);

                replaceDict.Add("#pr1#", part1);
                replaceDict.Add("#pr2#", part2);
                replaceDict.Add("#pr3#", part3);
                replaceDict.Add("#pr4#", part4);
                replaceDict.Add("#pr5#", part5);

                replaceDict.Add("#amnt1#", amnt1);
                replaceDict.Add("#amnt2#", amnt2);
                replaceDict.Add("#amnt3#", amnt3);
                replaceDict.Add("#amnt4#", amnt4);
                replaceDict.Add("#amnt5#", amnt5);

                replaceDict.Add("#total#", tot);
                                
                return replaceDict;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("frmBill_GetReplaceDictionary()-->" + ex.Message);
                return null;
            }
        }


        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                string pname = txtPName.Text.Trim();
                string total = txtTotal.Text.Trim();
                string billNo = txtBillNo.Text.Trim();
                if (string.IsNullOrEmpty(pname) || string.IsNullOrEmpty(total))
                {
                    MessageBox.Show("Please enter patient name, particulars and bill amount.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                //initialize word object
                document = new Document();
                //close if the template is already opened
                if (GloabalFunctions.closeOpenedWord(GloabalFunctions.BillTemplatePath))
                    System.Threading.Thread.Sleep(100);
                document.LoadFromFile(GloabalFunctions.BillTemplatePath);
                //get strings to replace
                Dictionary<string, string> dictReplace = GetReplaceDictionary();
                //Replace text
                foreach (KeyValuePair<string, string> kvp in dictReplace)
                {
                    document.Replace(kvp.Key, kvp.Value, true, true);
                }
                //Save doc file.

                //UncPath = Directory.GetParent(UncPath).ToString();

                if (!Directory.Exists(UncPath))
                    Directory.CreateDirectory(UncPath);

                string docxPath = UncPath + "\\" + pname + "_" + billNo + ".docx";
                if (File.Exists(docxPath))
                {
                    //DialogResult res = MessageBox.Show("Patient file already exists with name " + docxPath + ".\r\n" + "Click Yes to override No to save another file.", "GPApps :: PMS", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    //if (res == DialogResult.Yes)
                    //{
                    //    if (closeOpenedWord(docxPath))
                    //        System.Threading.Thread.Sleep(100);

                    //    File.Delete(docxPath);
                    //}
                    //else if (res == DialogResult.No)
                    //{
                    //    docxPath = UncPath + "\\" + strToDay + "\\" + strPName.Replace(".", "_") + "_1" + ".docx";
                    //    if (File.Exists(docxPath))
                    //        docxPath = UncPath + "\\" + strToDay + "\\" + strPName.Replace(".", "_") + "_2" + ".docx";
                    //    if (closeOpenedWord(docxPath))
                    //        System.Threading.Thread.Sleep(100);
                    //}
                    //else
                    //    return;
                }

                               
                document.SaveToFile(docxPath, FileFormat.Docx);
                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    string pdfPath = docxPath.Replace(".docx", ".pdf");
                //    //Convert to PDF
                //    document.SaveToFile(pdfPath, FileFormat.PDF);
                //}
                document.Close();

                int intBNo = Convert.ToInt32(billNo);
                Properties.Settings.Default.billNo = intBNo;
                Properties.Settings.Default.Save();
                intBNo += 1;
                if (intBNo < 999)
                    txtBillNo.Text = Convert.ToString(intBNo).PadLeft(4, '0');
                else
                    txtBillNo.Text = Convert.ToString(intBNo);


                if (MessageBox.Show("Bill details saved successfully. \r\n Do you want to give print?.", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    GloabalFunctions.printFile(docxPath);

                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    EmailNotification.eMailNotification(strPName, strEmail, pdfPath);
                //    //System.Threading.Thread.Sleep(100);
                //}

                clearControls();
            }
            catch (Exception ex)
            {
               GloabalFunctions.WriteLog("btnBillPrint_Click()-->" + ex.Message);
            }
        }

        private void btnClear2_Click(object sender, EventArgs e)
        {
            clearControls();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                {
                    e.Handled = true;
                }

                //if (!string.IsNullOrEmpty(txtMonth.Text))
                //{
                //    string mm = txtMonth.Text.Trim() + "" + e.KeyChar.ToString();
                //    if (Convert.ToInt16(mm) > 11)
                //        e.Handled = true;
                //}
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        private void frmBill_Load(object sender, EventArgs e)
        {
            txtPName.Text = !string.IsNullOrEmpty(frmHome.patientNameForMail) ? frmHome.patientNameForMail.ToUpper() : string.Empty;
            string strBNo = "";
            int billNo = Properties.Settings.Default.billNo;
            billNo += 1;
            if (billNo < 999)
                strBNo = Convert.ToString(billNo).PadLeft(4,'0');

            txtBillNo.Text = strBNo;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                GloabalFunctions.BrowseFileToPrint(UncPath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("PFC-Browse_Click()-->" + ex.Message);
            }
        }
    }
}
