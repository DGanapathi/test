﻿namespace PMSApp
{
    partial class frmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHome));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.grbHeader = new System.Windows.Forms.GroupBox();
            this.lblCN = new System.Windows.Forms.Label();
            this.chkRandomColors = new System.Windows.Forms.CheckBox();
            this.lbtnColor = new System.Windows.Forms.LinkLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lblTime = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblClinic = new System.Windows.Forms.Label();
            this.grbRight = new System.Windows.Forms.GroupBox();
            this.btnEmail = new System.Windows.Forms.Button();
            this.btnClear2 = new System.Windows.Forms.Button();
            this.lblCount = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.dgPatients = new System.Windows.Forms.DataGridView();
            this.PatientName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grbSearch = new System.Windows.Forms.GroupBox();
            this.cmbMonth = new System.Windows.Forms.ComboBox();
            this.chkMonth = new System.Windows.Forms.CheckBox();
            this.txtDiagSearch = new System.Windows.Forms.TextBox();
            this.dtpSearchDate = new System.Windows.Forms.DateTimePicker();
            this.btnSearch = new System.Windows.Forms.Button();
            this.chkSearchAll = new System.Windows.Forms.CheckBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lbtnLabReports = new System.Windows.Forms.LinkLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbtnConfig = new System.Windows.Forms.LinkLabel();
            this.lblPN = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.lblSex = new System.Windows.Forms.Label();
            this.cmbSex = new System.Windows.Forms.ComboBox();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblBP = new System.Windows.Forms.Label();
            this.lblTemparature = new System.Windows.Forms.Label();
            this.lblPulse = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.grbRx = new System.Windows.Forms.GroupBox();
            this.txtRx = new System.Windows.Forms.TextBox();
            this.grbCO = new System.Windows.Forms.GroupBox();
            this.txtCO = new System.Windows.Forms.TextBox();
            this.lblCont = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblHeight = new System.Windows.Forms.Label();
            this.txtMonth = new System.Windows.Forms.TextBox();
            this.txtMedicineSearch = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSymptoms = new System.Windows.Forms.TextBox();
            this.btnAddSymptom = new System.Windows.Forms.Button();
            this.txtOccupation = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPulse = new System.Windows.Forms.TextBox();
            this.txtBP = new System.Windows.Forms.TextBox();
            this.txtTemparature = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.lblYrs = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblKgs = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtRR = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBMI = new System.Windows.Forms.TextBox();
            this.btnBill = new System.Windows.Forms.Button();
            this.txtDays = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnMCert = new System.Windows.Forms.Button();
            this.grbLeft = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDiagnosis = new System.Windows.Forms.TextBox();
            this.chkReVisit = new System.Windows.Forms.CheckBox();
            this.txtUnits = new System.Windows.Forms.TextBox();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.btnVaccination = new System.Windows.Forms.Button();
            this.btnMFC = new System.Windows.Forms.Button();
            this.btnInvestigations = new System.Windows.Forms.Button();
            this.grbMain = new System.Windows.Forms.GroupBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.chkA4 = new System.Windows.Forms.CheckBox();
            this.grbHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grbRight.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPatients)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.grbSearch.SuspendLayout();
            this.grbRx.SuspendLayout();
            this.grbCO.SuspendLayout();
            this.grbLeft.SuspendLayout();
            this.grbMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbHeader
            // 
            this.grbHeader.Controls.Add(this.lblCN);
            this.grbHeader.Controls.Add(this.chkRandomColors);
            this.grbHeader.Controls.Add(this.lbtnColor);
            this.grbHeader.Controls.Add(this.pictureBox3);
            this.grbHeader.Controls.Add(this.lblTime);
            this.grbHeader.Controls.Add(this.pictureBox2);
            this.grbHeader.Controls.Add(this.pictureBox1);
            this.grbHeader.Controls.Add(this.lblClinic);
            this.grbHeader.Location = new System.Drawing.Point(1, 2);
            this.grbHeader.Name = "grbHeader";
            this.grbHeader.Size = new System.Drawing.Size(920, 97);
            this.grbHeader.TabIndex = 0;
            this.grbHeader.TabStop = false;
            // 
            // lblCN
            // 
            this.lblCN.AutoSize = true;
            this.lblCN.ForeColor = System.Drawing.Color.White;
            this.lblCN.Location = new System.Drawing.Point(533, 11);
            this.lblCN.Name = "lblCN";
            this.lblCN.Size = new System.Drawing.Size(0, 13);
            this.lblCN.TabIndex = 64;
            // 
            // chkRandomColors
            // 
            this.chkRandomColors.AutoSize = true;
            this.chkRandomColors.Location = new System.Drawing.Point(657, 9);
            this.chkRandomColors.Name = "chkRandomColors";
            this.chkRandomColors.Size = new System.Drawing.Size(15, 14);
            this.chkRandomColors.TabIndex = 64;
            this.toolTip1.SetToolTip(this.chkRandomColors, "Check this for random color change");
            this.chkRandomColors.UseVisualStyleBackColor = true;
            this.chkRandomColors.CheckedChanged += new System.EventHandler(this.chkRandomColors_CheckedChanged);
            // 
            // lbtnColor
            // 
            this.lbtnColor.AutoSize = true;
            this.lbtnColor.Location = new System.Drawing.Point(671, 9);
            this.lbtnColor.Name = "lbtnColor";
            this.lbtnColor.Size = new System.Drawing.Size(59, 13);
            this.lbtnColor.TabIndex = 5;
            this.lbtnColor.TabStop = true;
            this.lbtnColor.Text = "UI Settings";
            this.lbtnColor.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbtnColor_LinkClicked);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(819, 8);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(98, 88);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // lblTime
            // 
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTime.Location = new System.Drawing.Point(520, 76);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(210, 15);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "lblTime";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(734, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(98, 88);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PMSApp.Properties.Resources.PMSEmail7;
            this.pictureBox1.Location = new System.Drawing.Point(3, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(115, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lblClinic
            // 
            this.lblClinic.AutoSize = true;
            this.lblClinic.Font = new System.Drawing.Font("Microsoft Sans Serif", 45F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClinic.ForeColor = System.Drawing.Color.Red;
            this.lblClinic.Location = new System.Drawing.Point(115, 14);
            this.lblClinic.Name = "lblClinic";
            this.lblClinic.Size = new System.Drawing.Size(622, 69);
            this.lblClinic.TabIndex = 0;
            this.lblClinic.Text = "Sri Sai Kalpana Clinic";
            // 
            // grbRight
            // 
            this.grbRight.Controls.Add(this.btnEmail);
            this.grbRight.Controls.Add(this.btnClear2);
            this.grbRight.Controls.Add(this.lblCount);
            this.grbRight.Controls.Add(this.btnDelete);
            this.grbRight.Controls.Add(this.btnEdit);
            this.grbRight.Controls.Add(this.btnOpen);
            this.grbRight.Controls.Add(this.btnPrint);
            this.grbRight.Controls.Add(this.dgPatients);
            this.grbRight.Controls.Add(this.grbSearch);
            this.grbRight.Location = new System.Drawing.Point(518, 92);
            this.grbRight.Name = "grbRight";
            this.grbRight.Size = new System.Drawing.Size(402, 557);
            this.grbRight.TabIndex = 2;
            this.grbRight.TabStop = false;
            // 
            // btnEmail
            // 
            this.btnEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEmail.Enabled = false;
            this.btnEmail.Image = global::PMSApp.Properties.Resources.email_16;
            this.btnEmail.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnEmail.Location = new System.Drawing.Point(267, 528);
            this.btnEmail.Name = "btnEmail";
            this.btnEmail.Size = new System.Drawing.Size(62, 27);
            this.btnEmail.TabIndex = 54;
            this.btnEmail.Text = "Mail";
            this.btnEmail.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEmail.UseVisualStyleBackColor = true;
            this.btnEmail.Click += new System.EventHandler(this.btnEmail_Click);
            // 
            // btnClear2
            // 
            this.btnClear2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClear2.Image = global::PMSApp.Properties.Resources.Cleaner_16x16;
            this.btnClear2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear2.Location = new System.Drawing.Point(333, 528);
            this.btnClear2.Name = "btnClear2";
            this.btnClear2.Size = new System.Drawing.Size(62, 27);
            this.btnClear2.TabIndex = 55;
            this.btnClear2.Text = "Clear";
            this.btnClear2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear2.UseVisualStyleBackColor = true;
            this.btnClear2.Click += new System.EventHandler(this.btnClear2_Click);
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.ForeColor = System.Drawing.Color.Red;
            this.lblCount.Location = new System.Drawing.Point(6, 72);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(60, 15);
            this.lblCount.TabIndex = 25;
            this.lblCount.Text = "lblCount";
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.Enabled = false;
            this.btnDelete.Image = global::PMSApp.Properties.Resources.Delete_16x16;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnDelete.Location = new System.Drawing.Point(200, 528);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(62, 27);
            this.btnDelete.TabIndex = 53;
            this.btnDelete.Text = "Delete";
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEdit.Enabled = false;
            this.btnEdit.Image = global::PMSApp.Properties.Resources.Edit20x20;
            this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.Location = new System.Drawing.Point(71, 528);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(62, 27);
            this.btnEdit.TabIndex = 51;
            this.btnEdit.Text = "Edit";
            this.btnEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnOpen.Enabled = false;
            this.btnOpen.Image = ((System.Drawing.Image)(resources.GetObject("btnOpen.Image")));
            this.btnOpen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOpen.Location = new System.Drawing.Point(5, 528);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(62, 27);
            this.btnOpen.TabIndex = 50;
            this.btnOpen.Text = "Open";
            this.btnOpen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPrint.Enabled = false;
            this.btnPrint.Image = global::PMSApp.Properties.Resources.print18;
            this.btnPrint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPrint.Location = new System.Drawing.Point(136, 528);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(62, 27);
            this.btnPrint.TabIndex = 52;
            this.btnPrint.Text = "Print";
            this.btnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // dgPatients
            // 
            this.dgPatients.AllowUserToAddRows = false;
            this.dgPatients.AllowUserToDeleteRows = false;
            this.dgPatients.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgPatients.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPatients.BackgroundColor = System.Drawing.Color.Lavender;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPatients.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgPatients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPatients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PatientName,
            this.FilePath});
            this.dgPatients.ContextMenuStrip = this.contextMenuStrip1;
            this.dgPatients.Location = new System.Drawing.Point(4, 91);
            this.dgPatients.MultiSelect = false;
            this.dgPatients.Name = "dgPatients";
            this.dgPatients.ReadOnly = true;
            this.dgPatients.RowHeadersVisible = false;
            this.dgPatients.RowHeadersWidth = 15;
            this.dgPatients.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgPatients.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgPatients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPatients.Size = new System.Drawing.Size(394, 436);
            this.dgPatients.TabIndex = 49;
            this.dgPatients.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPatients_CellClick);
            this.dgPatients.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPatients_CellDoubleClick);
            this.dgPatients.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgPatients_CellMouseDown);
            this.dgPatients.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgPatients_ColumnHeaderMouseClick);
            this.dgPatients.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgPatients_MouseDown);
            // 
            // PatientName
            // 
            this.PatientName.DataPropertyName = "PatientName";
            this.PatientName.FillWeight = 65.98985F;
            this.PatientName.HeaderText = "Patient Name";
            this.PatientName.MinimumWidth = 20;
            this.PatientName.Name = "PatientName";
            this.PatientName.ReadOnly = true;
            this.PatientName.ToolTipText = "PatientName";
            // 
            // FilePath
            // 
            this.FilePath.DataPropertyName = "FilePath";
            this.FilePath.FillWeight = 134.0102F;
            this.FilePath.HeaderText = "File Path";
            this.FilePath.MinimumWidth = 20;
            this.FilePath.Name = "FilePath";
            this.FilePath.ReadOnly = true;
            this.FilePath.ToolTipText = "FilePath";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.printToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(108, 70);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Image = global::PMSApp.Properties.Resources.open_file_icon_16x16;
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Image = global::PMSApp.Properties.Resources.print18;
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Image = global::PMSApp.Properties.Resources.Delete_16x16;
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // grbSearch
            // 
            this.grbSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbSearch.BackColor = System.Drawing.Color.Transparent;
            this.grbSearch.Controls.Add(this.cmbMonth);
            this.grbSearch.Controls.Add(this.chkMonth);
            this.grbSearch.Controls.Add(this.txtDiagSearch);
            this.grbSearch.Controls.Add(this.dtpSearchDate);
            this.grbSearch.Controls.Add(this.btnSearch);
            this.grbSearch.Controls.Add(this.chkSearchAll);
            this.grbSearch.Controls.Add(this.txtSearch);
            this.grbSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSearch.ForeColor = System.Drawing.Color.Blue;
            this.grbSearch.Location = new System.Drawing.Point(3, 6);
            this.grbSearch.Name = "grbSearch";
            this.grbSearch.Size = new System.Drawing.Size(395, 66);
            this.grbSearch.TabIndex = 42;
            this.grbSearch.TabStop = false;
            this.grbSearch.Text = "Search";
            // 
            // cmbMonth
            // 
            this.cmbMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMonth.Enabled = false;
            this.cmbMonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMonth.FormattingEnabled = true;
            this.cmbMonth.Items.AddRange(new object[] {
            "-Month-",
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec"});
            this.cmbMonth.Location = new System.Drawing.Point(114, 39);
            this.cmbMonth.Name = "cmbMonth";
            this.cmbMonth.Size = new System.Drawing.Size(66, 24);
            this.cmbMonth.TabIndex = 65;
            this.cmbMonth.SelectedIndexChanged += new System.EventHandler(this.cmbMonth_SelectedIndexChanged);
            // 
            // chkMonth
            // 
            this.chkMonth.AutoSize = true;
            this.chkMonth.Location = new System.Drawing.Point(99, 46);
            this.chkMonth.Name = "chkMonth";
            this.chkMonth.Size = new System.Drawing.Size(15, 14);
            this.chkMonth.TabIndex = 66;
            this.toolTip1.SetToolTip(this.chkMonth, "Search based on month & Clinical Diagnosis\r\nIf Search All selected then month wil" +
        "l be disabled.");
            this.chkMonth.UseVisualStyleBackColor = true;
            this.chkMonth.CheckedChanged += new System.EventHandler(this.chkMonth_CheckedChanged);
            // 
            // txtDiagSearch
            // 
            this.txtDiagSearch.Enabled = false;
            this.txtDiagSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiagSearch.Location = new System.Drawing.Point(182, 39);
            this.txtDiagSearch.MaxLength = 0;
            this.txtDiagSearch.Name = "txtDiagSearch";
            this.txtDiagSearch.Size = new System.Drawing.Size(206, 22);
            this.txtDiagSearch.TabIndex = 65;
            this.txtDiagSearch.TextChanged += new System.EventHandler(this.SetFirstCharUpper);
            // 
            // dtpSearchDate
            // 
            this.dtpSearchDate.CustomFormat = "dd/MM/yyyy";
            this.dtpSearchDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpSearchDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSearchDate.Location = new System.Drawing.Point(6, 15);
            this.dtpSearchDate.Name = "dtpSearchDate";
            this.dtpSearchDate.Size = new System.Drawing.Size(104, 22);
            this.dtpSearchDate.TabIndex = 43;
            this.dtpSearchDate.CloseUp += new System.EventHandler(this.dtpSearchDate_CloseUp);
            this.dtpSearchDate.ValueChanged += new System.EventHandler(this.dtpSearchDate_ValueChanged);
            this.dtpSearchDate.DropDown += new System.EventHandler(this.dtpSearchDate_DropDown);
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.BackColor = System.Drawing.Color.Teal;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.Location = new System.Drawing.Point(365, 14);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(25, 22);
            this.btnSearch.TabIndex = 45;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // chkSearchAll
            // 
            this.chkSearchAll.AutoSize = true;
            this.chkSearchAll.BackColor = System.Drawing.Color.Transparent;
            this.chkSearchAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSearchAll.Location = new System.Drawing.Point(5, 41);
            this.chkSearchAll.Name = "chkSearchAll";
            this.chkSearchAll.Size = new System.Drawing.Size(91, 19);
            this.chkSearchAll.TabIndex = 46;
            this.chkSearchAll.Text = "Search All";
            this.toolTip1.SetToolTip(this.chkSearchAll, "Search based on Patient Name, Clinical Diagnosis in entire data.");
            this.chkSearchAll.UseVisualStyleBackColor = false;
            this.chkSearchAll.CheckedChanged += new System.EventHandler(this.chkSearchAll_CheckedChanged);
            // 
            // txtSearch
            // 
            this.txtSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(113, 14);
            this.txtSearch.MaxLength = 50;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(253, 22);
            this.txtSearch.TabIndex = 44;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // lbtnLabReports
            // 
            this.lbtnLabReports.AutoSize = true;
            this.lbtnLabReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtnLabReports.Location = new System.Drawing.Point(437, 85);
            this.lbtnLabReports.Name = "lbtnLabReports";
            this.lbtnLabReports.Size = new System.Drawing.Size(76, 13);
            this.lbtnLabReports.TabIndex = 48;
            this.lbtnLabReports.TabStop = true;
            this.lbtnLabReports.Text = "Lab Reports";
            this.lbtnLabReports.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbtnLabReports_LinkClicked);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(424, 105);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 15);
            this.label11.TabIndex = 55;
            this.label11.Text = "RR";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(327, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 15);
            this.label12.TabIndex = 58;
            this.label12.Text = "BMI";
            // 
            // lbtnConfig
            // 
            this.lbtnConfig.AutoSize = true;
            this.lbtnConfig.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtnConfig.Location = new System.Drawing.Point(451, 68);
            this.lbtnConfig.Name = "lbtnConfig";
            this.lbtnConfig.Size = new System.Drawing.Size(43, 13);
            this.lbtnConfig.TabIndex = 45;
            this.lbtnConfig.TabStop = true;
            this.lbtnConfig.Text = "Config";
            this.lbtnConfig.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbtnConfig_LinkClicked);
            // 
            // lblPN
            // 
            this.lblPN.AutoSize = true;
            this.lblPN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPN.Location = new System.Drawing.Point(4, 17);
            this.lblPN.Name = "lblPN";
            this.lblPN.Size = new System.Drawing.Size(94, 15);
            this.lblPN.TabIndex = 17;
            this.lblPN.Text = "Patient Name";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAge.Location = new System.Drawing.Point(327, 17);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(31, 15);
            this.lblAge.TabIndex = 18;
            this.lblAge.Text = "Age";
            // 
            // txtPName
            // 
            this.txtPName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPName.Location = new System.Drawing.Point(97, 15);
            this.txtPName.MaxLength = 50;
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(224, 22);
            this.txtPName.TabIndex = 0;
            // 
            // lblSex
            // 
            this.lblSex.AutoSize = true;
            this.lblSex.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSex.Location = new System.Drawing.Point(219, 48);
            this.lblSex.Name = "lblSex";
            this.lblSex.Size = new System.Drawing.Size(31, 15);
            this.lblSex.TabIndex = 21;
            this.lblSex.Text = "Sex";
            // 
            // cmbSex
            // 
            this.cmbSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSex.FormattingEnabled = true;
            this.cmbSex.Items.AddRange(new object[] {
            "- Select -",
            "Female",
            "Male",
            "Trans"});
            this.cmbSex.Location = new System.Drawing.Point(252, 43);
            this.cmbSex.Name = "cmbSex";
            this.cmbSex.Size = new System.Drawing.Size(69, 24);
            this.cmbSex.TabIndex = 5;
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeight.Location = new System.Drawing.Point(327, 48);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(23, 15);
            this.lblWeight.TabIndex = 23;
            this.lblWeight.Text = "Wt";
            // 
            // lblBP
            // 
            this.lblBP.AutoSize = true;
            this.lblBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBP.Location = new System.Drawing.Point(198, 105);
            this.lblBP.Name = "lblBP";
            this.lblBP.Size = new System.Drawing.Size(25, 15);
            this.lblBP.TabIndex = 25;
            this.lblBP.Text = "BP";
            // 
            // lblTemparature
            // 
            this.lblTemparature.AutoSize = true;
            this.lblTemparature.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemparature.Location = new System.Drawing.Point(4, 105);
            this.lblTemparature.Name = "lblTemparature";
            this.lblTemparature.Size = new System.Drawing.Size(89, 15);
            this.lblTemparature.TabIndex = 26;
            this.lblTemparature.Text = "Temparature";
            // 
            // lblPulse
            // 
            this.lblPulse.AutoSize = true;
            this.lblPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPulse.Location = new System.Drawing.Point(327, 105);
            this.lblPulse.Name = "lblPulse";
            this.lblPulse.Size = new System.Drawing.Size(26, 15);
            this.lblPulse.TabIndex = 27;
            this.lblPulse.Text = "PR";
            // 
            // txtContact
            // 
            this.txtContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContact.Location = new System.Drawing.Point(97, 43);
            this.txtContact.MaxLength = 10;
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(115, 22);
            this.txtContact.TabIndex = 4;
            this.txtContact.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAge_KeyPress);
            // 
            // grbRx
            // 
            this.grbRx.Controls.Add(this.txtRx);
            this.grbRx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbRx.ForeColor = System.Drawing.Color.MediumBlue;
            this.grbRx.Location = new System.Drawing.Point(5, 373);
            this.grbRx.Name = "grbRx";
            this.grbRx.Size = new System.Drawing.Size(510, 154);
            this.grbRx.TabIndex = 29;
            this.grbRx.TabStop = false;
            this.grbRx.Text = "Rx";
            // 
            // txtRx
            // 
            this.txtRx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRx.Location = new System.Drawing.Point(3, 15);
            this.txtRx.MaxLength = 3000;
            this.txtRx.Multiline = true;
            this.txtRx.Name = "txtRx";
            this.txtRx.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRx.Size = new System.Drawing.Size(504, 141);
            this.txtRx.TabIndex = 30;
            // 
            // grbCO
            // 
            this.grbCO.Controls.Add(this.txtCO);
            this.grbCO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbCO.ForeColor = System.Drawing.Color.MediumBlue;
            this.grbCO.Location = new System.Drawing.Point(5, 197);
            this.grbCO.Name = "grbCO";
            this.grbCO.Size = new System.Drawing.Size(510, 159);
            this.grbCO.TabIndex = 25;
            this.grbCO.TabStop = false;
            this.grbCO.Text = "C/O";
            // 
            // txtCO
            // 
            this.txtCO.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCO.Location = new System.Drawing.Point(3, 15);
            this.txtCO.MaxLength = 3000;
            this.txtCO.Multiline = true;
            this.txtCO.Name = "txtCO";
            this.txtCO.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCO.Size = new System.Drawing.Size(504, 142);
            this.txtCO.TabIndex = 26;
            // 
            // lblCont
            // 
            this.lblCont.AutoSize = true;
            this.lblCont.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCont.Location = new System.Drawing.Point(4, 48);
            this.lblCont.Name = "lblCont";
            this.lblCont.Size = new System.Drawing.Size(55, 15);
            this.lblCont.TabIndex = 31;
            this.lblCont.Text = "Contact";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(4, 75);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(58, 15);
            this.lblAddress.TabIndex = 33;
            this.lblAddress.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(97, 72);
            this.txtAddress.MaxLength = 100;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(224, 22);
            this.txtAddress.TabIndex = 8;
            this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_TextChanged);
            // 
            // txtAge
            // 
            this.txtAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAge.Location = new System.Drawing.Point(358, 15);
            this.txtAge.MaxLength = 3;
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(52, 22);
            this.txtAge.TabIndex = 1;
            this.txtAge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAge_KeyPress);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(4, 530);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(57, 27);
            this.btnSave.TabIndex = 31;
            this.btnSave.Text = "Save";
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClear.Image = global::PMSApp.Properties.Resources.Cleaner_16x16;
            this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.Location = new System.Drawing.Point(68, 530);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(57, 27);
            this.btnClear.TabIndex = 32;
            this.btnClear.Text = "Clear";
            this.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClose.Image = global::PMSApp.Properties.Resources.Close_16x16;
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(132, 530);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(57, 27);
            this.btnClose.TabIndex = 33;
            this.btnClose.Text = "Close";
            this.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(39, 361);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 15);
            this.label1.TabIndex = 39;
            this.label1.Text = "Medicine";
            // 
            // btnAdd
            // 
            this.btnAdd.Image = global::PMSApp.Properties.Resources.add;
            this.btnAdd.Location = new System.Drawing.Point(492, 358);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(24, 23);
            this.btnAdd.TabIndex = 28;
            this.btnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeight.Location = new System.Drawing.Point(426, 48);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(21, 15);
            this.lblHeight.TabIndex = 42;
            this.lblHeight.Text = "Ht";
            // 
            // txtMonth
            // 
            this.txtMonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonth.Location = new System.Drawing.Point(410, 15);
            this.txtMonth.MaxLength = 2;
            this.txtMonth.Name = "txtMonth";
            this.txtMonth.Size = new System.Drawing.Size(52, 22);
            this.txtMonth.TabIndex = 2;
            this.txtMonth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMonth_KeyPress);
            // 
            // txtMedicineSearch
            // 
            this.txtMedicineSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedicineSearch.Location = new System.Drawing.Point(107, 358);
            this.txtMedicineSearch.Name = "txtMedicineSearch";
            this.txtMedicineSearch.Size = new System.Drawing.Size(386, 22);
            this.txtMedicineSearch.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(4, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 15);
            this.label7.TabIndex = 49;
            this.label7.Text = "Symptoms";
            // 
            // txtSymptoms
            // 
            this.txtSymptoms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSymptoms.Location = new System.Drawing.Point(77, 180);
            this.txtSymptoms.Name = "txtSymptoms";
            this.txtSymptoms.Size = new System.Drawing.Size(307, 22);
            this.txtSymptoms.TabIndex = 20;
            // 
            // btnAddSymptom
            // 
            this.btnAddSymptom.Image = global::PMSApp.Properties.Resources.add;
            this.btnAddSymptom.Location = new System.Drawing.Point(493, 180);
            this.btnAddSymptom.Name = "btnAddSymptom";
            this.btnAddSymptom.Size = new System.Drawing.Size(24, 23);
            this.btnAddSymptom.TabIndex = 23;
            this.btnAddSymptom.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAddSymptom.UseVisualStyleBackColor = true;
            this.btnAddSymptom.Click += new System.EventHandler(this.btnAddSymptom_Click);
            // 
            // txtOccupation
            // 
            this.txtOccupation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOccupation.Location = new System.Drawing.Point(97, 129);
            this.txtOccupation.MaxLength = 100;
            this.txtOccupation.Name = "txtOccupation";
            this.txtOccupation.Size = new System.Drawing.Size(136, 22);
            this.txtOccupation.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 131);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 15);
            this.label8.TabIndex = 51;
            this.label8.Text = "Occupation";
            // 
            // txtPulse
            // 
            this.txtPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPulse.Location = new System.Drawing.Point(358, 101);
            this.txtPulse.MaxLength = 6;
            this.txtPulse.Name = "txtPulse";
            this.txtPulse.Size = new System.Drawing.Size(66, 22);
            this.txtPulse.TabIndex = 12;
            this.txtPulse.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAge_KeyPress);
            // 
            // txtBP
            // 
            this.txtBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBP.Location = new System.Drawing.Point(225, 101);
            this.txtBP.MaxLength = 7;
            this.txtBP.Name = "txtBP";
            this.txtBP.Size = new System.Drawing.Size(96, 22);
            this.txtBP.TabIndex = 11;
            this.txtBP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBP_KeyPress);
            // 
            // txtTemparature
            // 
            this.txtTemparature.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTemparature.Location = new System.Drawing.Point(97, 101);
            this.txtTemparature.MaxLength = 6;
            this.txtTemparature.Name = "txtTemparature";
            this.txtTemparature.Size = new System.Drawing.Size(89, 22);
            this.txtTemparature.TabIndex = 10;
            this.txtTemparature.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAge_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(236, 132);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 15);
            this.label9.TabIndex = 53;
            this.label9.Text = "Email";
            // 
            // txtHeight
            // 
            this.txtHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHeight.Location = new System.Drawing.Point(448, 44);
            this.txtHeight.MaxLength = 5;
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(66, 22);
            this.txtHeight.TabIndex = 7;
            this.txtHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAge_KeyPress);
            // 
            // txtWeight
            // 
            this.txtWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeight.Location = new System.Drawing.Point(358, 43);
            this.txtWeight.MaxLength = 4;
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(66, 22);
            this.txtWeight.TabIndex = 6;
            this.txtWeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAge_KeyPress);
            // 
            // lblYrs
            // 
            this.lblYrs.AutoSize = true;
            this.lblYrs.BackColor = System.Drawing.Color.White;
            this.lblYrs.Location = new System.Drawing.Point(395, 20);
            this.lblYrs.Name = "lblYrs";
            this.lblYrs.Size = new System.Drawing.Size(14, 13);
            this.lblYrs.TabIndex = 35;
            this.lblYrs.Text = "Y";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(445, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 41;
            this.label2.Text = "M";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(165, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 13);
            this.label4.TabIndex = 45;
            this.label4.Text = "*F";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(281, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 47;
            this.label6.Text = "mmHg";
            // 
            // txtEmail
            // 
            this.txtEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(279, 129);
            this.txtEmail.MaxLength = 100;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(235, 22);
            this.txtEmail.TabIndex = 15;
            this.txtEmail.Validating += new System.ComponentModel.CancelEventHandler(this.txtEmail_Validating);
            // 
            // lblKgs
            // 
            this.lblKgs.AutoSize = true;
            this.lblKgs.BackColor = System.Drawing.Color.White;
            this.lblKgs.Location = new System.Drawing.Point(398, 48);
            this.lblKgs.Name = "lblKgs";
            this.lblKgs.Size = new System.Drawing.Size(25, 13);
            this.lblKgs.TabIndex = 36;
            this.lblKgs.Text = "Kgs";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(485, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 44;
            this.label3.Text = "CMs";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(399, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 46;
            this.label5.Text = "Min";
            // 
            // txtRR
            // 
            this.txtRR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRR.Location = new System.Drawing.Point(449, 101);
            this.txtRR.MaxLength = 5;
            this.txtRR.Name = "txtRR";
            this.txtRR.Size = new System.Drawing.Size(66, 22);
            this.txtRR.TabIndex = 13;
            this.txtRR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAge_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(490, 107);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 13);
            this.label10.TabIndex = 56;
            this.label10.Text = "Min";
            // 
            // txtBMI
            // 
            this.txtBMI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBMI.Location = new System.Drawing.Point(358, 72);
            this.txtBMI.MaxLength = 5;
            this.txtBMI.Name = "txtBMI";
            this.txtBMI.Size = new System.Drawing.Size(66, 22);
            this.txtBMI.TabIndex = 9;
            this.txtBMI.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAge_KeyPress);
            // 
            // btnBill
            // 
            this.btnBill.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBill.Image = global::PMSApp.Properties.Resources.cash;
            this.btnBill.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBill.Location = new System.Drawing.Point(196, 530);
            this.btnBill.Name = "btnBill";
            this.btnBill.Size = new System.Drawing.Size(57, 27);
            this.btnBill.TabIndex = 34;
            this.btnBill.Text = "Bill";
            this.btnBill.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnBill.UseVisualStyleBackColor = true;
            this.btnBill.Click += new System.EventHandler(this.btnBill_Click);
            // 
            // txtDays
            // 
            this.txtDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDays.Location = new System.Drawing.Point(462, 15);
            this.txtDays.MaxLength = 2;
            this.txtDays.Name = "txtDays";
            this.txtDays.Size = new System.Drawing.Size(52, 22);
            this.txtDays.TabIndex = 3;
            this.txtDays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMonth_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(496, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 13);
            this.label13.TabIndex = 61;
            this.label13.Text = "D";
            // 
            // btnMCert
            // 
            this.btnMCert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnMCert.Image = global::PMSApp.Properties.Resources.inv;
            this.btnMCert.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMCert.Location = new System.Drawing.Point(260, 530);
            this.btnMCert.Name = "btnMCert";
            this.btnMCert.Size = new System.Drawing.Size(57, 27);
            this.btnMCert.TabIndex = 35;
            this.btnMCert.Text = "MC";
            this.btnMCert.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMCert.UseVisualStyleBackColor = true;
            this.btnMCert.Click += new System.EventHandler(this.btnMCert_Click);
            // 
            // grbLeft
            // 
            this.grbLeft.Controls.Add(this.chkA4);
            this.grbLeft.Controls.Add(this.label14);
            this.grbLeft.Controls.Add(this.txtDiagnosis);
            this.grbLeft.Controls.Add(this.chkReVisit);
            this.grbLeft.Controls.Add(this.txtUnits);
            this.grbLeft.Controls.Add(this.txtValue);
            this.grbLeft.Controls.Add(this.btnVaccination);
            this.grbLeft.Controls.Add(this.btnMFC);
            this.grbLeft.Controls.Add(this.btnInvestigations);
            this.grbLeft.Controls.Add(this.btnMCert);
            this.grbLeft.Controls.Add(this.lbtnLabReports);
            this.grbLeft.Controls.Add(this.label13);
            this.grbLeft.Controls.Add(this.txtDays);
            this.grbLeft.Controls.Add(this.btnBill);
            this.grbLeft.Controls.Add(this.txtBMI);
            this.grbLeft.Controls.Add(this.label10);
            this.grbLeft.Controls.Add(this.txtRR);
            this.grbLeft.Controls.Add(this.label5);
            this.grbLeft.Controls.Add(this.label3);
            this.grbLeft.Controls.Add(this.lblKgs);
            this.grbLeft.Controls.Add(this.txtEmail);
            this.grbLeft.Controls.Add(this.label6);
            this.grbLeft.Controls.Add(this.label4);
            this.grbLeft.Controls.Add(this.label2);
            this.grbLeft.Controls.Add(this.lblYrs);
            this.grbLeft.Controls.Add(this.txtWeight);
            this.grbLeft.Controls.Add(this.txtHeight);
            this.grbLeft.Controls.Add(this.label9);
            this.grbLeft.Controls.Add(this.txtTemparature);
            this.grbLeft.Controls.Add(this.txtBP);
            this.grbLeft.Controls.Add(this.txtPulse);
            this.grbLeft.Controls.Add(this.label8);
            this.grbLeft.Controls.Add(this.txtOccupation);
            this.grbLeft.Controls.Add(this.btnAddSymptom);
            this.grbLeft.Controls.Add(this.txtSymptoms);
            this.grbLeft.Controls.Add(this.label7);
            this.grbLeft.Controls.Add(this.txtMedicineSearch);
            this.grbLeft.Controls.Add(this.txtMonth);
            this.grbLeft.Controls.Add(this.lblHeight);
            this.grbLeft.Controls.Add(this.btnAdd);
            this.grbLeft.Controls.Add(this.label1);
            this.grbLeft.Controls.Add(this.btnClose);
            this.grbLeft.Controls.Add(this.btnClear);
            this.grbLeft.Controls.Add(this.btnSave);
            this.grbLeft.Controls.Add(this.txtAge);
            this.grbLeft.Controls.Add(this.txtAddress);
            this.grbLeft.Controls.Add(this.lblAddress);
            this.grbLeft.Controls.Add(this.lblCont);
            this.grbLeft.Controls.Add(this.grbCO);
            this.grbLeft.Controls.Add(this.grbRx);
            this.grbLeft.Controls.Add(this.txtContact);
            this.grbLeft.Controls.Add(this.lblPulse);
            this.grbLeft.Controls.Add(this.lblTemparature);
            this.grbLeft.Controls.Add(this.lblBP);
            this.grbLeft.Controls.Add(this.lblWeight);
            this.grbLeft.Controls.Add(this.cmbSex);
            this.grbLeft.Controls.Add(this.lblSex);
            this.grbLeft.Controls.Add(this.txtPName);
            this.grbLeft.Controls.Add(this.lblAge);
            this.grbLeft.Controls.Add(this.lblPN);
            this.grbLeft.Controls.Add(this.label12);
            this.grbLeft.Controls.Add(this.label11);
            this.grbLeft.Controls.Add(this.lbtnConfig);
            this.grbLeft.Location = new System.Drawing.Point(1, 92);
            this.grbLeft.Name = "grbLeft";
            this.grbLeft.Size = new System.Drawing.Size(519, 559);
            this.grbLeft.TabIndex = 1;
            this.grbLeft.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(123, 158);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 15);
            this.label14.TabIndex = 64;
            this.label14.Text = "Cli. Diag.";
            // 
            // txtDiagnosis
            // 
            this.txtDiagnosis.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiagnosis.Location = new System.Drawing.Point(193, 155);
            this.txtDiagnosis.MaxLength = 0;
            this.txtDiagnosis.Name = "txtDiagnosis";
            this.txtDiagnosis.Size = new System.Drawing.Size(321, 22);
            this.txtDiagnosis.TabIndex = 16;
            this.txtDiagnosis.TextChanged += new System.EventHandler(this.SetFirstCharUpper);
            // 
            // chkReVisit
            // 
            this.chkReVisit.AutoSize = true;
            this.chkReVisit.BackColor = System.Drawing.Color.Transparent;
            this.chkReVisit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkReVisit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkReVisit.Location = new System.Drawing.Point(7, 157);
            this.chkReVisit.Name = "chkReVisit";
            this.chkReVisit.Size = new System.Drawing.Size(65, 17);
            this.chkReVisit.TabIndex = 62;
            this.chkReVisit.Text = "Revisit";
            this.chkReVisit.UseVisualStyleBackColor = false;
            // 
            // txtUnits
            // 
            this.txtUnits.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnits.Location = new System.Drawing.Point(427, 180);
            this.txtUnits.Name = "txtUnits";
            this.txtUnits.Size = new System.Drawing.Size(67, 22);
            this.txtUnits.TabIndex = 22;
            // 
            // txtValue
            // 
            this.txtValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValue.Location = new System.Drawing.Point(384, 180);
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(44, 22);
            this.txtValue.TabIndex = 21;
            // 
            // btnVaccination
            // 
            this.btnVaccination.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnVaccination.Image = global::PMSApp.Properties.Resources.vaccine;
            this.btnVaccination.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVaccination.Location = new System.Drawing.Point(452, 530);
            this.btnVaccination.Name = "btnVaccination";
            this.btnVaccination.Size = new System.Drawing.Size(57, 27);
            this.btnVaccination.TabIndex = 38;
            this.btnVaccination.Text = "VC";
            this.btnVaccination.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnVaccination.UseVisualStyleBackColor = true;
            this.btnVaccination.Click += new System.EventHandler(this.btnVaccination_Click);
            // 
            // btnMFC
            // 
            this.btnMFC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnMFC.Image = global::PMSApp.Properties.Resources.fitness;
            this.btnMFC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMFC.Location = new System.Drawing.Point(388, 530);
            this.btnMFC.Name = "btnMFC";
            this.btnMFC.Size = new System.Drawing.Size(57, 27);
            this.btnMFC.TabIndex = 37;
            this.btnMFC.Text = "PFC";
            this.btnMFC.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMFC.UseVisualStyleBackColor = true;
            this.btnMFC.Click += new System.EventHandler(this.btnMFC_Click);
            // 
            // btnInvestigations
            // 
            this.btnInvestigations.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnInvestigations.Image = global::PMSApp.Properties.Resources.microscope__3_;
            this.btnInvestigations.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInvestigations.Location = new System.Drawing.Point(324, 530);
            this.btnInvestigations.Name = "btnInvestigations";
            this.btnInvestigations.Size = new System.Drawing.Size(57, 27);
            this.btnInvestigations.TabIndex = 36;
            this.btnInvestigations.Text = "Lab";
            this.btnInvestigations.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnInvestigations.UseVisualStyleBackColor = true;
            this.btnInvestigations.Click += new System.EventHandler(this.btnInvestigations_Click);
            // 
            // grbMain
            // 
            this.grbMain.Controls.Add(this.grbHeader);
            this.grbMain.Controls.Add(this.grbLeft);
            this.grbMain.Controls.Add(this.grbRight);
            this.grbMain.Location = new System.Drawing.Point(-1, -6);
            this.grbMain.Name = "grbMain";
            this.grbMain.Size = new System.Drawing.Size(922, 653);
            this.grbMain.TabIndex = 63;
            this.grbMain.TabStop = false;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 100;
            this.toolTip1.AutoPopDelay = 6000;
            this.toolTip1.ForeColor = System.Drawing.Color.Maroon;
            this.toolTip1.InitialDelay = 100;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 20;
            // 
            // chkA4
            // 
            this.chkA4.AutoSize = true;
            this.chkA4.BackColor = System.Drawing.Color.Transparent;
            this.chkA4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkA4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkA4.Location = new System.Drawing.Point(73, 157);
            this.chkA4.Name = "chkA4";
            this.chkA4.Size = new System.Drawing.Size(41, 17);
            this.chkA4.TabIndex = 65;
            this.chkA4.Text = "A4";
            this.chkA4.UseVisualStyleBackColor = false;
            // 
            // frmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.BackgroundImage = global::PMSApp.Properties.Resources.topheader;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(920, 646);
            this.Controls.Add(this.grbMain);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(936, 682);
            this.Name = "frmHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GPApps :: PMS";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmHome_FormClosing);
            this.Load += new System.EventHandler(this.frmHome_Load);
            this.Resize += new System.EventHandler(this.frmHome_Resize);
            this.grbHeader.ResumeLayout(false);
            this.grbHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grbRight.ResumeLayout(false);
            this.grbRight.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPatients)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.grbSearch.ResumeLayout(false);
            this.grbSearch.PerformLayout();
            this.grbRx.ResumeLayout(false);
            this.grbRx.PerformLayout();
            this.grbCO.ResumeLayout(false);
            this.grbCO.PerformLayout();
            this.grbLeft.ResumeLayout(false);
            this.grbLeft.PerformLayout();
            this.grbMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbHeader;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblClinic;
        private System.Windows.Forms.GroupBox grbRight;
        private System.Windows.Forms.PictureBox pictureBox2;
        internal System.Windows.Forms.GroupBox grbSearch;
        internal System.Windows.Forms.DateTimePicker dtpSearchDate;
        internal System.Windows.Forms.Button btnSearch;
        internal System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridView dgPatients;
        internal System.Windows.Forms.Button btnDelete;
        internal System.Windows.Forms.Button btnEdit;
        internal System.Windows.Forms.Button btnOpen;
        internal System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblCount;
        internal System.Windows.Forms.Button btnClear2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.CheckBox chkSearchAll;
        internal System.Windows.Forms.Button btnEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn PatientName;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilePath;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.LinkLabel lbtnConfig;
        private System.Windows.Forms.Label lblPN;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.Label lblSex;
        private System.Windows.Forms.ComboBox cmbSex;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblBP;
        private System.Windows.Forms.Label lblTemparature;
        private System.Windows.Forms.Label lblPulse;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.GroupBox grbRx;
        private System.Windows.Forms.TextBox txtRx;
        private System.Windows.Forms.GroupBox grbCO;
        private System.Windows.Forms.TextBox txtCO;
        private System.Windows.Forms.Label lblCont;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtAge;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Button btnClear;
        internal System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.TextBox txtMonth;
        private System.Windows.Forms.TextBox txtMedicineSearch;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSymptoms;
        internal System.Windows.Forms.Button btnAddSymptom;
        private System.Windows.Forms.TextBox txtOccupation;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPulse;
        private System.Windows.Forms.TextBox txtBP;
        private System.Windows.Forms.TextBox txtTemparature;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.Label lblYrs;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblKgs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtRR;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtBMI;
        internal System.Windows.Forms.Button btnBill;
        private System.Windows.Forms.TextBox txtDays;
        private System.Windows.Forms.Label label13;
        internal System.Windows.Forms.Button btnMCert;
        private System.Windows.Forms.GroupBox grbLeft;
        private System.Windows.Forms.GroupBox grbMain;
        internal System.Windows.Forms.Button btnInvestigations;
        internal System.Windows.Forms.Button btnMFC;
        internal System.Windows.Forms.Button btnVaccination;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.LinkLabel lbtnColor;
        private System.Windows.Forms.CheckBox chkRandomColors;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblCN;
        private System.Windows.Forms.LinkLabel lbtnLabReports;
        private System.Windows.Forms.TextBox txtUnits;
        private System.Windows.Forms.TextBox txtValue;
        private System.Windows.Forms.CheckBox chkReVisit;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtDiagnosis;
        private System.Windows.Forms.TextBox txtDiagSearch;
        private System.Windows.Forms.ComboBox cmbMonth;
        private System.Windows.Forms.CheckBox chkMonth;
        private System.Windows.Forms.CheckBox chkA4;
    }
}