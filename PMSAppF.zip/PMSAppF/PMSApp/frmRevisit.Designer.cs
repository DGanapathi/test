﻿namespace PMSApp
{
    partial class frmRevisit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRevisit));
            this.btnAddSymptom = new System.Windows.Forms.Button();
            this.txtSymptoms = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMedicineSearch = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.grbCO = new System.Windows.Forms.GroupBox();
            this.txtCO = new System.Windows.Forms.TextBox();
            this.grbRx = new System.Windows.Forms.GroupBox();
            this.txtRx = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTemparature = new System.Windows.Forms.TextBox();
            this.txtBP = new System.Windows.Forms.TextBox();
            this.txtPulse = new System.Windows.Forms.TextBox();
            this.lblTemparature = new System.Windows.Forms.Label();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.lblPN = new System.Windows.Forms.Label();
            this.lblPulse = new System.Windows.Forms.Label();
            this.lblBP = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtUnits = new System.Windows.Forms.TextBox();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.grbCO.SuspendLayout();
            this.grbRx.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAddSymptom
            // 
            this.btnAddSymptom.Image = global::PMSApp.Properties.Resources.add;
            this.btnAddSymptom.Location = new System.Drawing.Point(470, 88);
            this.btnAddSymptom.Name = "btnAddSymptom";
            this.btnAddSymptom.Size = new System.Drawing.Size(24, 23);
            this.btnAddSymptom.TabIndex = 8;
            this.btnAddSymptom.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAddSymptom.UseVisualStyleBackColor = true;
            this.btnAddSymptom.Click += new System.EventHandler(this.btnAddSymptom_Click);
            // 
            // txtSymptoms
            // 
            this.txtSymptoms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSymptoms.Location = new System.Drawing.Point(48, 88);
            this.txtSymptoms.Name = "txtSymptoms";
            this.txtSymptoms.Size = new System.Drawing.Size(312, 22);
            this.txtSymptoms.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(-2, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 15);
            this.label7.TabIndex = 57;
            this.label7.Text = "Symp.";
            // 
            // txtMedicineSearch
            // 
            this.txtMedicineSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedicineSearch.Location = new System.Drawing.Point(86, 266);
            this.txtMedicineSearch.Name = "txtMedicineSearch";
            this.txtMedicineSearch.Size = new System.Drawing.Size(386, 22);
            this.txtMedicineSearch.TabIndex = 11;
            // 
            // btnAdd
            // 
            this.btnAdd.Image = global::PMSApp.Properties.Resources.add;
            this.btnAdd.Location = new System.Drawing.Point(471, 266);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(24, 23);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 269);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 15);
            this.label1.TabIndex = 56;
            this.label1.Text = "Medicine";
            // 
            // grbCO
            // 
            this.grbCO.BackColor = System.Drawing.Color.Transparent;
            this.grbCO.Controls.Add(this.txtCO);
            this.grbCO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbCO.ForeColor = System.Drawing.Color.MediumBlue;
            this.grbCO.Location = new System.Drawing.Point(1, 105);
            this.grbCO.Name = "grbCO";
            this.grbCO.Size = new System.Drawing.Size(494, 159);
            this.grbCO.TabIndex = 9;
            this.grbCO.TabStop = false;
            this.grbCO.Text = "C/O";
            // 
            // txtCO
            // 
            this.txtCO.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCO.Location = new System.Drawing.Point(3, 15);
            this.txtCO.MaxLength = 3000;
            this.txtCO.Multiline = true;
            this.txtCO.Name = "txtCO";
            this.txtCO.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCO.Size = new System.Drawing.Size(488, 142);
            this.txtCO.TabIndex = 10;
            // 
            // grbRx
            // 
            this.grbRx.BackColor = System.Drawing.Color.Transparent;
            this.grbRx.Controls.Add(this.txtRx);
            this.grbRx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbRx.ForeColor = System.Drawing.Color.MediumBlue;
            this.grbRx.Location = new System.Drawing.Point(1, 281);
            this.grbRx.Name = "grbRx";
            this.grbRx.Size = new System.Drawing.Size(495, 154);
            this.grbRx.TabIndex = 13;
            this.grbRx.TabStop = false;
            this.grbRx.Text = "Rx";
            // 
            // txtRx
            // 
            this.txtRx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRx.Location = new System.Drawing.Point(3, 15);
            this.txtRx.MaxLength = 3000;
            this.txtRx.Multiline = true;
            this.txtRx.Name = "txtRx";
            this.txtRx.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRx.Size = new System.Drawing.Size(489, 141);
            this.txtRx.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(394, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 65;
            this.label5.Text = "Min";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(276, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 66;
            this.label6.Text = "mmHg";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(160, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 13);
            this.label4.TabIndex = 64;
            this.label4.Text = "*F";
            // 
            // txtTemparature
            // 
            this.txtTemparature.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTemparature.Location = new System.Drawing.Point(92, 41);
            this.txtTemparature.MaxLength = 6;
            this.txtTemparature.Name = "txtTemparature";
            this.txtTemparature.Size = new System.Drawing.Size(89, 22);
            this.txtTemparature.TabIndex = 2;
            // 
            // txtBP
            // 
            this.txtBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBP.Location = new System.Drawing.Point(220, 41);
            this.txtBP.MaxLength = 7;
            this.txtBP.Name = "txtBP";
            this.txtBP.Size = new System.Drawing.Size(96, 22);
            this.txtBP.TabIndex = 3;
            // 
            // txtPulse
            // 
            this.txtPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPulse.Location = new System.Drawing.Point(353, 41);
            this.txtPulse.MaxLength = 6;
            this.txtPulse.Name = "txtPulse";
            this.txtPulse.Size = new System.Drawing.Size(66, 22);
            this.txtPulse.TabIndex = 4;
            // 
            // lblTemparature
            // 
            this.lblTemparature.AutoSize = true;
            this.lblTemparature.BackColor = System.Drawing.Color.Transparent;
            this.lblTemparature.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemparature.Location = new System.Drawing.Point(0, 44);
            this.lblTemparature.Name = "lblTemparature";
            this.lblTemparature.Size = new System.Drawing.Size(89, 15);
            this.lblTemparature.TabIndex = 63;
            this.lblTemparature.Text = "Temparature";
            // 
            // txtPName
            // 
            this.txtPName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPName.Location = new System.Drawing.Point(94, 7);
            this.txtPName.MaxLength = 50;
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(325, 22);
            this.txtPName.TabIndex = 1;
            // 
            // lblPN
            // 
            this.lblPN.AutoSize = true;
            this.lblPN.BackColor = System.Drawing.Color.Transparent;
            this.lblPN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPN.Location = new System.Drawing.Point(0, 9);
            this.lblPN.Name = "lblPN";
            this.lblPN.Size = new System.Drawing.Size(94, 15);
            this.lblPN.TabIndex = 62;
            this.lblPN.Text = "Patient Name";
            // 
            // lblPulse
            // 
            this.lblPulse.AutoSize = true;
            this.lblPulse.BackColor = System.Drawing.Color.Transparent;
            this.lblPulse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPulse.Location = new System.Drawing.Point(324, 46);
            this.lblPulse.Name = "lblPulse";
            this.lblPulse.Size = new System.Drawing.Size(26, 15);
            this.lblPulse.TabIndex = 68;
            this.lblPulse.Text = "PR";
            // 
            // lblBP
            // 
            this.lblBP.AutoSize = true;
            this.lblBP.BackColor = System.Drawing.Color.Transparent;
            this.lblBP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBP.Location = new System.Drawing.Point(195, 46);
            this.lblBP.Name = "lblBP";
            this.lblBP.Size = new System.Drawing.Size(25, 15);
            this.lblBP.TabIndex = 67;
            this.lblBP.Text = "BP";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClose.Image = global::PMSApp.Properties.Resources.Close_16x16;
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(132, 438);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(57, 27);
            this.btnClose.TabIndex = 17;
            this.btnClose.Text = "Close";
            this.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClear.Image = global::PMSApp.Properties.Resources.Cleaner_16x16;
            this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.Location = new System.Drawing.Point(68, 438);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(57, 27);
            this.btnClear.TabIndex = 16;
            this.btnClear.Text = "Clear";
            this.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(4, 438);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(57, 27);
            this.btnSave.TabIndex = 15;
            this.btnSave.Text = "Save";
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtUnits
            // 
            this.txtUnits.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnits.Location = new System.Drawing.Point(403, 88);
            this.txtUnits.Name = "txtUnits";
            this.txtUnits.Size = new System.Drawing.Size(67, 22);
            this.txtUnits.TabIndex = 7;
            // 
            // txtValue
            // 
            this.txtValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValue.Location = new System.Drawing.Point(360, 88);
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(44, 22);
            this.txtValue.TabIndex = 6;
            // 
            // frmRevisit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.BackgroundImage = global::PMSApp.Properties.Resources._11948;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(496, 476);
            this.Controls.Add(this.txtUnits);
            this.Controls.Add(this.txtValue);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblPulse);
            this.Controls.Add(this.lblBP);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTemparature);
            this.Controls.Add(this.txtBP);
            this.Controls.Add(this.txtPulse);
            this.Controls.Add(this.lblTemparature);
            this.Controls.Add(this.txtPName);
            this.Controls.Add(this.lblPN);
            this.Controls.Add(this.btnAddSymptom);
            this.Controls.Add(this.txtSymptoms);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtMedicineSearch);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grbCO);
            this.Controls.Add(this.grbRx);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRevisit";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PMS :: Revisit";
            this.Load += new System.EventHandler(this.frmRevisit_Load);
            this.grbCO.ResumeLayout(false);
            this.grbCO.PerformLayout();
            this.grbRx.ResumeLayout(false);
            this.grbRx.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnAddSymptom;
        private System.Windows.Forms.TextBox txtSymptoms;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMedicineSearch;
        internal System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grbCO;
        private System.Windows.Forms.TextBox txtCO;
        private System.Windows.Forms.GroupBox grbRx;
        private System.Windows.Forms.TextBox txtRx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTemparature;
        private System.Windows.Forms.TextBox txtBP;
        private System.Windows.Forms.TextBox txtPulse;
        private System.Windows.Forms.Label lblTemparature;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.Label lblPN;
        private System.Windows.Forms.Label lblPulse;
        private System.Windows.Forms.Label lblBP;
        internal System.Windows.Forms.Button btnClose;
        internal System.Windows.Forms.Button btnClear;
        internal System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtUnits;
        private System.Windows.Forms.TextBox txtValue;
    }
}