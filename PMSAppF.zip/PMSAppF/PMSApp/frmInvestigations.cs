﻿using Spire.Doc;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmInvestigations : Form
    {
        string UncPath = Directory.GetParent(System.Configuration.ConfigurationManager.AppSettings["FilesPath"]).ToString() + Path.DirectorySeparatorChar + "PatientInvestig";
        //word document object
        Document document = null;

        public frmInvestigations()
        {
            InitializeComponent();
        }
        private AutoCompleteStringCollection getAutoCompleteCollection(string path)
        {
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            try
            {
                string connString = "";
                if (!File.Exists(path))
                {
                    GloabalFunctions.WriteLog("File not exists: " + path);
                    return null;
                }

                if (GloabalFunctions.closeOpenedExcel(path))
                    System.Threading.Thread.Sleep(100);
                string strFileType = Path.GetExtension(path).ToLower();
                string sheetName = "";
                if (strFileType.Trim() == ".xls")
                {
                    //connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=Excel 8.0;";
                }
                else if (strFileType.Trim() == ".xlsx")
                {
                    //connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 12.0;";
                }

                ////Get the name of the First Sheet.
                //using (OleDbConnection con = new OleDbConnection(connString))
                //{
                //    using (OleDbCommand cmd = new OleDbCommand())
                //    {
                //        cmd.Connection = con;
                //        con.Open();
                //        DataTable dtExcelSchema = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                //        sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                //        con.Close();
                //    }
                //}

                sheetName = "Investigations$";
                //Read Data from the First Sheet.
                using (OleDbConnection con = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmd = new OleDbCommand())
                    {
                        using (OleDbDataAdapter oda = new OleDbDataAdapter())
                        {
                            //string query = "SELECT [UserName],[Education],[Location] FROM [Sheet1$]";
                            DataTable dt = new DataTable();
                            cmd.CommandText = "SELECT * From [" + sheetName + "]";
                            cmd.Connection = con;
                            con.Open();
                            oda.SelectCommand = cmd;
                            oda.Fill(dt);
                            //DataSet ds = new DataSet();
                            //da.Fill(ds);
                            con.Close();

                            if (dt != null && dt.Rows.Count > 0)
                            {
                                //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (dr[0] != DBNull.Value)
                                        MyCollection.Add(dr[0].ToString().Trim());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getAutoCompleteCollection()-->" + ex.Message);
                return null;
            }
            return MyCollection;
        }

        private void getClinicalDiagnosis()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.ClinicalDiagnosisExcelPath))
                {
                    MessageBox.Show("Clinical Diagnosis list: " + Path.GetFileName(GloabalFunctions.ClinicalDiagnosisExcelPath) + " not exists" + "\r\n" + "Please place Clinical Diagnosis list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.ClinicalDiagnosisExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.ClinicalDiagnosisExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtChliDiagnosis.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtChliDiagnosis.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtChliDiagnosis.AutoCompleteCustomSource = MyCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getClinicalDiagnosis()-->" + ex.Message);
            }
        }

        private void getRequiredInvestigations()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.InvestigationsExcelPath))
                {
                    MessageBox.Show("Investigations list: " + Path.GetFileName(GloabalFunctions.InvestigationsExcelPath) + " not exists" + "\r\n" + "Please place Investigations list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.InvestigationsExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.InvestigationsExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtAddInv.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtAddInv.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtAddInv.AutoCompleteCustomSource = MyCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getRequiredInvestigations()-->" + ex.Message);
            }
        }
        private void frmInvestigations_Load(object sender, EventArgs e)
        {
            txtPName.Text = !string.IsNullOrEmpty(frmHome.patientNameForMail) ? frmHome.patientNameForMail.ToUpper() : string.Empty;
            getRequiredInvestigations();
            getClinicalDiagnosis();
            cmbSex.SelectedIndex = 0;
        }
        private void btnAddSymptom_Click(object sender, EventArgs e)
        {
            string strTxt = txtAddInv.Text.Trim();
            string bullet = "\u2022";
                        
            if (!string.IsNullOrEmpty(strTxt))
            {
                if (strTxt.Length == 1)
                    strTxt = char.ToUpper(strTxt[0]).ToString();
                else if (strTxt.Length > 1)
                    strTxt = char.ToUpper(strTxt[0]) + strTxt.Substring(1);

                //Number format

                //int n = 1;
                //if (txtInvReq.Lines.Count() > 0)
                //{
                //    int noofLines = txtInvReq.Lines.Length;
                //    string lastline = txtInvReq.Lines[noofLines - 1];
                //    if (string.IsNullOrEmpty(lastline))
                //    {
                //        for (int i = 1; i <= noofLines; i++)
                //        {
                //            lastline = txtInvReq.Lines[noofLines - i];
                //            if (!string.IsNullOrEmpty(lastline) && lastline.Contains(')'))
                //                break;
                //        }
                //    }
                //    string num = lastline.Split(')')[0].Replace(bullet, "");
                //    //num = System.Text.RegularExpressions.Regex.Split(lastline, ")", System.Text.RegularExpressions.RegexOptions.None)[0];

                //    if (int.TryParse(num, out n))
                //        n = n + 1;
                //    else
                //        n = 1;

                //    strTxt = bullet + n + ") " + strTxt;
                //}
                //else
                //    strTxt = bullet + n + ") " + strTxt;

                strTxt = bullet + " " + strTxt;
                txtInvReq.AppendText(strTxt + Environment.NewLine);
                txtAddInv.Text = "";
            }
        }
        Dictionary<string, string> GetReplaceDictionary()
        {
            try
            {
                string strPName = txtPName.Text.Trim();
                string strAge = txtAge.Text.Trim();
                if (string.IsNullOrEmpty(strAge))
                    strAge = "0";
                strAge = strAge + "Y";
                string strAgeM = txtMonth.Text.Trim();
                string strAgeD = txtDays.Text.Trim();
                if (!string.IsNullOrEmpty(strAgeM))
                    strAge = strAge + ", " + strAgeM + "M";
                if (!string.IsNullOrEmpty(strAgeD))
                    strAge = strAge + ", " + strAgeD + "D";

                string strSex = cmbSex.Text.Trim();
                if (strSex == "Female")
                    strSex = "F";
                else if (strSex == "Male")
                    strSex = "M";
                else if (strSex == "Trans")
                    strSex = "TG";
                else
                    strSex = "";
                string strContact = txtContact.Text.Trim();
                string cliDiagnosis = txtChliDiagnosis.Text.Trim();
                string InvReq = txtInvReq.Text.Trim() + Environment.NewLine;
                string strDate = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"); // DateTime.Now.Day.ToString("D2") + "/" + DateTime.Now.Month.ToString("D2") + "/" + DateTime.Now.Year.ToString("D4");

                Dictionary<string, string> replaceDict = new Dictionary<string, string>();

                replaceDict.Add("#date#", strDate);
                replaceDict.Add("#pname#", strPName + " ");
                replaceDict.Add("#age#", strAge + " ");
                replaceDict.Add("#sex#", strSex);

                replaceDict.Add("#cont#", strContact + " ");
                replaceDict.Add("#cdiags#", cliDiagnosis);

                replaceDict.Add("#InvReq#", InvReq);

                return replaceDict;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("Inv-GetReplaceDictionary()-->" + ex.Message);
                return null;
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                string pname = txtPName.Text.Trim();
                string strSex = cmbSex.Text.Trim();
                string InvReq = txtInvReq.Text.Trim();
                string cliDiagnosis = txtChliDiagnosis.Text.Trim();
                if (string.IsNullOrEmpty(pname))
                {
                    MessageBox.Show("Please enter patient name.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (strSex == "- Select -")
                {
                    MessageBox.Show("Please select gender.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (string.IsNullOrEmpty(cliDiagnosis))
                {
                    MessageBox.Show("Please enter clinical diagnosis.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (string.IsNullOrEmpty(InvReq))
                {
                    MessageBox.Show("Please enter required investigations.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                //initialize word object
                document = new Document();
                //close if the template is already opened
                if (GloabalFunctions.closeOpenedWord(GloabalFunctions.InvestigationsTemplatePath))
                    System.Threading.Thread.Sleep(100);
                document.LoadFromFile(GloabalFunctions.InvestigationsTemplatePath);
                //get strings to replace
                Dictionary<string, string> dictReplace = GetReplaceDictionary();
                //Replace text
                foreach (KeyValuePair<string, string> kvp in dictReplace)
                {
                    document.Replace(kvp.Key, kvp.Value, true, true);
                }
                //Save doc file.

                //UncPath = Directory.GetParent(UncPath).ToString();

                if (!Directory.Exists(UncPath))
                    Directory.CreateDirectory(UncPath);

                string docxPath = UncPath + "\\" + pname + "_" + DateTime.Now.ToString("ddMMyyyy") + ".docx";
                
                document.SaveToFile(docxPath, FileFormat.Docx);
                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    string pdfPath = docxPath.Replace(".docx", ".pdf");
                //    //Convert to PDF
                //    document.SaveToFile(pdfPath, FileFormat.PDF);
                //}
                document.Close();

                
                if (MessageBox.Show("Required Investigations saved successfully. \r\n Do you want to give print?.", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    GloabalFunctions.printFile(docxPath);

                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    EmailNotification.eMailNotification(strPName, strEmail, pdfPath);
                //    //System.Threading.Thread.Sleep(100);
                //}

                clearControls();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnInvPrint_Click()-->" + ex.Message);
            }
        }
        private void clearControls()
        {
            //txtPName.Text = "";
            txtAge.Text = "";
            txtMonth.Text = "";
            txtDays.Text = "";
            cmbSex.SelectedIndex = 0;
            txtAddInv.Text = "";
            txtInvReq.Text = "";
            txtContact.Text = "";
            txtChliDiagnosis.Text = "";
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            clearControls();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1 || (sender as TextBox).Name == "txtAge"))
            {
                e.Handled = true;
            }
        }

        private void txtMonth_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                {
                    e.Handled = true;
                }

                //if (!string.IsNullOrEmpty(txtMonth.Text))
                //{
                //    string mm = txtMonth.Text.Trim() + "" + e.KeyChar.ToString();
                //    if (Convert.ToInt16(mm) > 11)
                //        e.Handled = true;
                //}
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        private void txtChliDiagnosis_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtChliDiagnosis.Text) && !Char.IsUpper(txtChliDiagnosis.Text, 0))
            {
                txtChliDiagnosis.Text = Char.ToUpper(txtChliDiagnosis.Text[0]) + txtChliDiagnosis.Text.Substring(1);
                txtChliDiagnosis.Select(txtChliDiagnosis.Text.Length, 1);
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                GloabalFunctions.BrowseFileToPrint(UncPath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("Inv-Browse_Click()-->" + ex.Message);
            }
        }
    }
}
