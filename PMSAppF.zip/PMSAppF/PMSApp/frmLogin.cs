﻿using PMSApp.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            if(Properties.Settings.Default.remember == true)
            {
                txtUserID.Text = Properties.Settings.Default.username;
                txtPwd.Text = Properties.Settings.Default.passward;
                chkRemember.Checked = true;
            }
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string uid = txtUserID.Text.Trim();
                string pwd = txtPwd.Text.Trim();
                if (string.IsNullOrEmpty(uid))
                {
                    MessageBox.Show("Please enter User ID.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    txtUserID.Focus();
                    return;
                }
                if (string.IsNullOrEmpty(pwd))
                {
                    MessageBox.Show("Please enter password.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    txtPwd.Focus();
                    return;
                }
                string orgUID = Properties.Settings.Default.username.Trim();
                string orgPWD = Properties.Settings.Default.passward.Trim();
                if(uid.ToLower() != orgUID.ToLower() || pwd != orgPWD)
                {
                    MessageBox.Show("Please enter valid credentials.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtPwd.Focus();
                    return;
                }
                if (chkRemember.Checked)
                    Properties.Settings.Default.remember = true;
                else
                    Properties.Settings.Default.remember = false;

                Properties.Settings.Default.Save();


                this.Hide();
                frmHome objHome = new frmHome();
                objHome.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "GPApps :: PMS");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "GPApps :: PMS");
            }
        }


        private void btnLogin_MouseHover(object sender, EventArgs e)
        {
            btnLogin.Image = Resources.L_3;
        }

        private void btnLogin_MouseLeave(object sender, EventArgs e)
        {
            btnLogin.Image = Resources.L_1;
        }

        private void btnLogin_MouseDown(object sender, MouseEventArgs e)
        {
            btnLogin.Image = Resources.L_3;
        }

        private void btnCancel_MouseHover(object sender, EventArgs e)
        {
            btnCancel.Image = Resources.C_3;
        }

        private void btnCancel_MouseLeave(object sender, EventArgs e)
        {
            btnCancel.Image = Resources.C_1;
        }

        private void btnCancel_MouseDown(object sender, MouseEventArgs e)
        {
            btnCancel.Image = Resources.C_3;
        }

        
        private void txtUserID_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                btnLogin.PerformClick();
            }
        }

        private void txtPwd_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyValue == 13)
            {
                btnLogin.PerformClick();
            }
        }

        
    }
}
