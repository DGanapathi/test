﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmConfig : Form
    {
        public frmConfig()
        {
            InitializeComponent();
        }

        private void frmConfig_Load(object sender, EventArgs e)
        {
            string UncPath = System.Configuration.ConfigurationManager.AppSettings["FilesPath"].ToString();
            string strEmail = System.Configuration.ConfigurationManager.AppSettings["FROMMAIL"].ToString();
            string strPwd = System.Configuration.ConfigurationManager.AppSettings["EMAILPASSWORD"].ToString();
            txtFilePath.Text = UncPath;
            txtEmail.Text = strEmail;
            txtPassword.Text = strPwd;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string UncPath = txtFilePath.Text.Trim();
                string strEmail = txtEmail.Text.Trim();
                string strPwd = txtPassword.Text.Trim();
                if (string.IsNullOrEmpty(UncPath))
                {
                    MessageBox.Show("Please enter path.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (!System.IO.Directory.Exists(@UncPath))
                {
                    MessageBox.Show("Path doesnot exist. Please enter valid path.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return; 
                }
                if (string.IsNullOrEmpty(strEmail))
                {
                    MessageBox.Show("Please enter path.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (string.IsNullOrEmpty(strPwd))
                {
                    MessageBox.Show("Please enter path.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);
                config.AppSettings.Settings["FilesPath"].Value = @UncPath;
                config.AppSettings.Settings["FROMMAIL"].Value = strEmail;
                config.AppSettings.Settings["EMAILPASSWORD"].Value = strPwd;
                config.Save(ConfigurationSaveMode.Minimal);
                MessageBox.Show("File path saved succusessfully.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
