﻿using Spire.Doc;
using Spire.Doc.Documents;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmVaccinationCard : Form
    {
        string UncPath = Directory.GetParent(System.Configuration.ConfigurationManager.AppSettings["FilesPath"]).ToString() + Path.DirectorySeparatorChar + "PatientVaccinationCards";
        string emailNotification = System.Configuration.ConfigurationManager.AppSettings["SendEmailNotification"].ToString();

        //word document object
        Document document = null;

        AutoCompleteStringCollection autoCollection = new AutoCompleteStringCollection();
        public frmVaccinationCard()
        {
            InitializeComponent();
            txtSearch.ForeColor = Color.LightGray;
            txtSearch.Text = "Enter Child Name";
            this.txtSearch.Leave += new System.EventHandler(this.txtSearch_Leave);
            this.txtSearch.Enter += new System.EventHandler(this.txtSearch_Enter);
        }
        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "Enter Child Name";
                txtSearch.Font = new Font(txtSearch.Font, FontStyle.Italic);
                txtSearch.ForeColor = Color.Gray;
            }
        }

        private void txtSearch_Enter(object sender, EventArgs e)
        {
            if (txtSearch.Text == "Enter Child Name")
            {
                txtSearch.Text = "";
                txtSearch.Font = new Font(txtSearch.Font, FontStyle.Regular);
                txtSearch.ForeColor = Color.Black;
            }
        }

        private void getData(string searchText)
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("ChildName");
                dt.Columns.Add("FilePath");
                string myDir = UncPath;
                if (Directory.Exists(myDir) && (Directory.GetFiles(myDir, "*.doc", SearchOption.AllDirectories).Count() > 0 || Directory.GetFiles(myDir, "*.docx", SearchOption.AllDirectories).Count() > 0))
                {
                    List<string> lstFiles = Directory.GetFiles(myDir, "*.*", SearchOption.AllDirectories).Where(file => new string[] { ".doc", ".docx" }.Contains(Path.GetExtension(file))).ToList();

                    DataRow dr;

                    foreach (string strFile in lstFiles)
                    {
                        if (!string.IsNullOrEmpty(searchText))
                        {
                            if (!Path.GetFileNameWithoutExtension(strFile).ToLower().Contains(searchText.ToLower()))
                                continue;
                        }
                        if (File.GetAttributes(strFile).HasFlag(FileAttributes.Hidden))
                            continue;

                        dr = dt.NewRow();
                        dr["ChildName"] = Path.GetFileNameWithoutExtension(strFile);
                        dr["FilePath"] = strFile;
                        dt.Rows.Add(dr);
                    }
                    dt.CaseSensitive = false;
                    //DataRow[] dtrow;
                    //dtrow = dt.Select("PatientName LIKE  '%" + searchText + "%'");
                    //dgPatients.AutoGenerateColumns = false;

                    dgPatients.DataSource = dt;
                    lblCount.Text = "No.of records : " + dgPatients.Rows.Count;
                }
                else
                {
                    //dgPatients.DataSource = null;
                    dgPatients.DataSource = dt;
                    lblCount.Text = "No data found";
                }
                dgPatients.ClearSelection();

                btnDelete.Enabled = false;
                btnPrint.Enabled = false;
                btnOpen.Enabled = false;
                btnEdit.Enabled = false;
                btnEmail.Enabled = false;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getData()-->" + ex.Message);
            }
        }

        private AutoCompleteStringCollection getAutoCompleteCollection(string path)
        {
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            try
            {
                string connString = "";
                if (!File.Exists(path))
                {
                    GloabalFunctions.WriteLog("File not exists: " + path);
                    return null;
                }

                if (GloabalFunctions.closeOpenedExcel(path))
                    System.Threading.Thread.Sleep(100);
                string strFileType = Path.GetExtension(path).ToLower();
                string sheetName = "";
                if (strFileType.Trim() == ".xls")
                {
                    //connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=Excel 8.0;";
                }
                else if (strFileType.Trim() == ".xlsx")
                {
                    //connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 12.0;";
                }

                //Get the name of the First Sheet.
                using (OleDbConnection con = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmd = new OleDbCommand())
                    {
                        cmd.Connection = con;
                        con.Open();
                        DataTable dtExcelSchema = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                        con.Close();
                    }
                }
                //Read Data from the First Sheet.
                using (OleDbConnection con = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmd = new OleDbCommand())
                    {
                        using (OleDbDataAdapter oda = new OleDbDataAdapter())
                        {
                            //string query = "SELECT [UserName],[Education],[Location] FROM [Sheet1$]";
                            DataTable dt = new DataTable();
                            cmd.CommandText = "SELECT * From [" + sheetName + "]";
                            cmd.Connection = con;
                            con.Open();
                            oda.SelectCommand = cmd;
                            oda.Fill(dt);
                            //DataSet ds = new DataSet();
                            //da.Fill(ds);
                            con.Close();

                            if (dt != null && dt.Rows.Count > 0)
                            {
                                //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (dr[0] != DBNull.Value)
                                        MyCollection.Add(dr[0].ToString().Trim());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getAutoCompleteCollection()-->" + ex.Message);
                return null;
            }
            return MyCollection;
        }


        private void getAddress()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.AddressesExcelPath))
                {
                    MessageBox.Show("Addresses list: " + Path.GetFileName(GloabalFunctions.AddressesExcelPath) + " not exists" + "\r\n" + "Please place Addresses list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.AddressesExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.AddressesExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtAddress.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtAddress.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtAddress.AutoCompleteCustomSource = MyCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getAddress()-->" + ex.Message);
            }
        }

        private void frmVaccinationCard_Load(object sender, EventArgs e)
        {
            getAddress();
            getData("");
            cmbSex.SelectedIndex = 0;
            
        }
        Dictionary<string, string> GetReplaceDictionary()
        {
            try
            {
                string strPName = txtPName.Text.Trim();
                string strSex = cmbSex.Text.Trim();
                if (strSex == "Female")
                    strSex = "F";
                else if (strSex == "Male")
                    strSex = "M";
                else if (strSex == "Trans")
                    strSex = "TG";
                else
                    strSex = "";
                string strWeight = txtWeight.Text.Trim() + "Kg";
                string strHeight = txtHeight.Text.Trim() + "Cm";
                string strAddr = txtAddress.Text.Trim();
                string strContact = txtContact.Text.Trim();


                string strDate = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"); // DateTime.Now.Day.ToString("D2") + "/" + DateTime.Now.Month.ToString("D2") + "/" + DateTime.Now.Year.ToString("D4");

                Dictionary<string, string> replaceDict = new Dictionary<string, string>();

                DateTime dtDOB = dpDOB.Value;
                string strDOB = dpDOB.Text;

                replaceDict.Add("#date#", strDate);
                replaceDict.Add("#pname#", strPName + " ");
                replaceDict.Add("#dob#", strDOB + " ");
                replaceDict.Add("#mname#", txtMName.Text.Trim());
                replaceDict.Add("#gender#", strSex + " ");
                replaceDict.Add("#wt#", strWeight + " ");
                replaceDict.Add("#ht#", strHeight + " ");
                replaceDict.Add("#addrs#", strAddr + " ");
                replaceDict.Add("#cont#", strContact + " ");

                //Due Date :41
                //replaceDict.Add("#dob#", strDOB);
                replaceDict.Add("#6wks#", dtDOB.AddDays(7 * 6).ToString("dd/MM/yyyy"));
                replaceDict.Add("#8wks#", dtDOB.AddDays(7 * 8).ToString("dd/MM/yyyy"));
                replaceDict.Add("#10wks#", dtDOB.AddDays(7 * 10).ToString("dd/MM/yyyy"));
                replaceDict.Add("#14wks#", dtDOB.AddDays(7 * 14).ToString("dd/MM/yyyy"));
                replaceDict.Add("#16wks#", dtDOB.AddDays(7 * 16).ToString("dd/MM/yyyy"));
                replaceDict.Add("#24wks#", dtDOB.AddDays(7 * 24).ToString("dd/MM/yyyy"));

                replaceDict.Add("#6mts#", dtDOB.AddMonths(6).ToString("dd/MM/yyyy"));
                replaceDict.Add("#9mts#", dtDOB.AddMonths(9).ToString("dd/MM/yyyy"));
                replaceDict.Add("#12mts#", dtDOB.AddMonths(12).ToString("dd/MM/yyyy"));
                replaceDict.Add("#15mts#", dtDOB.AddMonths(15).ToString("dd/MM/yyyy"));
                replaceDict.Add("#18mts#", dtDOB.AddMonths(18).ToString("dd/MM/yyyy"));

                replaceDict.Add("#2yrs#", dtDOB.AddYears(2).ToString("dd/MM/yyyy"));
                replaceDict.Add("#5yrs#", dtDOB.AddYears(5).ToString("dd/MM/yyyy"));
                replaceDict.Add("#8yrs#", dtDOB.AddYears(8).ToString("dd/MM/yyyy"));
                replaceDict.Add("#10yrs#", dtDOB.AddYears(10).ToString("dd/MM/yyyy"));
                replaceDict.Add("#11yrs#", dtDOB.AddYears(11).ToString("dd/MM/yyyy"));
                replaceDict.Add("#14yrs#", dtDOB.AddYears(14).ToString("dd/MM/yyyy"));
                replaceDict.Add("#16yrs#", dtDOB.AddYears(16).ToString("dd/MM/yyyy"));

                //Given Date :41
                replaceDict.Add("#bgcG#", dpBGCGiven.Enabled ? dpBGCGiven.Text.Trim() : "");
                replaceDict.Add("#hb1G#", dpHB1Given.Enabled ? dpHB1Given.Text.Trim() : "");
                replaceDict.Add("#opv1G#", dpOPV1Given.Enabled ? dpOPV1Given.Text.Trim() : "");
                replaceDict.Add("#opv2G#", dpOPV2Given.Enabled ? dpOPV2Given.Text.Trim() : "");
                replaceDict.Add("#dpt1G#", dpDPT1Given.Enabled ? dpDPT1Given.Text.Trim() : "");
                replaceDict.Add("#hb2G#", dpHB2Given.Enabled ? dpHB2Given.Text.Trim() : "");
                replaceDict.Add("#hib1G#", dpHIB1Given.Enabled ? dpHIB1Given.Text.Trim() : "");
                replaceDict.Add("#pcv1G#", dpPCV1Given.Enabled ? dpPCV1Given.Text.Trim() : "");
                replaceDict.Add("#rotarix1G#", dpRotarix1G.Enabled ? dpRotarix1G.Text.Trim() : "");
                replaceDict.Add("#dpt2G#", dpDPT2G.Enabled ? dpDPT2G.Text.Trim() : "");

                replaceDict.Add("#opv3G#", dpOPV3G.Enabled ? dpOPV3G.Text.Trim() : "");
                replaceDict.Add("#hib2G#", dpHIB2G.Enabled ? dpHIB2G.Text.Trim() : "");
                replaceDict.Add("#opv4G#", dpOPV4G.Enabled ? dpOPV4G.Text.Trim() : "");
                replaceDict.Add("#dpt3G#", dpDPT3G.Enabled ? dpDPT3G.Text.Trim() : "");
                replaceDict.Add("#hb3G#", dpHB3G.Enabled ? dpHB3G.Text.Trim() : "");
                replaceDict.Add("#hib3G#", dpHIB3G.Enabled ? dpHIB3G.Text.Trim() : "");
                replaceDict.Add("#pcv2G#", dpPCV2G.Enabled ? dpPCV2G.Text.Trim() : "");
                replaceDict.Add("#rotarix2G#", dpRotarix2G.Enabled ? dpRotarix2G.Text.Trim() : "");
                replaceDict.Add("#pcv3G#", dpPCV3G.Enabled ? dpPCV3G.Text.Trim() : "");
                replaceDict.Add("#measlesG#", dpMeaslesG.Enabled ? dpMeaslesG.Text.Trim() : "");

                replaceDict.Add("#varicella1G#", dpVaricella1G.Enabled ? dpVaricella1G.Text.Trim() : "");
                replaceDict.Add("#pcvbG#", dpPCVBoosterG.Enabled ? dpPCVBoosterG.Text.Trim() : "");
                replaceDict.Add("#mmr1G#", dpMMRG.Enabled ? dpMMRG.Text.Trim() : "");
                replaceDict.Add("#varicella2G#", dpVaricella2G.Enabled ? dpVaricella2G.Text.Trim() : "");
                replaceDict.Add("#dptb1G#", dpDPTBooster1G.Enabled ? dpDPTBooster1G.Text.Trim() : "");
                replaceDict.Add("#hibbG#", dpHIBBoosterG.Enabled ? dpHIBBoosterG.Text.Trim() : "");
                replaceDict.Add("#opvb1G#", dpOPVBoosterG.Enabled ? dpOPVBoosterG.Text.Trim() : "");
                replaceDict.Add("#ha1G#", dpHA1G.Enabled ? dpHA1G.Text.Trim() : "");

                replaceDict.Add("#typoidG#", dpTyphoidG.Enabled ? dpTyphoidG.Text.Trim() : "");
                replaceDict.Add("#ha2G#", dpHA2G.Enabled ? dpHA2G.Text.Trim() : "");
                replaceDict.Add("#dtpb2G#", dpDPTBooster2G.Enabled ? dpDPTBooster2G.Text.Trim() : "");
                replaceDict.Add("#opvb2G#", dpOPVBooster2G.Enabled ? dpOPVBooster2G.Text.Trim() : "");
                replaceDict.Add("#mmr2G#", dpMMR2G.Enabled ? dpMMR2G.Text.Trim() : "");
                replaceDict.Add("#vbG#", dpVaricellaBoosterG.Enabled ? dpVaricellaBoosterG.Text.Trim() : "");
                replaceDict.Add("#hbbG#", dpHBBG.Enabled ? dpHBBG.Text.Trim() : "");
                replaceDict.Add("#typoid2G#", dpTyphoid2G.Enabled ? dpTyphoid2G.Text.Trim() : "");
                replaceDict.Add("#typoid3G#", dpTyphoid3G.Enabled ? dpTyphoid3G.Text.Trim() : "");
                replaceDict.Add("#tdapb1G#", dpTBooster1G.Enabled ? dpTBooster1G.Text.Trim() : "");

                replaceDict.Add("#typoid4G#", dpTyphoid4G.Enabled ? dpTyphoid4G.Text.Trim() : "");
                replaceDict.Add("#typoid5G#", dpTyphoid5G.Enabled ? dpTyphoid5G.Text.Trim() : "");
                replaceDict.Add("#tdapb2G#", dpTBooster2G.Enabled ? dpTBooster2G.Text.Trim() : "");


                return replaceDict;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("VCard-GetReplaceDictionary()-->" + ex.Message);
                return null;
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string pname = txtPName.Text.Trim();
                string strDOB = dpDOB.Text;
                string strSex = cmbSex.Text.Trim();

                if (string.IsNullOrEmpty(pname))
                {
                    MessageBox.Show("Please enter patient name.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (strSex == "- Select -")
                {
                    MessageBox.Show("Please select gender.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                

                //initialize word object
                document = new Document();
                //close if the template is already opened
                if (GloabalFunctions.closeOpenedWord(GloabalFunctions.VaccinationCardTemplatePath))
                    System.Threading.Thread.Sleep(100);
                document.LoadFromFile(GloabalFunctions.VaccinationCardTemplatePath);
                //get strings to replace
                Dictionary<string, string> dictReplace = GetReplaceDictionary();
                //Replace text
                foreach (KeyValuePair<string, string> kvp in dictReplace)
                {
                    document.Replace(kvp.Key, kvp.Value, true, true);
                }
                //Save doc file.
                if (!Directory.Exists(UncPath))
                    Directory.CreateDirectory(UncPath);

                string docxPath = UncPath + "\\" + pname + "_" + dpDOB.Value.ToString("ddMMyyyy") + ".docx";
                string printFilePath = docxPath;
                if (File.Exists(docxPath))
                {
                    DialogResult res = MessageBox.Show("Vaccination card already exists with name: \r\n" + docxPath +"\r\n" + "Click Yes to override No to save another file.", "GPApps :: PMS", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (res == DialogResult.Yes)
                    {
                        if (GloabalFunctions.closeOpenedWord(docxPath))
                            System.Threading.Thread.Sleep(100);

                        File.Delete(docxPath);
                    }
                    else if (res == DialogResult.No)
                    {
                        docxPath = UncPath + "\\" + pname + "_" + dpDOB.Value.ToString("ddMMyyyy") + "_1" + ".docx";
                        if (File.Exists(docxPath))
                            docxPath = UncPath + "\\" + pname + "_" + dpDOB.Value.ToString("ddMMyyyy") + "_2" + ".docx";
                        if (GloabalFunctions.closeOpenedWord(docxPath))
                            System.Threading.Thread.Sleep(100);
                    }
                    else
                        return;
                }
                
                ////save to docx
                document.SaveToFile(docxPath, FileFormat.Docx);

                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    string pdfPath = docxPath.Replace(".docx", ".pdf");
                //    //Convert to PDF
                //    document.SaveToFile(pdfPath, FileFormat.PDF);
                //    printFilePath = pdfPath;
                //}

                document.Close();

                if (MessageBox.Show("Vaccination card saved successfully. \r\n Do you want to give print?.", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    GloabalFunctions.printFile(printFilePath);

                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    EmailNotification.eMailNotification(strPName, strEmail, pdfPath);
                //    //System.Threading.Thread.Sleep(100);
                //}


                getData("");
                clearControls();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("VC-Save_Click()-->" + ex.Message);
            }

        }
        private void clearControls()
        {
            txtPName.Text = "";
            dpDOB.Value = DateTime.Now.Date;
            txtMName.Text = "";
            txtContact.Text = "";
            cmbSex.SelectedIndex = 0;
            txtWeight.Text = "";
            txtHeight.Text = "";
            txtAddress.Text = "";
            txtWeight.Text = "";
            chkGivenOn1.Checked = true;
            chkGivenOn2.Checked = true;
            chkGivenOn3.Checked = true;
            chkGivenOn4.Checked = true;

            chkGivenOn1.Checked = false;
            chkGivenOn2.Checked = false;
            chkGivenOn3.Checked = false;
            chkGivenOn4.Checked = false;


            dgPatients.ClearSelection();
            txtSearch.Text = "Enter Child Name";
            txtSearch.Font = new Font(txtSearch.Font, FontStyle.Italic);
            txtSearch.ForeColor = Color.Gray;
            btnDelete.Enabled = false;
            btnPrint.Enabled = false;
            btnOpen.Enabled = false;
            btnEdit.Enabled = false;
            btnEmail.Enabled = false;
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            //try
            //{

            //    dpDOB.Value = ConvertDate("13/07/2018");
            //   // dpDOB.Value = Convert.ToDateTime("16/07/2018");
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.StackTrace); ;
            //}
            clearControls();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
               GloabalFunctions.ToViewFile(filePath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnOpen_Click()-->" + ex.Message);
            }
        }

        public static string filepathForMail = "";
        public static string patientNameForMail = "";
        public bool blConvertDate = true;
        public DateTime ConvertDate(string s)//Convert String to Date 
        {
            DateTime time = DateTime.Now;
            try
            {
                blConvertDate = true;
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
                DateTime time2 = Convert.ToDateTime(s);
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
                time = Convert.ToDateTime(time2);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("ConvertDate()-->" + ex.Message);
                blConvertDate = false;
            }
            return time;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Patient file not exists at this location." + "\r\n" + filePath, "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                editPatientFile(filePath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnEdit_Click()-->" + ex.Message);
            }
        }
        private bool editPatientFile(string strFilePath)
        {
            bool retVal = false;
            try
            {
                //Create word document
                Document document = new Document();
                document.LoadFromFile(strFilePath);

                //Get a paragraph
                //Paragraph paragraph = document.Sections[0].AddParagraph();

                if (document.Sections.Count > 0)
                {
                    foreach (Section sec in document.Sections)
                    {
                        if (sec.Paragraphs.Count > 0)
                        {
                            string txtPara = "";
                            string strTemp = "";
                            string[] tempArr = new string[2];

                            //Getting patient name, age, add,...
                            foreach (Paragraph prgp in sec.Paragraphs)
                            {
                                txtPara = prgp.Text;
                                if (txtPara.Contains("Vaccination Card") || txtPara.Contains("Date:"))
                                    continue;
                                if (txtPara.Contains("Child Name:"))
                                {
                                    //Child Name:GANI Sex:M DOB:01/01/2010
                                    tempArr = Regex.Split(txtPara, "Sex:");
                                    txtPName.Text = tempArr[0].Replace("Child Name:", "").Trim();
                                    strTemp = tempArr[1].Trim();
                                    tempArr = Regex.Split(strTemp, "DOB:");
                                    string sex = tempArr[0].Trim();
                                    if (sex.ToUpper() == "TRANS")
                                        cmbSex.SelectedIndex = 3;
                                    else if (sex.ToUpper() == "M")
                                        cmbSex.SelectedIndex = 2;
                                    else if (sex.ToUpper() == "F")
                                        cmbSex.SelectedIndex = 1;
                                    else
                                        cmbSex.SelectedIndex = 0;

                                    dpDOB.Value = ConvertDate(tempArr[1].Trim());
                                }
                                else if (txtPara.Trim().StartsWith("Mother Name:"))
                                {
                                    tempArr = Regex.Split(txtPara, "Weight:");
                                    txtMName.Text = tempArr[0].Replace("Mother Name:", "").Trim();

                                    strTemp = tempArr[1].Trim();
                                    tempArr = Regex.Split(strTemp, "Height:");
                                    txtWeight.Text = tempArr[0].Replace("Kg", "").Trim();
                                    txtHeight.Text = tempArr[1].Replace("Cm", "").Trim();
                                }
                                else if (txtPara.Trim().StartsWith("Address:"))
                                {
                                    tempArr = Regex.Split(txtPara, "Contact#:");
                                    txtAddress.Text = tempArr[0].Replace("Address:","").Trim();
                                    txtContact.Text = tempArr[1].Replace("Cm", "").Trim();
                                }
                            }
                        }
                        if (sec.Tables.Count > 0 && sec.Tables[0].Rows.Count > 0)
                        {
                            //Getting C/o & Rx details
                            StringBuilder sbCo = new StringBuilder();
                            StringBuilder sbRx = new StringBuilder();
                            Table table = sec.Tables[0] as Table;
                            if (table != null && table.Rows.Count > 0)
                            {
                                string ss = table.Rows[2].Cells[0].Paragraphs[0].Text;
                                //string mm = table.Rows[2].Cells[0].Paragraphs[0]?.Text? ;

                                if (table.Rows[2].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkBCG.Checked = true;
                                    dpBGCGiven.Value = ConvertDate(table.Rows[2].Cells[3].Paragraphs[0].Text);
                                    dpBGCGiven.Enabled = true;
                                }
                                else
                                    chkBCG.Checked = false;
                                if (table.Rows[3].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHB1.Checked = true;
                                    dpHB1Given.Value = ConvertDate(table.Rows[3].Cells[3].Paragraphs[0].Text);
                                    dpHB1Given.Enabled = true;
                                }
                                else
                                    chkHB1.Checked = false;
                                if (table.Rows[4].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkOPV1.Checked = true;
                                    dpOPV1Given.Value = ConvertDate(table.Rows[4].Cells[3].Paragraphs[0].Text);
                                    dpOPV1Given.Enabled = true;
                                }
                                else
                                    chkOPV1.Checked = false;
                                if (table.Rows[5].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkOPV2.Checked = true;
                                    dpOPV2Given.Value = ConvertDate(table.Rows[5].Cells[3].Paragraphs[0].Text);
                                    dpOPV2Given.Enabled = true;
                                }
                                else
                                    chkOPV2.Checked = false;
                                if (table.Rows[6].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkDPT1.Checked = true;
                                    dpDPT1Given.Value = ConvertDate(table.Rows[6].Cells[3].Paragraphs[0].Text);
                                    dpDPT1Given.Enabled = true;
                                }
                                else
                                    chkDPT1.Checked = false;
                                if (table.Rows[7].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHB2.Checked = true;
                                    dpHB2Given.Value = ConvertDate(table.Rows[7].Cells[3].Paragraphs[0].Text);
                                    dpHB2Given.Enabled = true;
                                }
                                else
                                    chkHB2.Checked = false;
                                if (table.Rows[8].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHIB1.Checked = true;
                                    dpHIB1Given.Value = ConvertDate(table.Rows[8].Cells[3].Paragraphs[0].Text);
                                    dpHIB1Given.Enabled = true;
                                }
                                else
                                    chkHIB1.Checked = false;
                                if (table.Rows[9].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkPCV1.Checked = true;
                                    dpPCV1Given.Value = ConvertDate(table.Rows[9].Cells[3].Paragraphs[0].Text);
                                    dpPCV1Given.Enabled = true;
                                }
                                else
                                    chkPCV1.Checked = false;
                                if (table.Rows[10].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkRotarix1.Checked = true;
                                    dpRotarix1G.Value = ConvertDate(table.Rows[10].Cells[3].Paragraphs[0].Text);
                                    dpRotarix1G.Enabled = true;
                                }
                                else
                                    chkRotarix1.Checked = false;
                                if (table.Rows[11].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkDPT2.Checked = true;
                                    dpDPT2G.Value = ConvertDate(table.Rows[11].Cells[3].Paragraphs[0].Text);
                                    dpDPT2G.Enabled = true;
                                }
                                else
                                    chkDPT2.Checked = false;
                                if (table.Rows[12].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkOPV3.Checked = true;
                                    dpOPV3G.Value = ConvertDate(table.Rows[12].Cells[3].Paragraphs[0].Text);
                                    dpOPV3G.Enabled = true;
                                }
                                else
                                    chkOPV3.Checked = false;
                                if (table.Rows[13].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHIB2.Checked = true;
                                    dpHIB2G.Value = ConvertDate(table.Rows[13].Cells[3].Paragraphs[0].Text);
                                    dpHIB2G.Enabled = true;
                                }
                                else
                                {
                                    chkHIB2.Checked = false;
                                }
                                if (table.Rows[14].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkOPV4.Checked = true;
                                    dpOPV4G.Value = ConvertDate(table.Rows[14].Cells[3].Paragraphs[0].Text);
                                    dpOPV4G.Enabled = true;
                                }
                                else
                                {
                                    chkOPV4.Checked = false;
                                }
                                if (table.Rows[15].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkDPT3.Checked = true;
                                    dpDPT3G.Value = ConvertDate(table.Rows[15].Cells[3].Paragraphs[0].Text);
                                    dpDPT3G.Enabled = true;
                                }
                                else
                                {
                                    chkDPT3.Checked = false;
                                }
                                if (table.Rows[16].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHB3.Checked = true;
                                    dpHB3G.Value = ConvertDate(table.Rows[16].Cells[3].Paragraphs[0].Text);
                                    dpHB3G.Enabled = true;
                                }
                                else
                                {
                                    chkHB3.Checked = false;
                                }
                                if (table.Rows[17].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHIB3.Checked = true;
                                    dpHIB3G.Value = ConvertDate(table.Rows[17].Cells[3].Paragraphs[0].Text);
                                    dpHIB3G.Enabled = true;
                                }
                                else
                                {
                                    chkHIB3.Checked = false;
                                }
                                if (table.Rows[18].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkPCV2.Checked = true;
                                    dpPCV2G.Value = ConvertDate(table.Rows[18].Cells[3].Paragraphs[0].Text);
                                    dpPCV2G.Enabled = true;
                                }
                                else
                                {
                                    chkPCV2.Checked = false;
                                }
                                if (table.Rows[19].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkRotarix2.Checked = true;
                                    dpRotarix2G.Value = ConvertDate(table.Rows[19].Cells[3].Paragraphs[0].Text);
                                    dpRotarix2G.Enabled = true;
                                }
                                else
                                {
                                    chkRotarix2.Checked = false;
                                }
                                if (table.Rows[20].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkPCV3.Checked = true;
                                    dpPCV3G.Value = ConvertDate(table.Rows[20].Cells[3].Paragraphs[0].Text);
                                    dpPCV3G.Enabled = true;
                                }
                                else
                                {
                                    chkPCV3.Checked = false;
                                }
                                if (table.Rows[21].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkMeasles.Checked = true;
                                    dpMeaslesG.Value = ConvertDate(table.Rows[21].Cells[3].Paragraphs[0].Text);
                                    dpMeaslesG.Enabled = true;
                                }
                                else
                                {
                                    chkMeasles.Checked = false;
                                }
                                if (table.Rows[22].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkVaricella1.Checked = true;
                                    dpVaricella1G.Value = ConvertDate(table.Rows[22].Cells[3].Paragraphs[0].Text);
                                    dpVaricella1G.Enabled = true;
                                }
                                else
                                {
                                    chkVaricella1.Checked = false;
                                }
                                if (table.Rows[23].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkPCVBooster.Checked = true;
                                    dpPCVBoosterG.Value = ConvertDate(table.Rows[23].Cells[3].Paragraphs[0].Text);
                                    dpPCVBoosterG.Enabled = true;
                                }
                                else
                                {
                                    chkPCVBooster.Checked = false;
                                }
                                if (table.Rows[24].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkMMR.Checked = true;
                                    dpMMRG.Value = ConvertDate(table.Rows[24].Cells[3].Paragraphs[0].Text);
                                    dpMMRG.Enabled = true;
                                }
                                else
                                    chkMMR.Checked = false;

                                if (table.Rows[25].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkVaricella2.Checked = true;
                                    dpVaricella2G.Value = ConvertDate(table.Rows[25].Cells[3].Paragraphs[0].Text);
                                    dpVaricella2G.Enabled = true;
                                }
                                else
                                {
                                    chkVaricella2.Checked = false;
                                }
                                if (table.Rows[26].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkDPTBooster1.Checked = true;
                                    dpDPTBooster1G.Value = ConvertDate(table.Rows[26].Cells[3].Paragraphs[0].Text);
                                    dpDPTBooster1G.Enabled = true;
                                }
                                else
                                {
                                    chkDPTBooster1.Checked = false;
                                }
                                if (table.Rows[27].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHIBBooster.Checked = true;
                                    dpHIBBoosterG.Value = ConvertDate(table.Rows[27].Cells[3].Paragraphs[0].Text);
                                    dpHIBBoosterG.Enabled = true;
                                }
                                else
                                {
                                    chkHIBBooster.Checked = false;
                                }
                                if (table.Rows[28].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkOPVBooster.Checked = true;
                                    dpOPVBoosterG.Value = ConvertDate(table.Rows[28].Cells[3].Paragraphs[0].Text);
                                    dpOPVBoosterG.Enabled = true;
                                }
                                else
                                {
                                    chkOPVBooster.Checked = false;
                                }
                                if (table.Rows[29].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHA1.Checked = true;
                                    dpHA1G.Value = ConvertDate(table.Rows[29].Cells[3].Paragraphs[0].Text);
                                    dpHA1G.Enabled = true;
                                }
                                else
                                {
                                    chkHA1.Checked = false;
                                }
                                if (table.Rows[30].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkTyphoid.Checked = true;
                                    dpTyphoidG.Value = ConvertDate(table.Rows[30].Cells[3].Paragraphs[0].Text);
                                    dpTyphoidG.Enabled = true;
                                }
                                else
                                {
                                    chkTyphoid.Checked = false;
                                }
                                if (table.Rows[31].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHA2.Checked = true;
                                    dpHA2G.Value = ConvertDate(table.Rows[31].Cells[3].Paragraphs[0].Text);
                                    dpHA2G.Enabled = true;
                                }
                                else
                                {
                                    chkHA2.Checked = false;
                                }
                                if (table.Rows[32].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkDPTBooster2.Checked = true;
                                    dpDPTBooster2G.Value = ConvertDate(table.Rows[32].Cells[3].Paragraphs[0].Text);
                                    dpDPTBooster2G.Enabled = true;
                                }
                                else
                                {
                                    chkDPTBooster2.Checked = false;
                                }
                                if (table.Rows[33].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkOPVBooster2.Checked = true;
                                    dpOPVBooster2G.Value = ConvertDate(table.Rows[33].Cells[3].Paragraphs[0].Text);
                                    dpOPVBooster2G.Enabled = true;
                                }
                                else
                                {
                                    chkOPVBooster2.Checked = false;
                                }
                                if (table.Rows[34].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkMMR2.Checked = true;
                                    dpMMR2G.Value = ConvertDate(table.Rows[34].Cells[3].Paragraphs[0].Text);
                                    dpMMR2G.Enabled = true;
                                }
                                else
                                {
                                    chkMMR2.Checked = false;
                                }
                                if (table.Rows[35].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkVaricellaBooster.Checked = true;
                                    dpVaricellaBoosterG.Value = ConvertDate(table.Rows[35].Cells[3].Paragraphs[0].Text);
                                    dpVaricellaBoosterG.Enabled = true;
                                }
                                else
                                {
                                    chkVaricellaBooster.Checked = false;
                                }
                                if (table.Rows[36].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkHBB.Checked = true;
                                    dpHBBG.Value = ConvertDate(table.Rows[36].Cells[3].Paragraphs[0].Text);
                                    dpHBBG.Enabled = true;
                                }
                                else
                                {
                                    chkHBB.Checked = false;
                                }
                                if (table.Rows[37].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkTyphoid2.Checked = true;
                                    dpTyphoid2G.Value = ConvertDate(table.Rows[37].Cells[3].Paragraphs[0].Text);
                                    dpTyphoid2G.Enabled = true;
                                }
                                else
                                {
                                    chkTyphoid2.Checked = false;
                                }
                                if (table.Rows[38].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkTyphoid3.Checked = true;
                                    dpTyphoid3G.Value = ConvertDate(table.Rows[38].Cells[3].Paragraphs[0].Text);
                                    dpTyphoid3G.Enabled = true;
                                }
                                else
                                {
                                    chkTyphoid3.Checked = false;
                                }
                                if (table.Rows[39].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkTBooster1.Checked = true;
                                    dpTBooster1G.Value = ConvertDate(table.Rows[39].Cells[3].Paragraphs[0].Text);
                                    dpTBooster1G.Enabled = true;
                                }
                                else
                                {
                                    chkTBooster1.Checked = false;
                                }
                                if (table.Rows[40].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkTyphoid4.Checked = true;
                                    dpTyphoid4G.Value = ConvertDate(table.Rows[40].Cells[3].Paragraphs[0].Text);
                                    dpTyphoid4G.Enabled = true;
                                }
                                else
                                {
                                    chkTyphoid4.Checked = false;
                                }
                                if (table.Rows[41].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkTyphoid5.Checked = true;
                                    dpTyphoid5G.Value = ConvertDate(table.Rows[41].Cells[3].Paragraphs[0].Text);
                                    dpTyphoid5G.Enabled = true;
                                }
                                else
                                {
                                    chkTyphoid5.Checked = false;
                                }
                                if (table.Rows[42].Cells[3].Paragraphs[0].Text != "")
                                {
                                    chkTBooster2.Checked = true;
                                    dpTBooster2G.Value = ConvertDate(table.Rows[41].Cells[3].Paragraphs[0].Text);
                                    dpTBooster2G.Enabled = true;
                                }
                                else
                                {
                                    chkTBooster2.Checked = false;
                                }
                            }
                        }
                    }
                }

                document.Close();
                retVal = true;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("editPatientFile()-->" + ex.StackTrace);
                MessageBox.Show("editPatientFile()-->" + ex.StackTrace);
                retVal = false;
            }
            return retVal;
        }

       
        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Patient file not exists at this location." + "\r\n" + filePath, "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                GloabalFunctions.printFile(filePath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnPrint_Click()-->" + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                if (MessageBox.Show("Are you sure you want to delete?", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.No)
                    return;
                if (File.Exists(filePath))
                {
                    GloabalFunctions.closeOpenedWord(filePath);
                    File.Delete(filePath);
                    getData("");
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnDelete_Click()-->" + ex.Message);
                MessageBox.Show(ex.Message, "GPApps :: PMS");
            }
        }

        private void btnEmail_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count == 1)
                {
                    patientNameForMail = dgPatients.SelectedRows[0].Cells[0].Value.ToString().Trim();
                    filepathForMail = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                    //emailCollForNotification = emailCollection;
                    frmHome.patientNameForMail = patientNameForMail;
                    frmEmail frmObj = new frmEmail();
                    frmObj.ShowDialog();
                    Application.DoEvents();
                    frmObj.Dispose();
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnClose2_Click()-->" + ex.Message);
            }
        }

        private void btnClear2_Click(object sender, EventArgs e)
        {
            clearControls();

        }

        #region "CheckBox Related"
        private void chkGivenOn1_CheckedChanged(object sender, EventArgs e)
        {
            var checkbox = sender as CheckBox;
            string strChkName = checkbox.Name;

            if (strChkName == "chkGivenOn1")
            {
                if (checkbox.Checked)
                {
                    chkBCG.Checked = true;
                    chkHB1.Checked = true;
                    chkOPV1.Checked = true;
                    chkOPV2.Checked = true;
                    chkDPT1.Checked = true;
                    chkHB2.Checked = true;
                    chkHIB1.Checked = true;
                    chkPCV1.Checked = true;
                    chkRotarix1.Checked = true;
                    chkDPT2.Checked = true;
                    chkOPV3.Checked = true;
                }
                else
                {
                    chkBCG.Checked = false;
                    chkHB1.Checked = false;
                    chkOPV1.Checked = false;
                    chkOPV2.Checked = false;
                    chkDPT1.Checked = false;
                    chkHB2.Checked = false;
                    chkHIB1.Checked = false;
                    chkPCV1.Checked = false;
                    chkRotarix1.Checked = false;
                    chkDPT2.Checked = false;
                    chkOPV3.Checked = false;
                }
            }
            else if (strChkName == "chkGivenOn2")
            {
                if (checkbox.Checked)
                {
                    chkHIB2.Checked = true;
                    chkOPV4.Checked = true;
                    chkDPT3.Checked = true;
                    chkHB3.Checked = true;
                    chkHIB3.Checked = true;
                    chkPCV2.Checked = true;
                    chkRotarix2.Checked = true;
                    chkPCV3.Checked = true;
                    chkMeasles.Checked = true;
                    chkVaricella1.Checked = true;
                    chkPCVBooster.Checked = true;
                }
                else
                {
                    chkHIB2.Checked = false;
                    chkOPV4.Checked = false;
                    chkDPT3.Checked = false;
                    chkHB3.Checked = false;
                    chkHIB3.Checked = false;
                    chkPCV2.Checked = false;
                    chkRotarix2.Checked = false;
                    chkPCV3.Checked = false;
                    chkMeasles.Checked = false;
                    chkVaricella1.Checked = false;
                    chkPCVBooster.Checked = false;
                }
            }
            else if (strChkName == "chkGivenOn3")
            {
                if (checkbox.Checked)
                {
                    chkMMR.Checked = true;
                    chkVaricella2.Checked = true;
                    chkDPTBooster1.Checked = true;
                    chkHIBBooster.Checked = true;
                    chkOPVBooster.Checked = true;
                    chkHA1.Checked = true;
                    chkTyphoid.Checked = true;
                    chkHA2.Checked = true;
                    chkDPTBooster2.Checked = true;
                    chkOPVBooster2.Checked = true;
                    chkMMR2.Checked = true;
                }
                else
                {
                    chkMMR.Checked = false;
                    chkVaricella2.Checked = false;
                    chkDPTBooster1.Checked = false;
                    chkHIBBooster.Checked = false;
                    chkOPVBooster.Checked = false;
                    chkHA1.Checked = false;
                    chkTyphoid.Checked = false;
                    chkHA2.Checked = false;
                    chkDPTBooster2.Checked = false;
                    chkOPVBooster2.Checked = false;
                    chkMMR2.Checked = false;
                }
            }
            else if (strChkName == "chkGivenOn4")
            {
                if (checkbox.Checked)
                {
                    chkVaricellaBooster.Checked = true;
                    chkHBB.Checked = true;
                    chkTyphoid2.Checked = true;
                    chkTyphoid3.Checked = true;
                    chkTBooster1.Checked = true;
                    chkTyphoid4.Checked = true;
                    chkTyphoid5.Checked = true;
                    chkTBooster2.Checked = true;
                }
                else
                {
                    chkVaricellaBooster.Checked = false;
                    chkHBB.Checked = false;
                    chkTyphoid2.Checked = false;
                    chkTyphoid3.Checked = false;
                    chkTBooster1.Checked = false;
                    chkTyphoid4.Checked = false;
                    chkTyphoid5.Checked = false;
                    chkTBooster2.Checked = false;
                }
            }
        }

        public void SetAllCheckboxes(Control where)
        {
            foreach (Control control in where.Controls)
            {
                //if (control.GetType().Name == "CheckBox")
                //    control.Paint += new PaintEventHandler(this.checkbox_Paint);
                //else if (control.Controls.Count > 0)
                //    SetAllCheckboxes(control);
            }
        }

        private void chkBCG_CheckedChanged(object sender, EventArgs e)
        {
            var checkbox = sender as CheckBox;
            string strChkName = checkbox.Name;

            if (strChkName == "chkBCG")
            {
                if (checkbox.Checked)
                {
                    dpBGCGiven.Enabled = true;
                    dpBGCGiven.Value = dpBGCDue.Value;
                }
                else
                {
                    dpBGCGiven.Enabled = false;
                }
            }
            else if (strChkName == "chkHB1")
            {
                if (checkbox.Checked)
                {
                    dpHB1Given.Enabled = true;
                    dpHB1Given.Value = dpHB1Due.Value;
                }
                else
                {
                    dpHB1Given.Enabled = false;
                }
            }
            else if (strChkName == "chkOPV1")
            {
                if (checkbox.Checked)
                {
                    dpOPV1Given.Enabled = true;
                    dpOPV1Given.Value = dpOPV1Due.Value;
                }
                else
                {
                    dpOPV1Given.Enabled = false;
                }
            }
            else if (strChkName == "chkOPV2")
            {
                if (checkbox.Checked)
                {
                    dpOPV2Given.Enabled = true;
                    dpOPV2Given.Value = dpOPV2Due.Value;

                }
                else
                {
                    dpOPV2Given.Enabled = false;
                }
            }
            else if (strChkName == "chkDPT1")
            {
                if (checkbox.Checked)
                {
                    dpDPT1Given.Enabled = true;
                    dpDPT1Given.Value = dpDPT1Due.Value;
                }
                else
                {
                    dpDPT1Given.Enabled = false;
                }
            }
            else if (strChkName == "chkHB2")
            {
                if (checkbox.Checked)
                {
                    dpHB2Given.Enabled = true;
                    dpHB2Given.Value = dpHB2Due.Value;
                }
                else
                {
                    dpHB2Given.Enabled = false;
                }
            }
            else if (strChkName == "chkHIB1")
            {
                if (checkbox.Checked)
                {
                    dpHIB1Given.Enabled = true;
                    dpHIB1Given.Value = dpHIB1Due.Value;
                }
                else
                {
                    dpHIB1Given.Enabled = false;
                }
            }
            else if (strChkName == "chkPCV1")
            {
                if (checkbox.Checked)
                {
                    dpPCV1Given.Enabled = true;
                    dpPCV1Given.Value = dpPCV1Due.Value;
                }
                else
                {
                    dpPCV1Given.Enabled = false;
                }
            }
            else if (strChkName == "chkRotarix1")
            {
                if (checkbox.Checked)
                {
                    dpRotarix1G.Enabled = true;
                    dpRotarix1G.Value = dpRotarix1D.Value;
                }
                else
                {
                    dpRotarix1G.Enabled = false;
                }
            }
            else if (strChkName == "chkDPT2")
            {
                if (checkbox.Checked)
                {
                    dpDPT2G.Enabled = true;
                    dpDPT2G.Value = dpDPT2D.Value;
                }
                else
                {
                    dpDPT2G.Enabled = false;
                }
            }
            else if (strChkName == "chkOPV3")
            {
                if (checkbox.Checked)
                {
                    dpOPV3G.Enabled = true;
                    dpOPV3G.Value = dpOPV3D.Value;
                }
                else
                    dpOPV3G.Enabled = false;
            }
        }

        private void chkHIB2_CheckedChanged(object sender, EventArgs e)
        {
            var checkbox = sender as CheckBox;
            string strChkName = checkbox.Name;

            if (strChkName == "chkHIB2")
            {
                if (checkbox.Checked)
                {
                    dpHIB2G.Enabled = true;
                    dpHIB2G.Value = dpHIB2D.Value;
                }
                else
                {
                    dpHIB2G.Enabled = false;
                }
            }
            else if (strChkName == "chkOPV4")
            {
                if (checkbox.Checked)
                {
                    dpOPV4G.Enabled = true;
                    dpOPV4G.Value = dpOPV4D.Value;
                }
                else
                {
                    dpOPV4G.Enabled = false;
                }
            }
            else if (strChkName == "chkDPT3")
            {
                if (checkbox.Checked)
                {
                    dpDPT3G.Enabled = true;
                    dpDPT3G.Value = dpDPT3D.Value;
                }
                else
                {
                    dpDPT3G.Enabled = false;
                }
            }
            else if (strChkName == "chkHB3")
            {
                if (checkbox.Checked)
                {
                    dpHB3G.Enabled = true;
                    dpHB3G.Value = dpHB3D.Value;
                }
                else
                {
                    dpHB3G.Enabled = false;
                }
            }
            else if (strChkName == "chkHIB3")
            {
                if (checkbox.Checked)
                {
                    dpHIB3G.Enabled = true;
                    dpHIB3G.Value = dpHIB3D.Value;
                }
                else
                {
                    dpHIB3G.Enabled = false;
                }
            }
            else if (strChkName == "chkPCV2")
            {
                if (checkbox.Checked)
                {
                    dpPCV2G.Enabled = true;
                    dpPCV2G.Value = dpPCV2D.Value;
                }
                else
                {
                    dpPCV2G.Enabled = false;
                }
            }
            else if (strChkName == "chkRotarix2")
            {
                if (checkbox.Checked)
                {
                    dpRotarix2G.Enabled = true;
                    dpRotarix2G.Value = dpRotarix2D.Value;
                }
                else
                {
                    dpRotarix2G.Enabled = false;
                }
            }
            else if (strChkName == "chkPCV3")
            {
                if (checkbox.Checked)
                {
                    dpPCV3G.Enabled = true;
                    dpPCV3G.Value = dpPCV3D.Value;
                }
                else
                {
                    dpPCV3G.Enabled = false;
                }
            }
            else if (strChkName == "chkMeasles")
            {
                if (checkbox.Checked)
                {
                    dpMeaslesG.Enabled = true;
                    dpMeaslesG.Value = dpMeaslesD.Value;
                }
                else
                {
                    dpMeaslesG.Enabled = false;
                }
            }
            else if (strChkName == "chkVaricella1")
            {
                if (checkbox.Checked)
                {
                    dpVaricella1G.Enabled = true;
                    dpVaricella1G.Value = dpVaricella1D.Value;
                }
                else
                {
                    dpVaricella1G.Enabled = false;
                }
            }
            else if (strChkName == "chkPCVBooster")
            {
                if (checkbox.Checked)
                {
                    dpPCVBoosterG.Enabled = true;
                    dpPCVBoosterG.Value = dpPCVBoosterD.Value;
                }
                else
                {
                    dpPCVBoosterG.Enabled = false;
                }
            }
        }

        private void chkMMR_CheckedChanged(object sender, EventArgs e)
        {
            var checkbox = sender as CheckBox;
            string strChkName = checkbox.Name;

            if (strChkName == "chkMMR")
            {
                if (checkbox.Checked)
                {
                    dpMMRG.Enabled = true;
                    dpMMRG.Value = dpMMRD.Value;
                }
                else
                {
                    dpMMRG.Enabled = false;
                }
            }
            else if (strChkName == "chkVaricella2")
            {
                if (checkbox.Checked)
                {
                    dpVaricella2G.Enabled = true;
                    dpVaricella2G.Value = dpVaricella2D.Value;
                }
                else
                {
                    dpVaricella2G.Enabled = false;
                }
            }
            else if (strChkName == "chkDPTBooster1")
            {
                if (checkbox.Checked)
                {
                    dpDPTBooster1G.Enabled = true;
                    dpDPTBooster1G.Value = dpDPTBooster1D.Value;
                }
                else
                {
                    dpDPTBooster1G.Enabled = false;
                }
            }
            else if (strChkName == "chkHIBBooster")
            {
                if (checkbox.Checked)
                {
                    dpHIBBoosterG.Enabled = true;
                    dpHIBBoosterG.Value = dpHIBBoosterD.Value;
                }
                else
                {
                    dpHIBBoosterG.Enabled = false;
                }
            }
            else if (strChkName == "chkOPVBooster")
            {
                if (checkbox.Checked)
                {
                    dpOPVBoosterG.Enabled = true;
                    dpOPVBoosterG.Value = dpOPVBoosterD.Value;
                }
                else
                {
                    dpOPVBoosterG.Enabled = false;
                }
            }
            else if (strChkName == "chkHA1")
            {
                if (checkbox.Checked)
                {
                    dpHA1G.Enabled = true;
                    dpHA1G.Value = dpHA1D.Value;
                }
                else
                {
                    dpHA1G.Enabled = false;
                }
            }
            else if (strChkName == "chkTyphoid")
            {
                if (checkbox.Checked)
                {
                    dpTyphoidG.Enabled = true;
                    dpTyphoidG.Value = dpTyphoidD.Value;
                }
                else
                {
                    dpTyphoidG.Enabled = false;
                }
            }
            else if (strChkName == "chkHA2")
            {
                if (checkbox.Checked)
                {
                    dpHA2G.Enabled = true;
                    dpHA2G.Value = dpHA2D.Value;
                }
                else
                {
                    dpHA2G.Enabled = false;
                }
            }
            else if (strChkName == "chkDPTBooster2")
            {
                if (checkbox.Checked)
                {
                    dpDPTBooster2G.Enabled = true;
                    dpDPTBooster2G.Value = dpDPTBooster2D.Value;
                }
                else
                {
                    dpDPTBooster2G.Enabled = false;
                }
            }
            else if (strChkName == "chkOPVBooster2")
            {
                if (checkbox.Checked)
                {
                    dpOPVBooster2G.Enabled = true;
                    dpOPVBooster2G.Value = dpOPVBooster2D.Value;
                }
                else
                {
                    dpOPVBooster2G.Enabled = false;
                }
            }
            else if (strChkName == "chkMMR2")
            {
                if (checkbox.Checked)
                {
                    dpMMR2G.Enabled = true;
                    dpMMR2G.Value = dpMMR2D.Value;
                }
                else
                {
                    dpMMR2G.Enabled = false;
                }
            }
        }

        private void chkVaricellaBooster_CheckedChanged(object sender, EventArgs e)
        {
            var checkbox = sender as CheckBox;
            string strChkName = checkbox.Name;

            if (strChkName == "chkVaricellaBooster")
            {
                if (checkbox.Checked)
                {
                    dpVaricellaBoosterG.Enabled = true;
                    dpVaricellaBoosterG.Value = dpVaricellaBoosterD.Value;
                }
                else
                {
                    dpVaricellaBoosterG.Enabled = false;
                }
            }
            else if (strChkName == "chkHBB")
            {
                if (checkbox.Checked)
                {
                    dpHBBG.Enabled = true;
                    dpHBBG.Value = dpHBBD.Value;
                }
                else
                {
                    dpHBBG.Enabled = false;
                }
            }
            else if (strChkName == "chkTyphoid2")
            {
                if (checkbox.Checked)
                {
                    dpTyphoid2G.Enabled = true;
                    dpTyphoid2G.Value = dpTyphoid2D.Value;
                }
                else
                {
                    dpTyphoid2G.Enabled = false;
                }
            }
            else if (strChkName == "chkTyphoid3")
            {
                if (checkbox.Checked)
                {
                    dpTyphoid3G.Enabled = true;
                    dpTyphoid3G.Value = dpTyphoid3D.Value;
                }
                else
                {
                    dpTyphoid3G.Enabled = false;
                }
            }
            else if (strChkName == "chkTBooster1")
            {
                if (checkbox.Checked)
                {
                    dpTBooster1G.Enabled = true;
                    dpTBooster1G.Value = dpTBooster1D.Value;
                }
                else
                {
                    dpTBooster1G.Enabled = false;
                }
            }
            else if (strChkName == "chkTyphoid4")
            {
                if (checkbox.Checked)
                {
                    dpTyphoid4G.Enabled = true;
                    dpTyphoid4G.Value = dpTyphoid4D.Value;
                }
                else
                {
                    dpTyphoid4G.Enabled = false;
                }
            }
            else if (strChkName == "chkTyphoid5")
            {
                if (checkbox.Checked)
                {
                    dpTyphoid5G.Enabled = true;
                    dpTyphoid5G.Value = dpTyphoid5D.Value;
                }
                else
                {
                    dpTyphoid5G.Enabled = false;
                }
            }
            else if (strChkName == "chkTBooster2")
            {
                if (checkbox.Checked)
                {
                    dpTBooster2G.Enabled = true;
                    dpTBooster2G.Value = dpTBooster2D.Value;
                }
                else
                {
                    dpTBooster2G.Enabled = false;
                }
            }
            
        }

        #endregion

        private void dpDOB_ValueChanged(object sender, EventArgs e)
        {
            DateTime dob = dpDOB.Value;

            dpBGCDue.Value = dob;
            dpHB1Due.Value = dob;
            dpOPV1Due.Value = dob;

            chkBCG.Checked = true;
            chkHB1.Checked = true;
            chkOPV1.Checked = true;
            dpBGCGiven.Value = dob;
            dpHB1Given.Value = dob;
            dpOPV1Given.Value = dob;

            dpOPV2Due.Value = dob.AddDays(7 * 6);
            dpDPT1Due.Value = dob.AddDays(7 * 6);
            dpHB2Due.Value = dob.AddDays(7 * 6);
            dpHIB1Due.Value = dob.AddDays(7 * 6);
            dpPCV1Due.Value = dob.AddDays(7 * 8);
            dpRotarix1D.Value = dob.AddDays(7 * 8);
            dpDPT2D.Value = dob.AddDays(7 * 10);
            dpOPV3D.Value = dob.AddDays(7 * 10);

            dpHIB2D.Value = dob.AddDays(7 * 10);
            dpOPV4D.Value = dob.AddDays(7 * 14);
            dpDPT3D.Value = dob.AddDays(7 * 14);
            dpHB3D.Value = dob.AddDays(7 * 14);
            dpHIB3D.Value = dob.AddDays(7 * 14);
            dpPCV2D.Value = dob.AddDays(7 * 16);
            dpRotarix2D.Value = dob.AddDays(7 * 24);
            dpPCV3D.Value = dob.AddDays(7 * 36);
            dpMeaslesD.Value = dob.AddMonths(12);
            dpVaricella1D.Value = dob.AddMonths(12);
            dpPCVBoosterD.Value = dob.AddMonths(15);

            dpMMRD.Value = dob.AddMonths(15);
            dpVaricella2D.Value = dob.AddMonths(18);
            dpDPTBooster1D.Value = dob.AddMonths(18);
            dpHIBBoosterD.Value = dob.AddMonths(18);
            dpOPVBoosterD.Value = dob.AddMonths(18);
            dpHA1D.Value = dob.AddMonths(24);
            dpTyphoidD.Value = dob.AddMonths(24);
            dpHA2D.Value = dob.AddYears(5);
            dpDPTBooster2D.Value = dob.AddYears(5);
            dpOPVBooster2D.Value = dob.AddYears(5);
            dpMMR2G.Value = dob.AddYears(5);

            dpVaricellaBoosterD.Value = dob.AddYears(5);
            dpHBBD.Value = dob.AddYears(5);
            dpTyphoid2D.Value = dob.AddYears(5);
            dpTyphoid3D.Value = dob.AddYears(8);
            dpTBooster1D.Value = dob.AddYears(10);
            dpTyphoid4D.Value = dob.AddYears(11);
            dpTyphoid5D.Value = dob.AddYears(14);
            dpTBooster2D.Value = dob.AddYears(16);
            //dpInfkuenzaD.Value = dob.AddYears(5);


        }

        private void dgPatients_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count == 0)
                    return;
                btnDelete.Enabled = true;
                btnPrint.Enabled = true;
                btnOpen.Enabled = true;
                btnEdit.Enabled = true;
                btnEmail.Enabled = true;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("dgPatients_CellClick()-->" + ex.Message);
            }
        }

        private void dgPatients_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                btnOpen.PerformClick();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("dgPatients_CellDoubleClick()-->" + ex.Message);
            }
        }

        private void dgPatients_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex > -1)
            {
                dgPatients.ClearSelection();
                dgPatients.Rows[e.RowIndex].Selected = true;
                btnDelete.Enabled = true;
                btnPrint.Enabled = true;
                btnOpen.Enabled = true;
                btnEdit.Enabled = true;
                btnEmail.Enabled = true;
            }
        }

        private void dgPatients_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            dgPatients.ClearSelection();
            btnDelete.Enabled = false;
            btnPrint.Enabled = false;
            btnOpen.Enabled = false;
            btnEdit.Enabled = false;
            btnEmail.Enabled = false;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSearch.Text.Trim()))
                btnSearch.PerformClick();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim().ToLower();
            if (searchText == "enter child name")
                searchText = "";
            if(!string.IsNullOrEmpty(searchText))
                getData(searchText);

        }
    }
}
