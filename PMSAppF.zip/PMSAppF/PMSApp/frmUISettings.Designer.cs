﻿namespace PMSApp
{
    partial class frmUISettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUISettings));
            this.lblBGColor = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtClinicName = new System.Windows.Forms.TextBox();
            this.pbBackground = new System.Windows.Forms.PictureBox();
            this.pbClinic = new System.Windows.Forms.PictureBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.btnClose = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.cmbboxClr = new System.Windows.Forms.ComboBox();
            this.lblBColor = new System.Windows.Forms.Label();
            this.lblCColor = new System.Windows.Forms.Label();
            this.cmbboxClr1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbFontSize = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbColorInterval = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbBackground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClinic)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBGColor
            // 
            this.lblBGColor.AutoSize = true;
            this.lblBGColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBGColor.Location = new System.Drawing.Point(14, 131);
            this.lblBGColor.Name = "lblBGColor";
            this.lblBGColor.Size = new System.Drawing.Size(125, 15);
            this.lblBGColor.TabIndex = 0;
            this.lblBGColor.Text = "Background Color:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Clinic Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Clinic Name Color:";
            // 
            // txtClinicName
            // 
            this.txtClinicName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClinicName.Location = new System.Drawing.Point(144, 29);
            this.txtClinicName.Name = "txtClinicName";
            this.txtClinicName.Size = new System.Drawing.Size(177, 21);
            this.txtClinicName.TabIndex = 3;
            this.txtClinicName.Text = "Sri Sai Kalpana Clinic";
            // 
            // pbBackground
            // 
            this.pbBackground.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pbBackground.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbBackground.Location = new System.Drawing.Point(145, 118);
            this.pbBackground.Name = "pbBackground";
            this.pbBackground.Size = new System.Drawing.Size(101, 42);
            this.pbBackground.TabIndex = 5;
            this.pbBackground.TabStop = false;
            this.toolTip1.SetToolTip(this.pbBackground, "Click here to change form background color");
            // 
            // pbClinic
            // 
            this.pbClinic.BackColor = System.Drawing.Color.Red;
            this.pbClinic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbClinic.Location = new System.Drawing.Point(145, 63);
            this.pbClinic.Name = "pbClinic";
            this.pbClinic.Size = new System.Drawing.Size(101, 42);
            this.pbClinic.TabIndex = 4;
            this.pbClinic.TabStop = false;
            this.toolTip1.SetToolTip(this.pbClinic, "Click here to change clinic name color");
            // 
            // btnClear
            // 
            this.btnClear.Image = global::PMSApp.Properties.Resources.Cleaner_16x16;
            this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.Location = new System.Drawing.Point(209, 202);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(59, 27);
            this.btnClear.TabIndex = 31;
            this.btnClear.Text = "Reset";
            this.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(145, 202);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(57, 27);
            this.btnSave.TabIndex = 30;
            this.btnSave.Text = "Save";
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Image = global::PMSApp.Properties.Resources.Close_16x16;
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(274, 202);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(57, 27);
            this.btnClose.TabIndex = 32;
            this.btnClose.Text = "Close";
            this.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 100;
            this.toolTip1.BackColor = System.Drawing.Color.Maroon;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // cmbboxClr
            // 
            this.cmbboxClr.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbboxClr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbboxClr.FormattingEnabled = true;
            this.cmbboxClr.Location = new System.Drawing.Point(248, 66);
            this.cmbboxClr.Name = "cmbboxClr";
            this.cmbboxClr.Size = new System.Drawing.Size(216, 21);
            this.cmbboxClr.TabIndex = 35;
            this.cmbboxClr.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cmbboxClr_DrawItem);
            this.cmbboxClr.SelectedIndexChanged += new System.EventHandler(this.cmbboxClr_SelectedIndexChanged);
            // 
            // lblBColor
            // 
            this.lblBColor.AutoSize = true;
            this.lblBColor.Location = new System.Drawing.Point(248, 147);
            this.lblBColor.Name = "lblBColor";
            this.lblBColor.Size = new System.Drawing.Size(75, 13);
            this.lblBColor.TabIndex = 34;
            this.lblBColor.Text = "LightSteelBlue";
            // 
            // lblCColor
            // 
            this.lblCColor.AutoSize = true;
            this.lblCColor.Location = new System.Drawing.Point(250, 91);
            this.lblCColor.Name = "lblCColor";
            this.lblCColor.Size = new System.Drawing.Size(27, 13);
            this.lblCColor.TabIndex = 33;
            this.lblCColor.Text = "Red";
            // 
            // cmbboxClr1
            // 
            this.cmbboxClr1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbboxClr1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbboxClr1.FormattingEnabled = true;
            this.cmbboxClr1.Location = new System.Drawing.Point(249, 121);
            this.cmbboxClr1.Name = "cmbboxClr1";
            this.cmbboxClr1.Size = new System.Drawing.Size(216, 21);
            this.cmbboxClr1.TabIndex = 36;
            this.cmbboxClr1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cmbboxClr_DrawItem);
            this.cmbboxClr1.SelectedIndexChanged += new System.EventHandler(this.cmbboxClr1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(323, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 15);
            this.label3.TabIndex = 37;
            this.label3.Text = "Font Size:";
            // 
            // cmbFontSize
            // 
            this.cmbFontSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFontSize.FormattingEnabled = true;
            this.cmbFontSize.Items.AddRange(new object[] {
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.cmbFontSize.Location = new System.Drawing.Point(396, 30);
            this.cmbFontSize.Name = "cmbFontSize";
            this.cmbFontSize.Size = new System.Drawing.Size(67, 21);
            this.cmbFontSize.TabIndex = 38;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 15);
            this.label4.TabIndex = 39;
            this.label4.Text = "Color Interval:";
            // 
            // cmbColorInterval
            // 
            this.cmbColorInterval.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbColorInterval.FormattingEnabled = true;
            this.cmbColorInterval.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "15",
            "20",
            "25",
            "30",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.cmbColorInterval.Location = new System.Drawing.Point(145, 171);
            this.cmbColorInterval.Name = "cmbColorInterval";
            this.cmbColorInterval.Size = new System.Drawing.Size(101, 21);
            this.cmbColorInterval.TabIndex = 40;
            // 
            // frmUISettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(474, 244);
            this.Controls.Add(this.cmbColorInterval);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbFontSize);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbboxClr1);
            this.Controls.Add(this.cmbboxClr);
            this.Controls.Add(this.lblBColor);
            this.Controls.Add(this.lblCColor);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.pbBackground);
            this.Controls.Add(this.pbClinic);
            this.Controls.Add(this.txtClinicName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblBGColor);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmUISettings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "GPApps :: UI Settings";
            this.Load += new System.EventHandler(this.frmUISettings_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbBackground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClinic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBGColor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtClinicName;
        private System.Windows.Forms.PictureBox pbClinic;
        private System.Windows.Forms.PictureBox pbBackground;
        internal System.Windows.Forms.Button btnClear;
        internal System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ColorDialog colorDialog1;
        internal System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox cmbboxClr;
        private System.Windows.Forms.Label lblBColor;
        private System.Windows.Forms.Label lblCColor;
        private System.Windows.Forms.ComboBox cmbboxClr1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbFontSize;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbColorInterval;
    }
}