﻿using Spire.Doc;
using Spire.Doc.Documents;
using Spire.Doc.Fields;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmRevisit : Form
    {
        string UncPath = System.Configuration.ConfigurationManager.AppSettings["FilesPath"].ToString();
        string bullet = System.Configuration.ConfigurationManager.AppSettings["BulletSymbol"].ToString();

        string strToDay = DateTime.Now.Day.ToString("D2") + "-" + DateTime.Now.Month.ToString("D2") + "-" + DateTime.Now.Year.ToString("D4");

        //word document object
        Document document = null;
        AutoCompleteStringCollection UnitsCollection = new AutoCompleteStringCollection();

        public frmRevisit()
        {
            InitializeComponent();

            txtValue.ForeColor = Color.LightGray;
            txtValue.Text = "Value";
            this.txtValue.Leave += new System.EventHandler(this.txtValue_Leave);
            this.txtValue.Enter += new System.EventHandler(this.txtValue_Enter);

            txtUnits.ForeColor = Color.LightGray;
            txtUnits.Text = "Units";
            this.txtUnits.Leave += new System.EventHandler(this.txtUnits_Leave);
            this.txtUnits.Enter += new System.EventHandler(this.txtUnits_Enter);

            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
        }

        private void txtValue_Leave(object sender, EventArgs e)
        {
            if (txtValue.Text == "")
            {
                txtValue.Text = "Value";
                txtValue.Font = new Font(txtValue.Font, FontStyle.Italic);
                txtValue.ForeColor = Color.Gray;
            }
        }

        private void txtValue_Enter(object sender, EventArgs e)
        {
            if (txtValue.Text == "Value")
            {
                txtValue.Text = "";
                txtValue.Font = new Font(txtValue.Font, FontStyle.Regular);
                txtValue.ForeColor = Color.Black;
            }
        }
        private void txtUnits_Leave(object sender, EventArgs e)
        {
            if (txtUnits.Text == "")
            {
                txtUnits.Text = "Units";
                txtUnits.Font = new Font(txtUnits.Font, FontStyle.Italic);
                txtUnits.ForeColor = Color.Gray;
            }
        }

        private void txtUnits_Enter(object sender, EventArgs e)
        {
            if (txtUnits.Text == "Units")
            {
                txtUnits.Text = "";
                txtUnits.Font = new Font(txtUnits.Font, FontStyle.Regular);
                txtUnits.ForeColor = Color.Black;
            }
        }

        private void frmRevisit_Load(object sender, EventArgs e)
        {
            try
            {
                txtPName.Text = !string.IsNullOrEmpty(frmHome.patientNameForMail) ? frmHome.patientNameForMail.ToUpper().Replace("_Rev","") : string.Empty;
                getMedicine();
                getSymptoms();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("frmHome_Load()-->" + ex.Message);
            }
        }
        private void getMedicine()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.MedicineListExcelPath))
                {
                    MessageBox.Show("Medicine list: " + Path.GetFileName(GloabalFunctions.MedicineListExcelPath) + " not exists" + "\r\n" + "Please place medicine list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.MedicineListExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.MedicineListExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtMedicineSearch.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtMedicineSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtMedicineSearch.AutoCompleteCustomSource = MyCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getMedicine()-->" + ex.Message);
            }
        }

        private void getSymptoms()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.SymptomsExcelPath))
                {
                    MessageBox.Show("Symptoms list: " + Path.GetFileName(GloabalFunctions.SymptomsExcelPath) + " not exists" + "\r\n" + "Please place Symptoms list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.SymptomsExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.SymptomsExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtSymptoms.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtSymptoms.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtSymptoms.AutoCompleteCustomSource = MyCollection;
                }
                if (UnitsCollection != null && UnitsCollection.Count > 0)
                {
                    txtUnits.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtUnits.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtUnits.AutoCompleteCustomSource = UnitsCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getSymptoms()-->" + ex.Message);
            }
        }
        private AutoCompleteStringCollection getAutoCompleteCollection(string path)
        {
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            try
            {
                string connString = "";
                if (!File.Exists(path))
                {
                    GloabalFunctions.WriteLog("File not exists: " + path);
                    return null;
                }

                if (GloabalFunctions.closeOpenedExcel(path))
                    System.Threading.Thread.Sleep(100);
                string strFileType = Path.GetExtension(path).ToLower();
                string sheetName = "";
                string sheetName2 = "";
                if (strFileType.Trim() == ".xls")
                {
                    //connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=Excel 8.0;";
                }
                else if (strFileType.Trim() == ".xlsx")
                {
                    //connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 12.0;";
                }

                //Get the name of the First Sheet.
                using (OleDbConnection con = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmd = new OleDbCommand())
                    {
                        cmd.Connection = con;
                        con.Open();
                        DataTable dtExcelSchema = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                        if (path.Contains("Symptoms.xls"))
                            sheetName2 = dtExcelSchema.Rows[1]["TABLE_NAME"].ToString();
                        con.Close();
                    }
                }
                //Read Data from the First Sheet.
                using (OleDbConnection con = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmd = new OleDbCommand())
                    {
                        using (OleDbDataAdapter oda = new OleDbDataAdapter())
                        {
                            //string query = "SELECT [UserName],[Education],[Location] FROM [Sheet1$]";
                            DataTable dt = new DataTable();
                            cmd.CommandText = "SELECT * From [" + sheetName + "]";
                            cmd.Connection = con;
                            con.Open();
                            oda.SelectCommand = cmd;
                            oda.Fill(dt);
                            //DataSet ds = new DataSet();
                            //da.Fill(ds);

                            if (dt != null && dt.Rows.Count > 0)
                            {
                                //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (dr[0] != DBNull.Value)
                                        MyCollection.Add(dr[0].ToString().Trim());
                                }
                            }

                            if (path.Contains("Symptoms.xls"))
                            {
                                dt = new DataTable();
                                cmd.CommandText = "SELECT * From [" + sheetName2 + "]";
                                oda.SelectCommand = cmd;
                                oda.Fill(dt);
                                con.Close();

                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                                    foreach (DataRow dr in dt.Rows)
                                    {
                                        if (dr[0] != DBNull.Value)
                                            UnitsCollection.Add(dr[0].ToString().Trim());
                                    }
                                }
                            }

                            con.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getAutoCompleteCollection()-->" + ex.Message);
                return null;
            }
            return MyCollection;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string strPName = txtPName.Text.Trim();
                string strCO = txtCO.Text.Trim();
                string strRx = txtRx.Text.Trim();
                string strTemp = txtTemparature.Text.Trim();
                string strBP = txtBP.Text.Trim() + "mmHg";
                string strPR = txtPulse.Text.Trim();

                if (string.IsNullOrEmpty(strPName))
                {
                    MessageBox.Show("Please enter patient name.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (string.IsNullOrEmpty(strCO) || string.IsNullOrEmpty(strRx))
                {
                    MessageBox.Show("Please enter mandatory data.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (!Directory.Exists(UncPath + "\\" + strToDay))
                    Directory.CreateDirectory(UncPath + "\\" + strToDay);

                string strDate = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt");
                string docxPath = UncPath + "\\" + strToDay + "\\" + strPName.Replace(".", "_") + "_Rev" + ".docx";
                document = new Document();
                Paragraph paragraph;
                Section sec;
                if (File.Exists(docxPath))
                {
                    document.LoadFromFile(docxPath);
                    sec = document.Sections[0];
                    paragraph = sec.AddParagraph(); //Get a paragraph    
                }
                else
                {
                    document.LoadFromFile(GloabalFunctions.BlankTemplatePath);
                    sec = document.Sections[0];
                    paragraph = sec.Paragraphs.Count>0? sec.Paragraphs[0] : sec.AddParagraph();
                }

                //string paraTxt = "Date: " + strDate + "\r\n";
                //paraTxt += "Temp: " + strTemp + "°F  B.P: " + strBP + "  PR: " + strPR + "/Min";
                //Append Text    
                //paragraph.AppendText(paraTxt);
                //paragraph.Format.LineSpacing = 1;

                //set the spacing before and after
                paragraph.Format.BeforeSpacing = 0;
                paragraph.Format.AfterSpacing = 0;

                //Data Format
                TextRange TR = paragraph.AppendText("Date: ");
                //TR.CharacterFormat.FontName = "Calibri";
                //TR.CharacterFormat.FontSize = 14;
                TR.CharacterFormat.TextColor = Color.Blue;
                TR.CharacterFormat.Bold = true;
                paragraph.AppendText(strDate + "\r\n");

                TR = paragraph.AppendText("Temp: ");
                TR.CharacterFormat.TextColor = Color.Blue;
                TR.CharacterFormat.Bold = true;
                paragraph.AppendText(strTemp + "°F");

                TR = paragraph.AppendText("  B.P: ");
                TR.CharacterFormat.TextColor = Color.Blue;
                TR.CharacterFormat.Bold = true;
                paragraph.AppendText(strBP);

                TR = paragraph.AppendText("  PR: ");
                TR.CharacterFormat.TextColor = Color.Blue;
                TR.CharacterFormat.Bold = true;
                paragraph.AppendText(strPR + "/Min");

                Table table = sec.AddTable(true);
                
                //Add Cells
                table.ResetCells(1, 2);
                TableRow FRow = table.Rows[0];
                //FRow.Cells[0].Width = 37;
                //FRow.Cells[1].Width = 63;
                FRow.Cells[0].CellWidthType = CellWidthType.Auto;
                FRow.Cells[1].CellWidthType = CellWidthType.Auto;


                Paragraph p = FRow.Cells[0].AddParagraph();
                
                TR = p.AppendText("C/O \r\n");
                TR.CharacterFormat.TextColor = Color.Red;
                TR.CharacterFormat.Bold = true;
                p.AppendText(strCO);

                //FRow.Cells[1].CellWidthType = CellWidthType.Auto;
                p = FRow.Cells[1].AddParagraph();
                TR = p.AppendText("Rx \r\n");
                TR.CharacterFormat.TextColor = Color.Red;
                TR.CharacterFormat.Bold = true;
                p.AppendText(strRx);

                sec.AddParagraph();

                //Save doc file.    
                document.SaveToFile(docxPath, FileFormat.Docx);
                //document.Clone();
                DialogResult dialogResult = MessageBox.Show("Patient data saved successfully.\r\n Click on Yes to open file. \r\n Click on Cancel to print.", "GPApps :: PMS", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                if (dialogResult == DialogResult.Yes)
                {
                    System.Diagnostics.Process.Start(docxPath);
                }
                else if(dialogResult == DialogResult.Cancel)
                {
                    GloabalFunctions.printFile(docxPath);
                }
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                GloabalFunctions.WriteLog("Revisit-btnSave_Click()-->" + ex.Message);
            }
        }

        private void createDoc()
        {
            //Section -1
            //Creating New Word
            Spire.Doc.Document doc = new Spire.Doc.Document();
            //Adding Section
            Spire.Doc.Section section = doc.AddSection();

            //Section -2
            //Adding Header
            Spire.Doc.HeaderFooter header = section.HeadersFooters.Header;
            Spire.Doc.Documents.Paragraph headerParagraph = header.AddParagraph();
            headerParagraph.Format.HorizontalAlignment = Spire.Doc.Documents.HorizontalAlignment.Center;
            headerParagraph.Format.Borders.Bottom.BorderType = Spire.Doc.Documents.BorderStyle.ThickThinMediumGap;
            headerParagraph.Format.Borders.Bottom.Space = 0.05f;
            headerParagraph.Format.Borders.Bottom.Color = System.Drawing.Color.Navy;
            //Adding and formating Header Paragraph
            Spire.Doc.Fields.TextRange headerText = headerParagraph.AppendText("Creating Docs Using Spire Doc Library");
            headerText.CharacterFormat.FontName = "Cambria";
            headerText.CharacterFormat.FontSize = 15;
            headerText.CharacterFormat.TextColor = System.Drawing.Color.Navy;

            ////Section -3
            //Spire.Doc.Documents.Paragraph paragraph0 = section.AddParagraph();

            //Adding paragraph to document
            Spire.Doc.Documents.Paragraph paragraph = section.AddParagraph();

            //Append Text
            paragraph.AppendText("Hello! "
            + "I was created by Spire.Doc for WPF, it's a professional .NET Word component "
            + "which enables developers to perform a large range of tasks on Word document (such as create, open, write, edit, save and convert "
            + "Word document) without installing Microsoft Office and any other third-party tools on system.");
            paragraph.Format.HorizontalAlignment = Spire.Doc.Documents.HorizontalAlignment.Justify;
            paragraph.Format.AfterSpacing = 15;
            paragraph.Format.BeforeSpacing = 20;
            //Adding another paragrhap

            Spire.Doc.Documents.Paragraph paragraph1 = section.AddParagraph();
            paragraph1.AppendText("Hello! "
           + "I was created by Spire.Doc for WPF, it's a professional .NET Word component "
           + "which enables developers to perform a large range of tasks on Word document (such as create, open, write, edit, save and convert "
           + "Word document) without installing Microsoft Office and any other third-party tools on system.");
            paragraph1.Format.HorizontalAlignment = Spire.Doc.Documents.HorizontalAlignment.Justify;
            paragraph1.Format.AfterSpacing = 15;

            //Section -4
            Spire.Doc.Documents.Paragraph paragraph2 = section.AddParagraph();

            Spire.Doc.Fields.DocPicture image = paragraph2.AppendPicture(System.Drawing.Image.FromFile(@"D:\Icons collection\pms\PMSEmail.png"));
            image.VerticalAlignment = Spire.Doc.ShapeVerticalAlignment.Center;
            image.HorizontalAlignment = Spire.Doc.ShapeHorizontalAlignment.Center;
            image.Width = 500;
            image.Height = 500;

            //Section -5
            //Adding footer
            Spire.Doc.HeaderFooter footer = section.HeadersFooters.Footer;
            Spire.Doc.Documents.Paragraph footerParagraph = footer.AddParagraph();
            footerParagraph.Format.HorizontalAlignment = Spire.Doc.Documents.HorizontalAlignment.Center;
            footerParagraph.Format.Borders.Bottom.BorderType = Spire.Doc.Documents.BorderStyle.ThickThinMediumGap;
            footerParagraph.Format.Borders.Bottom.Space = 0.05f;
            footerParagraph.Format.Borders.Bottom.Color = System.Drawing.Color.Navy;
            //Adding and formating footer Paragraph
            Spire.Doc.Fields.TextRange footerText = footerParagraph.AppendText("This document is created by Kailash");
            footerText.CharacterFormat.FontName = "Cambria";
            footerText.CharacterFormat.FontSize = 15;
            footerText.CharacterFormat.TextColor = System.Drawing.Color.Gray;
            //Section -6
            //Save and launch
            doc.SaveToFile("D://MyDoc.docx", Spire.Doc.FileFormat.Docx);
            System.Diagnostics.Process.Start("D://MyDoc.docx");

        }

        private void CreateDoc1()
        {
            //Create Table
            Document doc = new Document();
            Section s = doc.AddSection();
            Table table = s.AddTable(true);

            //Create Header and Data
            String[] Header = { "Item", "Description", "Qty", "Unit Price", "Price" };
            String[][] data = {
                                  new String[]{ "Spire.Doc for .NET",".NET Word Component","1","$799.00","$799.00"},
                                  new String[]{"Spire.XLS for .NET",".NET Excel Component","2","$799.00","$1,598.00"},
                                  new String[]{"Spire.Office for .NET",".NET Office Component","1","$1,899.00","$1,899.00"},
                                  new String[]{"Spire.PDF for .NET",".NET PDFComponent","2","$599.00","$1,198.00"},
                              };
            //Add Cells
            table.ResetCells(data.Length + 1, Header.Length);

            //Header Row
            TableRow FRow = table.Rows[0];
            FRow.IsHeader = true;
            //Row Height
            FRow.Height = 23;
            //Header Format
            FRow.RowFormat.BackColor = Color.AliceBlue;
            for (int i = 0; i < Header.Length; i++)
            {
                //Cell Alignment
                Paragraph p = FRow.Cells[i].AddParagraph();
                FRow.Cells[i].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                p.Format.HorizontalAlignment = Spire.Doc.Documents.HorizontalAlignment.Center;
                //Data Format
                TextRange TR = p.AppendText(Header[i]);
                TR.CharacterFormat.FontName = "Calibri";
                TR.CharacterFormat.FontSize = 14;
                TR.CharacterFormat.TextColor = Color.Teal;
                TR.CharacterFormat.Bold = true;
            }

            //Data Row
            for (int r = 0; r < data.Length; r++)
            {
                TableRow DataRow = table.Rows[r + 1];

                //Row Height
                DataRow.Height = 20;

                //C Represents Column.
                for (int c = 0; c < data[r].Length; c++)
                {
                    //Cell Alignment
                    DataRow.Cells[c].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                    //Fill Data in Rows
                    Paragraph p2 = DataRow.Cells[c].AddParagraph();
                    TextRange TR2 = p2.AppendText(data[r][c]);
                    //Format Cells
                    p2.Format.HorizontalAlignment = Spire.Doc.Documents.HorizontalAlignment.Center;
                    TR2.CharacterFormat.FontName = "Calibri";
                    TR2.CharacterFormat.FontSize = 12;
                    TR2.CharacterFormat.TextColor = Color.Brown;
                }
            }

            //Save and Launch
            doc.SaveToFile("WordTable.docx", FileFormat.Docm2013);
            System.Diagnostics.Process.Start("WordTable.docx");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPName.Text = "";
            txtTemparature.Text = "";
            txtBP.Text = "";
            txtPulse.Text = "";
            txtCO.Text = "";
            txtRx.Text = "";
            txtSymptoms.Text = "";
            txtMedicineSearch.Text = "";

            txtValue.Text = "Value";
            txtValue.Font = new Font(txtValue.Font, FontStyle.Italic);
            txtValue.ForeColor = Color.Gray;

            txtUnits.Text = "Units";
            txtUnits.Font = new Font(txtUnits.Font, FontStyle.Italic);
            txtUnits.ForeColor = Color.Gray;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddSymptom_Click(object sender, EventArgs e)
        {
            string strTxt = txtSymptoms.Text.Trim();
            if (!string.IsNullOrEmpty(strTxt))
            {
                if (strTxt.Length == 1)
                    strTxt = char.ToUpper(strTxt[0]).ToString();
                else if (strTxt.Length > 1)
                    strTxt = char.ToUpper(strTxt[0]) + strTxt.Substring(1);


                string val = txtValue.Text.Trim();
                if (!string.IsNullOrEmpty(val) && val != "Value")
                {
                    int indx = strTxt.LastIndexOf(':');
                    if (indx > 0)
                        strTxt = strTxt.Remove(indx, 1).Insert(indx, ": " + val + " ");
                    else
                        strTxt = strTxt + ": " + val;
                }

                string unit = txtUnits.Text.Trim();
                if (!string.IsNullOrEmpty(unit) && unit != "Units")
                {
                    strTxt = strTxt + " " + unit;
                }

                txtCO.AppendText("\u2022 " + strTxt + Environment.NewLine);
                txtSymptoms.Text = "";

                txtValue.Text = "Value";
                txtValue.Font = new Font(txtValue.Font, FontStyle.Italic);
                txtValue.ForeColor = Color.Gray;

                txtUnits.Text = "Units";
                txtUnits.Font = new Font(txtUnits.Font, FontStyle.Italic);
                txtUnits.ForeColor = Color.Gray;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string strTxt = txtMedicineSearch.Text.Trim();
            //Bullet format
            //if (!string.IsNullOrEmpty(strTxt))
            //{
            //    if (strTxt.Length == 1)
            //        strTxt = char.ToUpper(strTxt[0]).ToString();
            //    else if (strTxt.Length > 1)
            //        strTxt = char.ToUpper(strTxt[0]) + strTxt.Substring(1);

            //    txtRx.AppendText("\u2022 " + strTxt + Environment.NewLine);
            //    txtMedicineSearch.Text = "";
            //}

            //         1‣ \u2023 (TRIANGULAR BULLET)
            //         2 ◦ \u25E6 (WHITE BULLET)
            //         3 ◉ \u25C9 (FISHEYE)
            //         4 ■ \u25A0 (BLACK SQUARE)
            //         5 □ \u25A1 (WHITE SQUARE)
            //         6 ❏ \u274F (LOWER RIGHT DROP-SHADOWED WHITE SQUARE)

            if (bullet == "1")
                bullet = "\u2023";
            else if (bullet == "2")
                bullet = "\u2022";
            else if (bullet == "3")
                bullet = "\u25C9";

            else if (bullet == "4")
                bullet = "\u25A0";
            else if (bullet == "5")
                bullet = "\u25A1";
            else if (bullet == "6")
                bullet = "\u274F";
            else if (bullet == "7")
                bullet = "\u25E6";


            //Number format
            if (!string.IsNullOrEmpty(strTxt))
            {
                if (strTxt.Length == 1)
                    strTxt = char.ToUpper(strTxt[0]).ToString();
                else if (strTxt.Length > 1)
                    strTxt = char.ToUpper(strTxt[0]) + strTxt.Substring(1);

                int n = 1;
                if (txtRx.Lines.Count() > 0)
                {
                    int noofLines = txtRx.Lines.Length;
                    string lastline = txtRx.Lines[noofLines - 1];
                    if (string.IsNullOrEmpty(lastline))
                    {
                        for (int i = 1; i <= noofLines; i++)
                        {
                            lastline = txtRx.Lines[noofLines - i];
                            if (!string.IsNullOrEmpty(lastline) && lastline.Contains(')'))
                                break;
                        }
                    }
                    string num = lastline.Split(')')[0].Replace(bullet, "");
                    //num = System.Text.RegularExpressions.Regex.Split(lastline, ")", System.Text.RegularExpressions.RegexOptions.None)[0];

                    if (int.TryParse(num, out n))
                        n = n + 1;
                    else
                        n = 1;

                    strTxt = bullet + n + ") " + strTxt;
                }
                else
                    strTxt = bullet + n + ") " + strTxt;

                txtRx.AppendText(strTxt + Environment.NewLine);
                txtMedicineSearch.Text = "";
            }
        }
    }
}
