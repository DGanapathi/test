﻿namespace PMSApp
{
    partial class frmVaccinationCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVaccinationCard));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblCont = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.cmbSex = new System.Windows.Forms.ComboBox();
            this.lblSex = new System.Windows.Forms.Label();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.lblPN = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblKgs = new System.Windows.Forms.Label();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMName = new System.Windows.Forms.TextBox();
            this.dpDOB = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.grbTab1 = new System.Windows.Forms.GroupBox();
            this.chkOPV3 = new System.Windows.Forms.CheckBox();
            this.chkDPT2 = new System.Windows.Forms.CheckBox();
            this.chkRotarix1 = new System.Windows.Forms.CheckBox();
            this.chkPCV1 = new System.Windows.Forms.CheckBox();
            this.chkHIB1 = new System.Windows.Forms.CheckBox();
            this.chkHB2 = new System.Windows.Forms.CheckBox();
            this.chkDPT1 = new System.Windows.Forms.CheckBox();
            this.chkOPV2 = new System.Windows.Forms.CheckBox();
            this.chkOPV1 = new System.Windows.Forms.CheckBox();
            this.chkHB1 = new System.Windows.Forms.CheckBox();
            this.chkBCG = new System.Windows.Forms.CheckBox();
            this.dpRotarix1G = new System.Windows.Forms.DateTimePicker();
            this.dpRotarix1D = new System.Windows.Forms.DateTimePicker();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.dpHIB1Given = new System.Windows.Forms.DateTimePicker();
            this.dpHIB1Due = new System.Windows.Forms.DateTimePicker();
            this.label67 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.chkGivenOn1 = new System.Windows.Forms.CheckBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.dpOPV3G = new System.Windows.Forms.DateTimePicker();
            this.dpOPV3D = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.dpDPT2G = new System.Windows.Forms.DateTimePicker();
            this.dpDPT2D = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dpPCV1Given = new System.Windows.Forms.DateTimePicker();
            this.dpPCV1Due = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.dpHB2Given = new System.Windows.Forms.DateTimePicker();
            this.dpHB2Due = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dpDPT1Given = new System.Windows.Forms.DateTimePicker();
            this.dpDPT1Due = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dpOPV2Given = new System.Windows.Forms.DateTimePicker();
            this.dpOPV2Due = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dpOPV1Given = new System.Windows.Forms.DateTimePicker();
            this.dpOPV1Due = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dpHB1Given = new System.Windows.Forms.DateTimePicker();
            this.dpHB1Due = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dpBGCGiven = new System.Windows.Forms.DateTimePicker();
            this.dpBGCDue = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.grbTab2 = new System.Windows.Forms.GroupBox();
            this.chkPCVBooster = new System.Windows.Forms.CheckBox();
            this.chkVaricella1 = new System.Windows.Forms.CheckBox();
            this.chkMeasles = new System.Windows.Forms.CheckBox();
            this.chkPCV3 = new System.Windows.Forms.CheckBox();
            this.chkRotarix2 = new System.Windows.Forms.CheckBox();
            this.chkPCV2 = new System.Windows.Forms.CheckBox();
            this.chkHIB3 = new System.Windows.Forms.CheckBox();
            this.chkHB3 = new System.Windows.Forms.CheckBox();
            this.chkDPT3 = new System.Windows.Forms.CheckBox();
            this.chkOPV4 = new System.Windows.Forms.CheckBox();
            this.chkHIB2 = new System.Windows.Forms.CheckBox();
            this.dpMeaslesG = new System.Windows.Forms.DateTimePicker();
            this.dpMeaslesD = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.dpRotarix2G = new System.Windows.Forms.DateTimePicker();
            this.dpRotarix2D = new System.Windows.Forms.DateTimePicker();
            this.label24 = new System.Windows.Forms.Label();
            this.chkGivenOn2 = new System.Windows.Forms.CheckBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.dpPCVBoosterG = new System.Windows.Forms.DateTimePicker();
            this.dpPCVBoosterD = new System.Windows.Forms.DateTimePicker();
            this.label30 = new System.Windows.Forms.Label();
            this.dpVaricella1G = new System.Windows.Forms.DateTimePicker();
            this.dpVaricella1D = new System.Windows.Forms.DateTimePicker();
            this.label32 = new System.Windows.Forms.Label();
            this.dpPCV3G = new System.Windows.Forms.DateTimePicker();
            this.dpPCV3D = new System.Windows.Forms.DateTimePicker();
            this.label34 = new System.Windows.Forms.Label();
            this.dpPCV2G = new System.Windows.Forms.DateTimePicker();
            this.dpPCV2D = new System.Windows.Forms.DateTimePicker();
            this.label36 = new System.Windows.Forms.Label();
            this.dpHIB3G = new System.Windows.Forms.DateTimePicker();
            this.dpHIB3D = new System.Windows.Forms.DateTimePicker();
            this.label38 = new System.Windows.Forms.Label();
            this.dpHB3G = new System.Windows.Forms.DateTimePicker();
            this.dpHB3D = new System.Windows.Forms.DateTimePicker();
            this.label40 = new System.Windows.Forms.Label();
            this.dpDPT3G = new System.Windows.Forms.DateTimePicker();
            this.dpDPT3D = new System.Windows.Forms.DateTimePicker();
            this.label42 = new System.Windows.Forms.Label();
            this.dpOPV4G = new System.Windows.Forms.DateTimePicker();
            this.dpOPV4D = new System.Windows.Forms.DateTimePicker();
            this.label81 = new System.Windows.Forms.Label();
            this.dpHIB2G = new System.Windows.Forms.DateTimePicker();
            this.dpHIB2D = new System.Windows.Forms.DateTimePicker();
            this.label84 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.grbTab3 = new System.Windows.Forms.GroupBox();
            this.label70 = new System.Windows.Forms.Label();
            this.chkMMR2 = new System.Windows.Forms.CheckBox();
            this.chkOPVBooster2 = new System.Windows.Forms.CheckBox();
            this.chkDPTBooster2 = new System.Windows.Forms.CheckBox();
            this.chkHA2 = new System.Windows.Forms.CheckBox();
            this.chkTyphoid = new System.Windows.Forms.CheckBox();
            this.chkHA1 = new System.Windows.Forms.CheckBox();
            this.chkOPVBooster = new System.Windows.Forms.CheckBox();
            this.chkHIBBooster = new System.Windows.Forms.CheckBox();
            this.chkDPTBooster1 = new System.Windows.Forms.CheckBox();
            this.chkVaricella2 = new System.Windows.Forms.CheckBox();
            this.chkMMR = new System.Windows.Forms.CheckBox();
            this.dpDPTBooster2G = new System.Windows.Forms.DateTimePicker();
            this.dpDPTBooster2D = new System.Windows.Forms.DateTimePicker();
            this.label31 = new System.Windows.Forms.Label();
            this.dpTyphoidG = new System.Windows.Forms.DateTimePicker();
            this.dpTyphoidD = new System.Windows.Forms.DateTimePicker();
            this.label44 = new System.Windows.Forms.Label();
            this.chkGivenOn3 = new System.Windows.Forms.CheckBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.dpMMR2G = new System.Windows.Forms.DateTimePicker();
            this.dpMMR2D = new System.Windows.Forms.DateTimePicker();
            this.label50 = new System.Windows.Forms.Label();
            this.dpOPVBooster2G = new System.Windows.Forms.DateTimePicker();
            this.dpOPVBooster2D = new System.Windows.Forms.DateTimePicker();
            this.label52 = new System.Windows.Forms.Label();
            this.dpHA2G = new System.Windows.Forms.DateTimePicker();
            this.dpHA2D = new System.Windows.Forms.DateTimePicker();
            this.label54 = new System.Windows.Forms.Label();
            this.dpHA1G = new System.Windows.Forms.DateTimePicker();
            this.dpHA1D = new System.Windows.Forms.DateTimePicker();
            this.label56 = new System.Windows.Forms.Label();
            this.dpOPVBoosterG = new System.Windows.Forms.DateTimePicker();
            this.dpOPVBoosterD = new System.Windows.Forms.DateTimePicker();
            this.label58 = new System.Windows.Forms.Label();
            this.dpHIBBoosterG = new System.Windows.Forms.DateTimePicker();
            this.dpHIBBoosterD = new System.Windows.Forms.DateTimePicker();
            this.label60 = new System.Windows.Forms.Label();
            this.dpDPTBooster1G = new System.Windows.Forms.DateTimePicker();
            this.dpDPTBooster1D = new System.Windows.Forms.DateTimePicker();
            this.label62 = new System.Windows.Forms.Label();
            this.dpVaricella2G = new System.Windows.Forms.DateTimePicker();
            this.dpVaricella2D = new System.Windows.Forms.DateTimePicker();
            this.label68 = new System.Windows.Forms.Label();
            this.dpMMRG = new System.Windows.Forms.DateTimePicker();
            this.dpMMRD = new System.Windows.Forms.DateTimePicker();
            this.label69 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.grbTab4 = new System.Windows.Forms.GroupBox();
            this.label72 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.chkTBooster2 = new System.Windows.Forms.CheckBox();
            this.chkTyphoid5 = new System.Windows.Forms.CheckBox();
            this.chkTyphoid4 = new System.Windows.Forms.CheckBox();
            this.chkTBooster1 = new System.Windows.Forms.CheckBox();
            this.chkTyphoid3 = new System.Windows.Forms.CheckBox();
            this.chkTyphoid2 = new System.Windows.Forms.CheckBox();
            this.chkHBB = new System.Windows.Forms.CheckBox();
            this.chkVaricellaBooster = new System.Windows.Forms.CheckBox();
            this.dpTyphoid5G = new System.Windows.Forms.DateTimePicker();
            this.dpTyphoid5D = new System.Windows.Forms.DateTimePicker();
            this.label73 = new System.Windows.Forms.Label();
            this.chkGivenOn4 = new System.Windows.Forms.CheckBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.dpTBooster2G = new System.Windows.Forms.DateTimePicker();
            this.dpTBooster2D = new System.Windows.Forms.DateTimePicker();
            this.label96 = new System.Windows.Forms.Label();
            this.dpTyphoid4G = new System.Windows.Forms.DateTimePicker();
            this.dpTyphoid4D = new System.Windows.Forms.DateTimePicker();
            this.label97 = new System.Windows.Forms.Label();
            this.dpTBooster1G = new System.Windows.Forms.DateTimePicker();
            this.dpTBooster1D = new System.Windows.Forms.DateTimePicker();
            this.label98 = new System.Windows.Forms.Label();
            this.dpTyphoid3G = new System.Windows.Forms.DateTimePicker();
            this.dpTyphoid3D = new System.Windows.Forms.DateTimePicker();
            this.label99 = new System.Windows.Forms.Label();
            this.dpTyphoid2G = new System.Windows.Forms.DateTimePicker();
            this.dpTyphoid2D = new System.Windows.Forms.DateTimePicker();
            this.label100 = new System.Windows.Forms.Label();
            this.dpHBBG = new System.Windows.Forms.DateTimePicker();
            this.dpHBBD = new System.Windows.Forms.DateTimePicker();
            this.label101 = new System.Windows.Forms.Label();
            this.dpVaricellaBoosterG = new System.Windows.Forms.DateTimePicker();
            this.dpVaricellaBoosterD = new System.Windows.Forms.DateTimePicker();
            this.label102 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.grbTab5 = new System.Windows.Forms.GroupBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dgPatients = new System.Windows.Forms.DataGridView();
            this.ChildName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbSearch = new System.Windows.Forms.GroupBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEmail = new System.Windows.Forms.Button();
            this.btnClear2 = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.lblCount = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.grbTab1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.grbTab2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.grbTab3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.grbTab4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPatients)).BeginInit();
            this.grbSearch.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(104, 102);
            this.txtAddress.MaxLength = 100;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(335, 22);
            this.txtAddress.TabIndex = 8;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(11, 105);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(58, 15);
            this.lblAddress.TabIndex = 43;
            this.lblAddress.Text = "Address";
            // 
            // lblCont
            // 
            this.lblCont.AutoSize = true;
            this.lblCont.BackColor = System.Drawing.Color.Transparent;
            this.lblCont.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCont.Location = new System.Drawing.Point(11, 78);
            this.lblCont.Name = "lblCont";
            this.lblCont.Size = new System.Drawing.Size(55, 15);
            this.lblCont.TabIndex = 42;
            this.lblCont.Text = "Contact";
            // 
            // txtContact
            // 
            this.txtContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContact.Location = new System.Drawing.Point(104, 73);
            this.txtContact.MaxLength = 10;
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(146, 22);
            this.txtContact.TabIndex = 5;
            // 
            // cmbSex
            // 
            this.cmbSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSex.FormattingEnabled = true;
            this.cmbSex.Items.AddRange(new object[] {
            "- Select -",
            "Female",
            "Male",
            "Trans"});
            this.cmbSex.Location = new System.Drawing.Point(336, 44);
            this.cmbSex.Name = "cmbSex";
            this.cmbSex.Size = new System.Drawing.Size(104, 24);
            this.cmbSex.TabIndex = 4;
            // 
            // lblSex
            // 
            this.lblSex.AutoSize = true;
            this.lblSex.BackColor = System.Drawing.Color.Transparent;
            this.lblSex.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSex.Location = new System.Drawing.Point(303, 49);
            this.lblSex.Name = "lblSex";
            this.lblSex.Size = new System.Drawing.Size(31, 15);
            this.lblSex.TabIndex = 41;
            this.lblSex.Text = "Sex";
            // 
            // txtPName
            // 
            this.txtPName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPName.Location = new System.Drawing.Point(104, 19);
            this.txtPName.MaxLength = 50;
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(194, 22);
            this.txtPName.TabIndex = 1;
            // 
            // lblPN
            // 
            this.lblPN.AutoSize = true;
            this.lblPN.BackColor = System.Drawing.Color.Transparent;
            this.lblPN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPN.Location = new System.Drawing.Point(11, 21);
            this.lblPN.Name = "lblPN";
            this.lblPN.Size = new System.Drawing.Size(82, 15);
            this.lblPN.TabIndex = 40;
            this.lblPN.Text = "Child Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(411, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "CMs";
            // 
            // lblKgs
            // 
            this.lblKgs.AutoSize = true;
            this.lblKgs.BackColor = System.Drawing.Color.White;
            this.lblKgs.Location = new System.Drawing.Point(324, 79);
            this.lblKgs.Name = "lblKgs";
            this.lblKgs.Size = new System.Drawing.Size(25, 13);
            this.lblKgs.TabIndex = 48;
            this.lblKgs.Text = "Kgs";
            // 
            // txtWeight
            // 
            this.txtWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeight.Location = new System.Drawing.Point(284, 74);
            this.txtWeight.MaxLength = 4;
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(66, 22);
            this.txtWeight.TabIndex = 6;
            // 
            // txtHeight
            // 
            this.txtHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHeight.Location = new System.Drawing.Point(374, 75);
            this.txtHeight.MaxLength = 5;
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(66, 22);
            this.txtHeight.TabIndex = 7;
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.BackColor = System.Drawing.Color.Transparent;
            this.lblHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeight.Location = new System.Drawing.Point(352, 79);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(21, 15);
            this.lblHeight.TabIndex = 49;
            this.lblHeight.Text = "Ht";
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.BackColor = System.Drawing.Color.Transparent;
            this.lblWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeight.Location = new System.Drawing.Point(253, 79);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(23, 15);
            this.lblWeight.TabIndex = 47;
            this.lblWeight.Text = "Wt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 15);
            this.label1.TabIndex = 51;
            this.label1.Text = "Mother Name";
            // 
            // txtMName
            // 
            this.txtMName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMName.Location = new System.Drawing.Point(104, 46);
            this.txtMName.MaxLength = 50;
            this.txtMName.Name = "txtMName";
            this.txtMName.Size = new System.Drawing.Size(194, 22);
            this.txtMName.TabIndex = 3;
            // 
            // dpDOB
            // 
            this.dpDOB.CustomFormat = "dd/MM/yyyy";
            this.dpDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDOB.Location = new System.Drawing.Point(336, 19);
            this.dpDOB.Name = "dpDOB";
            this.dpDOB.Size = new System.Drawing.Size(104, 22);
            this.dpDOB.TabIndex = 2;
            this.dpDOB.ValueChanged += new System.EventHandler(this.dpDOB_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(301, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 15);
            this.label2.TabIndex = 54;
            this.label2.Text = "DOB";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtMName);
            this.groupBox1.Controls.Add(this.dpDOB);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblPN);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtPName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblSex);
            this.groupBox1.Controls.Add(this.lblKgs);
            this.groupBox1.Controls.Add(this.cmbSex);
            this.groupBox1.Controls.Add(this.txtWeight);
            this.groupBox1.Controls.Add(this.txtContact);
            this.groupBox1.Controls.Add(this.txtHeight);
            this.groupBox1.Controls.Add(this.lblCont);
            this.groupBox1.Controls.Add(this.lblHeight);
            this.groupBox1.Controls.Add(this.lblAddress);
            this.groupBox1.Controls.Add(this.lblWeight);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Location = new System.Drawing.Point(6, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(452, 133);
            this.groupBox1.TabIndex = 55;
            this.groupBox1.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.ImageList = this.imageList1;
            this.tabControl1.Location = new System.Drawing.Point(6, 160);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(458, 364);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.grbTab1);
            this.tabPage1.ImageIndex = 0;
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(450, 333);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Vaccine Tab1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // grbTab1
            // 
            this.grbTab1.Controls.Add(this.chkOPV3);
            this.grbTab1.Controls.Add(this.chkDPT2);
            this.grbTab1.Controls.Add(this.chkRotarix1);
            this.grbTab1.Controls.Add(this.chkPCV1);
            this.grbTab1.Controls.Add(this.chkHIB1);
            this.grbTab1.Controls.Add(this.chkHB2);
            this.grbTab1.Controls.Add(this.chkDPT1);
            this.grbTab1.Controls.Add(this.chkOPV2);
            this.grbTab1.Controls.Add(this.chkOPV1);
            this.grbTab1.Controls.Add(this.chkHB1);
            this.grbTab1.Controls.Add(this.chkBCG);
            this.grbTab1.Controls.Add(this.dpRotarix1G);
            this.grbTab1.Controls.Add(this.dpRotarix1D);
            this.grbTab1.Controls.Add(this.label79);
            this.grbTab1.Controls.Add(this.label80);
            this.grbTab1.Controls.Add(this.dpHIB1Given);
            this.grbTab1.Controls.Add(this.dpHIB1Due);
            this.grbTab1.Controls.Add(this.label67);
            this.grbTab1.Controls.Add(this.label78);
            this.grbTab1.Controls.Add(this.chkGivenOn1);
            this.grbTab1.Controls.Add(this.label66);
            this.grbTab1.Controls.Add(this.label65);
            this.grbTab1.Controls.Add(this.label64);
            this.grbTab1.Controls.Add(this.dpOPV3G);
            this.grbTab1.Controls.Add(this.dpOPV3D);
            this.grbTab1.Controls.Add(this.label22);
            this.grbTab1.Controls.Add(this.label23);
            this.grbTab1.Controls.Add(this.dpDPT2G);
            this.grbTab1.Controls.Add(this.dpDPT2D);
            this.grbTab1.Controls.Add(this.label18);
            this.grbTab1.Controls.Add(this.label19);
            this.grbTab1.Controls.Add(this.dpPCV1Given);
            this.grbTab1.Controls.Add(this.dpPCV1Due);
            this.grbTab1.Controls.Add(this.label16);
            this.grbTab1.Controls.Add(this.label17);
            this.grbTab1.Controls.Add(this.dpHB2Given);
            this.grbTab1.Controls.Add(this.dpHB2Due);
            this.grbTab1.Controls.Add(this.label14);
            this.grbTab1.Controls.Add(this.label15);
            this.grbTab1.Controls.Add(this.dpDPT1Given);
            this.grbTab1.Controls.Add(this.dpDPT1Due);
            this.grbTab1.Controls.Add(this.label12);
            this.grbTab1.Controls.Add(this.label13);
            this.grbTab1.Controls.Add(this.dpOPV2Given);
            this.grbTab1.Controls.Add(this.dpOPV2Due);
            this.grbTab1.Controls.Add(this.label10);
            this.grbTab1.Controls.Add(this.label11);
            this.grbTab1.Controls.Add(this.dpOPV1Given);
            this.grbTab1.Controls.Add(this.dpOPV1Due);
            this.grbTab1.Controls.Add(this.label8);
            this.grbTab1.Controls.Add(this.label9);
            this.grbTab1.Controls.Add(this.dpHB1Given);
            this.grbTab1.Controls.Add(this.dpHB1Due);
            this.grbTab1.Controls.Add(this.label6);
            this.grbTab1.Controls.Add(this.label7);
            this.grbTab1.Controls.Add(this.dpBGCGiven);
            this.grbTab1.Controls.Add(this.dpBGCDue);
            this.grbTab1.Controls.Add(this.label5);
            this.grbTab1.Controls.Add(this.label4);
            this.grbTab1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTab1.Location = new System.Drawing.Point(3, -1);
            this.grbTab1.Name = "grbTab1";
            this.grbTab1.Size = new System.Drawing.Size(445, 330);
            this.grbTab1.TabIndex = 1;
            this.grbTab1.TabStop = false;
            // 
            // chkOPV3
            // 
            this.chkOPV3.AutoSize = true;
            this.chkOPV3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOPV3.Location = new System.Drawing.Point(321, 308);
            this.chkOPV3.Name = "chkOPV3";
            this.chkOPV3.Size = new System.Drawing.Size(15, 14);
            this.chkOPV3.TabIndex = 37;
            this.chkOPV3.UseVisualStyleBackColor = true;
            this.chkOPV3.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkDPT2
            // 
            this.chkDPT2.AutoSize = true;
            this.chkDPT2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDPT2.Location = new System.Drawing.Point(321, 281);
            this.chkDPT2.Name = "chkDPT2";
            this.chkDPT2.Size = new System.Drawing.Size(15, 14);
            this.chkDPT2.TabIndex = 34;
            this.chkDPT2.UseVisualStyleBackColor = true;
            this.chkDPT2.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkRotarix1
            // 
            this.chkRotarix1.AutoSize = true;
            this.chkRotarix1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRotarix1.Location = new System.Drawing.Point(321, 254);
            this.chkRotarix1.Name = "chkRotarix1";
            this.chkRotarix1.Size = new System.Drawing.Size(15, 14);
            this.chkRotarix1.TabIndex = 31;
            this.chkRotarix1.UseVisualStyleBackColor = true;
            this.chkRotarix1.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkPCV1
            // 
            this.chkPCV1.AutoSize = true;
            this.chkPCV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPCV1.Location = new System.Drawing.Point(321, 226);
            this.chkPCV1.Name = "chkPCV1";
            this.chkPCV1.Size = new System.Drawing.Size(15, 14);
            this.chkPCV1.TabIndex = 28;
            this.chkPCV1.UseVisualStyleBackColor = true;
            this.chkPCV1.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkHIB1
            // 
            this.chkHIB1.AutoSize = true;
            this.chkHIB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHIB1.Location = new System.Drawing.Point(321, 202);
            this.chkHIB1.Name = "chkHIB1";
            this.chkHIB1.Size = new System.Drawing.Size(15, 14);
            this.chkHIB1.TabIndex = 25;
            this.chkHIB1.UseVisualStyleBackColor = true;
            this.chkHIB1.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkHB2
            // 
            this.chkHB2.AutoSize = true;
            this.chkHB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHB2.Location = new System.Drawing.Point(321, 174);
            this.chkHB2.Name = "chkHB2";
            this.chkHB2.Size = new System.Drawing.Size(15, 14);
            this.chkHB2.TabIndex = 22;
            this.chkHB2.UseVisualStyleBackColor = true;
            this.chkHB2.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkDPT1
            // 
            this.chkDPT1.AutoSize = true;
            this.chkDPT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDPT1.Location = new System.Drawing.Point(321, 145);
            this.chkDPT1.Name = "chkDPT1";
            this.chkDPT1.Size = new System.Drawing.Size(15, 14);
            this.chkDPT1.TabIndex = 19;
            this.chkDPT1.UseVisualStyleBackColor = true;
            this.chkDPT1.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkOPV2
            // 
            this.chkOPV2.AutoSize = true;
            this.chkOPV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOPV2.Location = new System.Drawing.Point(321, 119);
            this.chkOPV2.Name = "chkOPV2";
            this.chkOPV2.Size = new System.Drawing.Size(15, 14);
            this.chkOPV2.TabIndex = 16;
            this.chkOPV2.UseVisualStyleBackColor = true;
            this.chkOPV2.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkOPV1
            // 
            this.chkOPV1.AutoSize = true;
            this.chkOPV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOPV1.Location = new System.Drawing.Point(321, 91);
            this.chkOPV1.Name = "chkOPV1";
            this.chkOPV1.Size = new System.Drawing.Size(15, 14);
            this.chkOPV1.TabIndex = 13;
            this.chkOPV1.UseVisualStyleBackColor = true;
            this.chkOPV1.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkHB1
            // 
            this.chkHB1.AutoSize = true;
            this.chkHB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHB1.Location = new System.Drawing.Point(321, 65);
            this.chkHB1.Name = "chkHB1";
            this.chkHB1.Size = new System.Drawing.Size(15, 14);
            this.chkHB1.TabIndex = 10;
            this.chkHB1.UseVisualStyleBackColor = true;
            this.chkHB1.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // chkBCG
            // 
            this.chkBCG.AutoSize = true;
            this.chkBCG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBCG.Location = new System.Drawing.Point(321, 37);
            this.chkBCG.Name = "chkBCG";
            this.chkBCG.Size = new System.Drawing.Size(15, 14);
            this.chkBCG.TabIndex = 7;
            this.chkBCG.UseVisualStyleBackColor = true;
            this.chkBCG.CheckedChanged += new System.EventHandler(this.chkBCG_CheckedChanged);
            // 
            // dpRotarix1G
            // 
            this.dpRotarix1G.CustomFormat = "dd/MM/yyyy";
            this.dpRotarix1G.Enabled = false;
            this.dpRotarix1G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpRotarix1G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpRotarix1G.Location = new System.Drawing.Point(340, 249);
            this.dpRotarix1G.Name = "dpRotarix1G";
            this.dpRotarix1G.Size = new System.Drawing.Size(90, 22);
            this.dpRotarix1G.TabIndex = 32;
            // 
            // dpRotarix1D
            // 
            this.dpRotarix1D.CustomFormat = "dd/MM/yyyy";
            this.dpRotarix1D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpRotarix1D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpRotarix1D.Location = new System.Drawing.Point(198, 249);
            this.dpRotarix1D.Name = "dpRotarix1D";
            this.dpRotarix1D.Size = new System.Drawing.Size(90, 22);
            this.dpRotarix1D.TabIndex = 30;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(112, 249);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(80, 15);
            this.label79.TabIndex = 126;
            this.label79.Text = "8 Weeks(2M)";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(13, 249);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(56, 15);
            this.label80.TabIndex = 125;
            this.label80.Text = "Rotarix 1";
            // 
            // dpHIB1Given
            // 
            this.dpHIB1Given.CustomFormat = "dd/MM/yyyy";
            this.dpHIB1Given.Enabled = false;
            this.dpHIB1Given.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHIB1Given.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHIB1Given.Location = new System.Drawing.Point(340, 195);
            this.dpHIB1Given.Name = "dpHIB1Given";
            this.dpHIB1Given.Size = new System.Drawing.Size(90, 22);
            this.dpHIB1Given.TabIndex = 26;
            // 
            // dpHIB1Due
            // 
            this.dpHIB1Due.CustomFormat = "dd/MM/yyyy";
            this.dpHIB1Due.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHIB1Due.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHIB1Due.Location = new System.Drawing.Point(198, 195);
            this.dpHIB1Due.Name = "dpHIB1Due";
            this.dpHIB1Due.Size = new System.Drawing.Size(90, 22);
            this.dpHIB1Due.TabIndex = 24;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(112, 195);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(54, 15);
            this.label67.TabIndex = 122;
            this.label67.Text = "6 Weeks";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(13, 222);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(66, 15);
            this.label78.TabIndex = 121;
            this.label78.Text = "PCV -13(1)";
            // 
            // chkGivenOn1
            // 
            this.chkGivenOn1.AutoSize = true;
            this.chkGivenOn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGivenOn1.Location = new System.Drawing.Point(322, 10);
            this.chkGivenOn1.Name = "chkGivenOn1";
            this.chkGivenOn1.Size = new System.Drawing.Size(79, 17);
            this.chkGivenOn1.TabIndex = 5;
            this.chkGivenOn1.Text = "Given On";
            this.chkGivenOn1.UseVisualStyleBackColor = true;
            this.chkGivenOn1.CheckedChanged += new System.EventHandler(this.chkGivenOn1_CheckedChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.Transparent;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(198, 10);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(67, 15);
            this.label66.TabIndex = 118;
            this.label66.Text = "Due Date";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.Transparent;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(112, 10);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(31, 15);
            this.label65.TabIndex = 4;
            this.label65.Text = "Age";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.Transparent;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(6, 10);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(99, 15);
            this.label64.TabIndex = 55;
            this.label64.Text = "Vaccine Name";
            // 
            // dpOPV3G
            // 
            this.dpOPV3G.CustomFormat = "dd/MM/yyyy";
            this.dpOPV3G.Enabled = false;
            this.dpOPV3G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPV3G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPV3G.Location = new System.Drawing.Point(337, 303);
            this.dpOPV3G.Name = "dpOPV3G";
            this.dpOPV3G.Size = new System.Drawing.Size(90, 22);
            this.dpOPV3G.TabIndex = 38;
            // 
            // dpOPV3D
            // 
            this.dpOPV3D.CustomFormat = "dd/MM/yyyy";
            this.dpOPV3D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPV3D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPV3D.Location = new System.Drawing.Point(198, 303);
            this.dpOPV3D.Name = "dpOPV3D";
            this.dpOPV3D.Size = new System.Drawing.Size(90, 22);
            this.dpOPV3D.TabIndex = 36;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(112, 303);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 15);
            this.label22.TabIndex = 110;
            this.label22.Text = "10 Weeks";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 303);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(68, 15);
            this.label23.TabIndex = 109;
            this.label23.Text = "OPV 3 / IPV";
            // 
            // dpDPT2G
            // 
            this.dpDPT2G.CustomFormat = "dd/MM/yyyy";
            this.dpDPT2G.Enabled = false;
            this.dpDPT2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPT2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPT2G.Location = new System.Drawing.Point(337, 276);
            this.dpDPT2G.Name = "dpDPT2G";
            this.dpDPT2G.Size = new System.Drawing.Size(90, 22);
            this.dpDPT2G.TabIndex = 35;
            // 
            // dpDPT2D
            // 
            this.dpDPT2D.CustomFormat = "dd/MM/yyyy";
            this.dpDPT2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPT2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPT2D.Location = new System.Drawing.Point(198, 276);
            this.dpDPT2D.Name = "dpDPT2D";
            this.dpDPT2D.Size = new System.Drawing.Size(90, 22);
            this.dpDPT2D.TabIndex = 33;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(112, 276);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 15);
            this.label18.TabIndex = 106;
            this.label18.Text = "10 Weeks";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 276);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 15);
            this.label19.TabIndex = 105;
            this.label19.Text = "DPT 2/DTaP 2";
            // 
            // dpPCV1Given
            // 
            this.dpPCV1Given.CustomFormat = "dd/MM/yyyy";
            this.dpPCV1Given.Enabled = false;
            this.dpPCV1Given.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpPCV1Given.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpPCV1Given.Location = new System.Drawing.Point(340, 222);
            this.dpPCV1Given.Name = "dpPCV1Given";
            this.dpPCV1Given.Size = new System.Drawing.Size(90, 22);
            this.dpPCV1Given.TabIndex = 29;
            // 
            // dpPCV1Due
            // 
            this.dpPCV1Due.CustomFormat = "dd/MM/yyyy";
            this.dpPCV1Due.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpPCV1Due.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpPCV1Due.Location = new System.Drawing.Point(198, 222);
            this.dpPCV1Due.Name = "dpPCV1Due";
            this.dpPCV1Due.Size = new System.Drawing.Size(90, 22);
            this.dpPCV1Due.TabIndex = 27;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(112, 222);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(80, 15);
            this.label16.TabIndex = 102;
            this.label16.Text = "8 Weeks(2M)";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(13, 195);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 15);
            this.label17.TabIndex = 101;
            this.label17.Text = "HIB 1";
            // 
            // dpHB2Given
            // 
            this.dpHB2Given.CustomFormat = "dd/MM/yyyy";
            this.dpHB2Given.Enabled = false;
            this.dpHB2Given.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHB2Given.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHB2Given.Location = new System.Drawing.Point(340, 168);
            this.dpHB2Given.Name = "dpHB2Given";
            this.dpHB2Given.Size = new System.Drawing.Size(90, 22);
            this.dpHB2Given.TabIndex = 23;
            // 
            // dpHB2Due
            // 
            this.dpHB2Due.CustomFormat = "dd/MM/yyyy";
            this.dpHB2Due.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHB2Due.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHB2Due.Location = new System.Drawing.Point(198, 168);
            this.dpHB2Due.Name = "dpHB2Due";
            this.dpHB2Due.Size = new System.Drawing.Size(90, 22);
            this.dpHB2Due.TabIndex = 21;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(112, 168);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 15);
            this.label14.TabIndex = 98;
            this.label14.Text = "6 Weeks";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 168);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 15);
            this.label15.TabIndex = 97;
            this.label15.Text = "Hepatitis B2";
            // 
            // dpDPT1Given
            // 
            this.dpDPT1Given.CustomFormat = "dd/MM/yyyy";
            this.dpDPT1Given.Enabled = false;
            this.dpDPT1Given.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPT1Given.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPT1Given.Location = new System.Drawing.Point(340, 141);
            this.dpDPT1Given.Name = "dpDPT1Given";
            this.dpDPT1Given.Size = new System.Drawing.Size(90, 22);
            this.dpDPT1Given.TabIndex = 20;
            // 
            // dpDPT1Due
            // 
            this.dpDPT1Due.CustomFormat = "dd/MM/yyyy";
            this.dpDPT1Due.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPT1Due.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPT1Due.Location = new System.Drawing.Point(198, 141);
            this.dpDPT1Due.Name = "dpDPT1Due";
            this.dpDPT1Due.Size = new System.Drawing.Size(90, 22);
            this.dpDPT1Due.TabIndex = 18;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(112, 141);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 15);
            this.label12.TabIndex = 94;
            this.label12.Text = "6 Weeks";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 141);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 15);
            this.label13.TabIndex = 93;
            this.label13.Text = "DPT 1/DTaP 1";
            // 
            // dpOPV2Given
            // 
            this.dpOPV2Given.CustomFormat = "dd/MM/yyyy";
            this.dpOPV2Given.Enabled = false;
            this.dpOPV2Given.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPV2Given.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPV2Given.Location = new System.Drawing.Point(340, 114);
            this.dpOPV2Given.Name = "dpOPV2Given";
            this.dpOPV2Given.Size = new System.Drawing.Size(90, 22);
            this.dpOPV2Given.TabIndex = 17;
            // 
            // dpOPV2Due
            // 
            this.dpOPV2Due.CustomFormat = "dd/MM/yyyy";
            this.dpOPV2Due.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPV2Due.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPV2Due.Location = new System.Drawing.Point(198, 114);
            this.dpOPV2Due.Name = "dpOPV2Due";
            this.dpOPV2Due.Size = new System.Drawing.Size(90, 22);
            this.dpOPV2Due.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(112, 114);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 15);
            this.label10.TabIndex = 90;
            this.label10.Text = "6 Weeks";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 114);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 15);
            this.label11.TabIndex = 89;
            this.label11.Text = "OPV 2 / IPV";
            // 
            // dpOPV1Given
            // 
            this.dpOPV1Given.CustomFormat = "dd/MM/yyyy";
            this.dpOPV1Given.Enabled = false;
            this.dpOPV1Given.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPV1Given.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPV1Given.Location = new System.Drawing.Point(340, 87);
            this.dpOPV1Given.Name = "dpOPV1Given";
            this.dpOPV1Given.Size = new System.Drawing.Size(90, 22);
            this.dpOPV1Given.TabIndex = 14;
            // 
            // dpOPV1Due
            // 
            this.dpOPV1Due.CustomFormat = "dd/MM/yyyy";
            this.dpOPV1Due.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPV1Due.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPV1Due.Location = new System.Drawing.Point(198, 87);
            this.dpOPV1Due.Name = "dpOPV1Due";
            this.dpOPV1Due.Size = new System.Drawing.Size(90, 22);
            this.dpOPV1Due.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(112, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 15);
            this.label8.TabIndex = 86;
            this.label8.Text = "Birth";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 15);
            this.label9.TabIndex = 85;
            this.label9.Text = "OPV 1";
            // 
            // dpHB1Given
            // 
            this.dpHB1Given.CustomFormat = "dd/MM/yyyy";
            this.dpHB1Given.Enabled = false;
            this.dpHB1Given.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHB1Given.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHB1Given.Location = new System.Drawing.Point(340, 60);
            this.dpHB1Given.Name = "dpHB1Given";
            this.dpHB1Given.Size = new System.Drawing.Size(90, 22);
            this.dpHB1Given.TabIndex = 11;
            // 
            // dpHB1Due
            // 
            this.dpHB1Due.CustomFormat = "dd/MM/yyyy";
            this.dpHB1Due.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHB1Due.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHB1Due.Location = new System.Drawing.Point(198, 60);
            this.dpHB1Due.Name = "dpHB1Due";
            this.dpHB1Due.Size = new System.Drawing.Size(90, 22);
            this.dpHB1Due.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(112, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 15);
            this.label6.TabIndex = 82;
            this.label6.Text = "Birth";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 15);
            this.label7.TabIndex = 81;
            this.label7.Text = "Hepatitis B1";
            // 
            // dpBGCGiven
            // 
            this.dpBGCGiven.CustomFormat = "dd/MM/yyyy";
            this.dpBGCGiven.Enabled = false;
            this.dpBGCGiven.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpBGCGiven.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpBGCGiven.Location = new System.Drawing.Point(340, 33);
            this.dpBGCGiven.Name = "dpBGCGiven";
            this.dpBGCGiven.Size = new System.Drawing.Size(90, 22);
            this.dpBGCGiven.TabIndex = 8;
            // 
            // dpBGCDue
            // 
            this.dpBGCDue.CustomFormat = "dd/MM/yyyy";
            this.dpBGCDue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpBGCDue.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpBGCDue.Location = new System.Drawing.Point(198, 33);
            this.dpBGCDue.Name = "dpBGCDue";
            this.dpBGCDue.Size = new System.Drawing.Size(90, 22);
            this.dpBGCDue.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(112, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "Birth";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 15);
            this.label4.TabIndex = 77;
            this.label4.Text = "BCG";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.grbTab2);
            this.tabPage2.ImageIndex = 3;
            this.tabPage2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(450, 333);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Vaccine Tab2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // grbTab2
            // 
            this.grbTab2.Controls.Add(this.chkPCVBooster);
            this.grbTab2.Controls.Add(this.chkVaricella1);
            this.grbTab2.Controls.Add(this.chkMeasles);
            this.grbTab2.Controls.Add(this.chkPCV3);
            this.grbTab2.Controls.Add(this.chkRotarix2);
            this.grbTab2.Controls.Add(this.chkPCV2);
            this.grbTab2.Controls.Add(this.chkHIB3);
            this.grbTab2.Controls.Add(this.chkHB3);
            this.grbTab2.Controls.Add(this.chkDPT3);
            this.grbTab2.Controls.Add(this.chkOPV4);
            this.grbTab2.Controls.Add(this.chkHIB2);
            this.grbTab2.Controls.Add(this.dpMeaslesG);
            this.grbTab2.Controls.Add(this.dpMeaslesD);
            this.grbTab2.Controls.Add(this.label20);
            this.grbTab2.Controls.Add(this.dpRotarix2G);
            this.grbTab2.Controls.Add(this.dpRotarix2D);
            this.grbTab2.Controls.Add(this.label24);
            this.grbTab2.Controls.Add(this.chkGivenOn2);
            this.grbTab2.Controls.Add(this.label26);
            this.grbTab2.Controls.Add(this.label28);
            this.grbTab2.Controls.Add(this.dpPCVBoosterG);
            this.grbTab2.Controls.Add(this.dpPCVBoosterD);
            this.grbTab2.Controls.Add(this.label30);
            this.grbTab2.Controls.Add(this.dpVaricella1G);
            this.grbTab2.Controls.Add(this.dpVaricella1D);
            this.grbTab2.Controls.Add(this.label32);
            this.grbTab2.Controls.Add(this.dpPCV3G);
            this.grbTab2.Controls.Add(this.dpPCV3D);
            this.grbTab2.Controls.Add(this.label34);
            this.grbTab2.Controls.Add(this.dpPCV2G);
            this.grbTab2.Controls.Add(this.dpPCV2D);
            this.grbTab2.Controls.Add(this.label36);
            this.grbTab2.Controls.Add(this.dpHIB3G);
            this.grbTab2.Controls.Add(this.dpHIB3D);
            this.grbTab2.Controls.Add(this.label38);
            this.grbTab2.Controls.Add(this.dpHB3G);
            this.grbTab2.Controls.Add(this.dpHB3D);
            this.grbTab2.Controls.Add(this.label40);
            this.grbTab2.Controls.Add(this.dpDPT3G);
            this.grbTab2.Controls.Add(this.dpDPT3D);
            this.grbTab2.Controls.Add(this.label42);
            this.grbTab2.Controls.Add(this.dpOPV4G);
            this.grbTab2.Controls.Add(this.dpOPV4D);
            this.grbTab2.Controls.Add(this.label81);
            this.grbTab2.Controls.Add(this.dpHIB2G);
            this.grbTab2.Controls.Add(this.dpHIB2D);
            this.grbTab2.Controls.Add(this.label84);
            this.grbTab2.Controls.Add(this.label21);
            this.grbTab2.Controls.Add(this.label87);
            this.grbTab2.Controls.Add(this.label86);
            this.grbTab2.Controls.Add(this.label85);
            this.grbTab2.Controls.Add(this.label82);
            this.grbTab2.Controls.Add(this.label83);
            this.grbTab2.Controls.Add(this.label71);
            this.grbTab2.Controls.Add(this.label35);
            this.grbTab2.Controls.Add(this.label37);
            this.grbTab2.Controls.Add(this.label39);
            this.grbTab2.Controls.Add(this.label41);
            this.grbTab2.Controls.Add(this.label43);
            this.grbTab2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTab2.Location = new System.Drawing.Point(3, -1);
            this.grbTab2.Name = "grbTab2";
            this.grbTab2.Size = new System.Drawing.Size(443, 329);
            this.grbTab2.TabIndex = 2;
            this.grbTab2.TabStop = false;
            // 
            // chkPCVBooster
            // 
            this.chkPCVBooster.AutoSize = true;
            this.chkPCVBooster.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPCVBooster.Location = new System.Drawing.Point(326, 308);
            this.chkPCVBooster.Name = "chkPCVBooster";
            this.chkPCVBooster.Size = new System.Drawing.Size(15, 14);
            this.chkPCVBooster.TabIndex = 32;
            this.chkPCVBooster.UseVisualStyleBackColor = true;
            this.chkPCVBooster.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkVaricella1
            // 
            this.chkVaricella1.AutoSize = true;
            this.chkVaricella1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkVaricella1.Location = new System.Drawing.Point(326, 281);
            this.chkVaricella1.Name = "chkVaricella1";
            this.chkVaricella1.Size = new System.Drawing.Size(15, 14);
            this.chkVaricella1.TabIndex = 29;
            this.chkVaricella1.UseVisualStyleBackColor = true;
            this.chkVaricella1.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkMeasles
            // 
            this.chkMeasles.AutoSize = true;
            this.chkMeasles.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMeasles.Location = new System.Drawing.Point(326, 254);
            this.chkMeasles.Name = "chkMeasles";
            this.chkMeasles.Size = new System.Drawing.Size(15, 14);
            this.chkMeasles.TabIndex = 26;
            this.chkMeasles.UseVisualStyleBackColor = true;
            this.chkMeasles.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkPCV3
            // 
            this.chkPCV3.AutoSize = true;
            this.chkPCV3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPCV3.Location = new System.Drawing.Point(326, 226);
            this.chkPCV3.Name = "chkPCV3";
            this.chkPCV3.Size = new System.Drawing.Size(15, 14);
            this.chkPCV3.TabIndex = 23;
            this.chkPCV3.UseVisualStyleBackColor = true;
            this.chkPCV3.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkRotarix2
            // 
            this.chkRotarix2.AutoSize = true;
            this.chkRotarix2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRotarix2.Location = new System.Drawing.Point(326, 202);
            this.chkRotarix2.Name = "chkRotarix2";
            this.chkRotarix2.Size = new System.Drawing.Size(15, 14);
            this.chkRotarix2.TabIndex = 20;
            this.chkRotarix2.UseVisualStyleBackColor = true;
            this.chkRotarix2.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkPCV2
            // 
            this.chkPCV2.AutoSize = true;
            this.chkPCV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPCV2.Location = new System.Drawing.Point(326, 174);
            this.chkPCV2.Name = "chkPCV2";
            this.chkPCV2.Size = new System.Drawing.Size(15, 14);
            this.chkPCV2.TabIndex = 17;
            this.chkPCV2.UseVisualStyleBackColor = true;
            this.chkPCV2.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkHIB3
            // 
            this.chkHIB3.AutoSize = true;
            this.chkHIB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHIB3.Location = new System.Drawing.Point(326, 145);
            this.chkHIB3.Name = "chkHIB3";
            this.chkHIB3.Size = new System.Drawing.Size(15, 14);
            this.chkHIB3.TabIndex = 14;
            this.chkHIB3.UseVisualStyleBackColor = true;
            this.chkHIB3.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkHB3
            // 
            this.chkHB3.AutoSize = true;
            this.chkHB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHB3.Location = new System.Drawing.Point(326, 119);
            this.chkHB3.Name = "chkHB3";
            this.chkHB3.Size = new System.Drawing.Size(15, 14);
            this.chkHB3.TabIndex = 11;
            this.chkHB3.UseVisualStyleBackColor = true;
            this.chkHB3.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkDPT3
            // 
            this.chkDPT3.AutoSize = true;
            this.chkDPT3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDPT3.Location = new System.Drawing.Point(326, 91);
            this.chkDPT3.Name = "chkDPT3";
            this.chkDPT3.Size = new System.Drawing.Size(15, 14);
            this.chkDPT3.TabIndex = 8;
            this.chkDPT3.UseVisualStyleBackColor = true;
            this.chkDPT3.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkOPV4
            // 
            this.chkOPV4.AutoSize = true;
            this.chkOPV4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOPV4.Location = new System.Drawing.Point(326, 65);
            this.chkOPV4.Name = "chkOPV4";
            this.chkOPV4.Size = new System.Drawing.Size(15, 14);
            this.chkOPV4.TabIndex = 5;
            this.chkOPV4.UseVisualStyleBackColor = true;
            this.chkOPV4.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // chkHIB2
            // 
            this.chkHIB2.AutoSize = true;
            this.chkHIB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHIB2.Location = new System.Drawing.Point(326, 37);
            this.chkHIB2.Name = "chkHIB2";
            this.chkHIB2.Size = new System.Drawing.Size(15, 14);
            this.chkHIB2.TabIndex = 2;
            this.chkHIB2.UseVisualStyleBackColor = true;
            this.chkHIB2.CheckedChanged += new System.EventHandler(this.chkHIB2_CheckedChanged);
            // 
            // dpMeaslesG
            // 
            this.dpMeaslesG.CustomFormat = "dd/MM/yyyy";
            this.dpMeaslesG.Enabled = false;
            this.dpMeaslesG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpMeaslesG.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpMeaslesG.Location = new System.Drawing.Point(345, 249);
            this.dpMeaslesG.Name = "dpMeaslesG";
            this.dpMeaslesG.Size = new System.Drawing.Size(90, 22);
            this.dpMeaslesG.TabIndex = 27;
            // 
            // dpMeaslesD
            // 
            this.dpMeaslesD.CustomFormat = "dd/MM/yyyy";
            this.dpMeaslesD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpMeaslesD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpMeaslesD.Location = new System.Drawing.Point(210, 249);
            this.dpMeaslesD.Name = "dpMeaslesD";
            this.dpMeaslesD.Size = new System.Drawing.Size(90, 22);
            this.dpMeaslesD.TabIndex = 25;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(115, 249);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(87, 15);
            this.label20.TabIndex = 174;
            this.label20.Text = "36 Weeks(9M)";
            // 
            // dpRotarix2G
            // 
            this.dpRotarix2G.CustomFormat = "dd/MM/yyyy";
            this.dpRotarix2G.Enabled = false;
            this.dpRotarix2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpRotarix2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpRotarix2G.Location = new System.Drawing.Point(345, 195);
            this.dpRotarix2G.Name = "dpRotarix2G";
            this.dpRotarix2G.Size = new System.Drawing.Size(90, 22);
            this.dpRotarix2G.TabIndex = 21;
            // 
            // dpRotarix2D
            // 
            this.dpRotarix2D.CustomFormat = "dd/MM/yyyy";
            this.dpRotarix2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpRotarix2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpRotarix2D.Location = new System.Drawing.Point(210, 195);
            this.dpRotarix2D.Name = "dpRotarix2D";
            this.dpRotarix2D.Size = new System.Drawing.Size(90, 22);
            this.dpRotarix2D.TabIndex = 19;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(115, 195);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(87, 15);
            this.label24.TabIndex = 171;
            this.label24.Text = "16 Weeks(4M)";
            // 
            // chkGivenOn2
            // 
            this.chkGivenOn2.AutoSize = true;
            this.chkGivenOn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGivenOn2.Location = new System.Drawing.Point(327, 10);
            this.chkGivenOn2.Name = "chkGivenOn2";
            this.chkGivenOn2.Size = new System.Drawing.Size(79, 17);
            this.chkGivenOn2.TabIndex = 0;
            this.chkGivenOn2.Text = "Given On";
            this.chkGivenOn2.UseVisualStyleBackColor = true;
            this.chkGivenOn2.CheckedChanged += new System.EventHandler(this.chkGivenOn1_CheckedChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(210, 10);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(67, 15);
            this.label26.TabIndex = 169;
            this.label26.Text = "Due Date";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(115, 10);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(31, 15);
            this.label28.TabIndex = 168;
            this.label28.Text = "Age";
            // 
            // dpPCVBoosterG
            // 
            this.dpPCVBoosterG.CustomFormat = "dd/MM/yyyy";
            this.dpPCVBoosterG.Enabled = false;
            this.dpPCVBoosterG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpPCVBoosterG.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpPCVBoosterG.Location = new System.Drawing.Point(342, 303);
            this.dpPCVBoosterG.Name = "dpPCVBoosterG";
            this.dpPCVBoosterG.Size = new System.Drawing.Size(90, 22);
            this.dpPCVBoosterG.TabIndex = 33;
            // 
            // dpPCVBoosterD
            // 
            this.dpPCVBoosterD.CustomFormat = "dd/MM/yyyy";
            this.dpPCVBoosterD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpPCVBoosterD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpPCVBoosterD.Location = new System.Drawing.Point(210, 303);
            this.dpPCVBoosterD.Name = "dpPCVBoosterD";
            this.dpPCVBoosterD.Size = new System.Drawing.Size(90, 22);
            this.dpPCVBoosterD.TabIndex = 31;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(115, 303);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(64, 15);
            this.label30.TabIndex = 165;
            this.label30.Text = "12 M(1 Yr)";
            // 
            // dpVaricella1G
            // 
            this.dpVaricella1G.CustomFormat = "dd/MM/yyyy";
            this.dpVaricella1G.Enabled = false;
            this.dpVaricella1G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpVaricella1G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpVaricella1G.Location = new System.Drawing.Point(342, 276);
            this.dpVaricella1G.Name = "dpVaricella1G";
            this.dpVaricella1G.Size = new System.Drawing.Size(90, 22);
            this.dpVaricella1G.TabIndex = 30;
            // 
            // dpVaricella1D
            // 
            this.dpVaricella1D.CustomFormat = "dd/MM/yyyy";
            this.dpVaricella1D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpVaricella1D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpVaricella1D.Location = new System.Drawing.Point(210, 276);
            this.dpVaricella1D.Name = "dpVaricella1D";
            this.dpVaricella1D.Size = new System.Drawing.Size(90, 22);
            this.dpVaricella1D.TabIndex = 28;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(115, 276);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(64, 15);
            this.label32.TabIndex = 162;
            this.label32.Text = "12 M(1 Yr)";
            // 
            // dpPCV3G
            // 
            this.dpPCV3G.CustomFormat = "dd/MM/yyyy";
            this.dpPCV3G.Enabled = false;
            this.dpPCV3G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpPCV3G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpPCV3G.Location = new System.Drawing.Point(345, 222);
            this.dpPCV3G.Name = "dpPCV3G";
            this.dpPCV3G.Size = new System.Drawing.Size(90, 22);
            this.dpPCV3G.TabIndex = 24;
            // 
            // dpPCV3D
            // 
            this.dpPCV3D.CustomFormat = "dd/MM/yyyy";
            this.dpPCV3D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpPCV3D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpPCV3D.Location = new System.Drawing.Point(210, 222);
            this.dpPCV3D.Name = "dpPCV3D";
            this.dpPCV3D.Size = new System.Drawing.Size(90, 22);
            this.dpPCV3D.TabIndex = 22;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(115, 222);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(87, 15);
            this.label34.TabIndex = 159;
            this.label34.Text = "24 Weeks(6M)";
            // 
            // dpPCV2G
            // 
            this.dpPCV2G.CustomFormat = "dd/MM/yyyy";
            this.dpPCV2G.Enabled = false;
            this.dpPCV2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpPCV2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpPCV2G.Location = new System.Drawing.Point(345, 168);
            this.dpPCV2G.Name = "dpPCV2G";
            this.dpPCV2G.Size = new System.Drawing.Size(90, 22);
            this.dpPCV2G.TabIndex = 18;
            // 
            // dpPCV2D
            // 
            this.dpPCV2D.CustomFormat = "dd/MM/yyyy";
            this.dpPCV2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpPCV2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpPCV2D.Location = new System.Drawing.Point(210, 168);
            this.dpPCV2D.Name = "dpPCV2D";
            this.dpPCV2D.Size = new System.Drawing.Size(90, 22);
            this.dpPCV2D.TabIndex = 16;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(115, 168);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(87, 15);
            this.label36.TabIndex = 156;
            this.label36.Text = "16 Weeks(4M)";
            // 
            // dpHIB3G
            // 
            this.dpHIB3G.CustomFormat = "dd/MM/yyyy";
            this.dpHIB3G.Enabled = false;
            this.dpHIB3G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHIB3G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHIB3G.Location = new System.Drawing.Point(345, 141);
            this.dpHIB3G.Name = "dpHIB3G";
            this.dpHIB3G.Size = new System.Drawing.Size(90, 22);
            this.dpHIB3G.TabIndex = 15;
            // 
            // dpHIB3D
            // 
            this.dpHIB3D.CustomFormat = "dd/MM/yyyy";
            this.dpHIB3D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHIB3D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHIB3D.Location = new System.Drawing.Point(210, 141);
            this.dpHIB3D.Name = "dpHIB3D";
            this.dpHIB3D.Size = new System.Drawing.Size(90, 22);
            this.dpHIB3D.TabIndex = 13;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(115, 141);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(61, 15);
            this.label38.TabIndex = 153;
            this.label38.Text = "14 Weeks";
            // 
            // dpHB3G
            // 
            this.dpHB3G.CustomFormat = "dd/MM/yyyy";
            this.dpHB3G.Enabled = false;
            this.dpHB3G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHB3G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHB3G.Location = new System.Drawing.Point(345, 114);
            this.dpHB3G.Name = "dpHB3G";
            this.dpHB3G.Size = new System.Drawing.Size(90, 22);
            this.dpHB3G.TabIndex = 12;
            // 
            // dpHB3D
            // 
            this.dpHB3D.CustomFormat = "dd/MM/yyyy";
            this.dpHB3D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHB3D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHB3D.Location = new System.Drawing.Point(210, 114);
            this.dpHB3D.Name = "dpHB3D";
            this.dpHB3D.Size = new System.Drawing.Size(90, 22);
            this.dpHB3D.TabIndex = 10;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(115, 114);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(88, 15);
            this.label40.TabIndex = 150;
            this.label40.Text = "14 Weeks / 6M";
            // 
            // dpDPT3G
            // 
            this.dpDPT3G.CustomFormat = "dd/MM/yyyy";
            this.dpDPT3G.Enabled = false;
            this.dpDPT3G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPT3G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPT3G.Location = new System.Drawing.Point(345, 87);
            this.dpDPT3G.Name = "dpDPT3G";
            this.dpDPT3G.Size = new System.Drawing.Size(90, 22);
            this.dpDPT3G.TabIndex = 9;
            // 
            // dpDPT3D
            // 
            this.dpDPT3D.CustomFormat = "dd/MM/yyyy";
            this.dpDPT3D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPT3D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPT3D.Location = new System.Drawing.Point(210, 87);
            this.dpDPT3D.Name = "dpDPT3D";
            this.dpDPT3D.Size = new System.Drawing.Size(90, 22);
            this.dpDPT3D.TabIndex = 7;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(115, 87);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(61, 15);
            this.label42.TabIndex = 147;
            this.label42.Text = "14 Weeks";
            // 
            // dpOPV4G
            // 
            this.dpOPV4G.CustomFormat = "dd/MM/yyyy";
            this.dpOPV4G.Enabled = false;
            this.dpOPV4G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPV4G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPV4G.Location = new System.Drawing.Point(345, 60);
            this.dpOPV4G.Name = "dpOPV4G";
            this.dpOPV4G.Size = new System.Drawing.Size(90, 22);
            this.dpOPV4G.TabIndex = 6;
            // 
            // dpOPV4D
            // 
            this.dpOPV4D.CustomFormat = "dd/MM/yyyy";
            this.dpOPV4D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPV4D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPV4D.Location = new System.Drawing.Point(210, 60);
            this.dpOPV4D.Name = "dpOPV4D";
            this.dpOPV4D.Size = new System.Drawing.Size(90, 22);
            this.dpOPV4D.TabIndex = 4;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(115, 60);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(61, 15);
            this.label81.TabIndex = 144;
            this.label81.Text = "14 Weeks";
            // 
            // dpHIB2G
            // 
            this.dpHIB2G.CustomFormat = "dd/MM/yyyy";
            this.dpHIB2G.Enabled = false;
            this.dpHIB2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHIB2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHIB2G.Location = new System.Drawing.Point(345, 33);
            this.dpHIB2G.Name = "dpHIB2G";
            this.dpHIB2G.Size = new System.Drawing.Size(90, 22);
            this.dpHIB2G.TabIndex = 3;
            // 
            // dpHIB2D
            // 
            this.dpHIB2D.CustomFormat = "dd/MM/yyyy";
            this.dpHIB2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHIB2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHIB2D.Location = new System.Drawing.Point(210, 33);
            this.dpHIB2D.Name = "dpHIB2D";
            this.dpHIB2D.Size = new System.Drawing.Size(90, 22);
            this.dpHIB2D.TabIndex = 1;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(115, 33);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(61, 15);
            this.label84.TabIndex = 141;
            this.label84.Text = "10 Weeks";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(9, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(37, 15);
            this.label21.TabIndex = 140;
            this.label21.Text = "HIB 2";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(9, 303);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(96, 15);
            this.label87.TabIndex = 139;
            this.label87.Text = "PCV -13 Booster";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(9, 276);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(64, 15);
            this.label86.TabIndex = 138;
            this.label86.Text = "Varicella 1";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(9, 222);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(66, 15);
            this.label85.TabIndex = 137;
            this.label85.Text = "PCV -13(3)";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(9, 195);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(56, 15);
            this.label82.TabIndex = 133;
            this.label82.Text = "Rotarix 2";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(9, 168);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(66, 15);
            this.label83.TabIndex = 132;
            this.label83.Text = "PCV -13(2)";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.Transparent;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(7, 10);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(99, 15);
            this.label71.TabIndex = 120;
            this.label71.Text = "Vaccine Name";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 249);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(54, 15);
            this.label35.TabIndex = 93;
            this.label35.Text = "Measles";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(9, 141);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(37, 15);
            this.label37.TabIndex = 89;
            this.label37.Text = "HIB 3";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(9, 114);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(73, 15);
            this.label39.TabIndex = 85;
            this.label39.Text = "Hepatitis B3";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(9, 87);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(85, 15);
            this.label41.TabIndex = 81;
            this.label41.Text = "DPT 3/DTaP 3";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(9, 60);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(68, 15);
            this.label43.TabIndex = 77;
            this.label43.Text = "OPV 4 / IPV";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.grbTab3);
            this.tabPage3.ImageIndex = 0;
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(450, 333);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Vaccine Tab3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // grbTab3
            // 
            this.grbTab3.Controls.Add(this.label70);
            this.grbTab3.Controls.Add(this.chkMMR2);
            this.grbTab3.Controls.Add(this.chkOPVBooster2);
            this.grbTab3.Controls.Add(this.chkDPTBooster2);
            this.grbTab3.Controls.Add(this.chkHA2);
            this.grbTab3.Controls.Add(this.chkTyphoid);
            this.grbTab3.Controls.Add(this.chkHA1);
            this.grbTab3.Controls.Add(this.chkOPVBooster);
            this.grbTab3.Controls.Add(this.chkHIBBooster);
            this.grbTab3.Controls.Add(this.chkDPTBooster1);
            this.grbTab3.Controls.Add(this.chkVaricella2);
            this.grbTab3.Controls.Add(this.chkMMR);
            this.grbTab3.Controls.Add(this.dpDPTBooster2G);
            this.grbTab3.Controls.Add(this.dpDPTBooster2D);
            this.grbTab3.Controls.Add(this.label31);
            this.grbTab3.Controls.Add(this.dpTyphoidG);
            this.grbTab3.Controls.Add(this.dpTyphoidD);
            this.grbTab3.Controls.Add(this.label44);
            this.grbTab3.Controls.Add(this.chkGivenOn3);
            this.grbTab3.Controls.Add(this.label46);
            this.grbTab3.Controls.Add(this.label48);
            this.grbTab3.Controls.Add(this.dpMMR2G);
            this.grbTab3.Controls.Add(this.dpMMR2D);
            this.grbTab3.Controls.Add(this.label50);
            this.grbTab3.Controls.Add(this.dpOPVBooster2G);
            this.grbTab3.Controls.Add(this.dpOPVBooster2D);
            this.grbTab3.Controls.Add(this.label52);
            this.grbTab3.Controls.Add(this.dpHA2G);
            this.grbTab3.Controls.Add(this.dpHA2D);
            this.grbTab3.Controls.Add(this.label54);
            this.grbTab3.Controls.Add(this.dpHA1G);
            this.grbTab3.Controls.Add(this.dpHA1D);
            this.grbTab3.Controls.Add(this.label56);
            this.grbTab3.Controls.Add(this.dpOPVBoosterG);
            this.grbTab3.Controls.Add(this.dpOPVBoosterD);
            this.grbTab3.Controls.Add(this.label58);
            this.grbTab3.Controls.Add(this.dpHIBBoosterG);
            this.grbTab3.Controls.Add(this.dpHIBBoosterD);
            this.grbTab3.Controls.Add(this.label60);
            this.grbTab3.Controls.Add(this.dpDPTBooster1G);
            this.grbTab3.Controls.Add(this.dpDPTBooster1D);
            this.grbTab3.Controls.Add(this.label62);
            this.grbTab3.Controls.Add(this.dpVaricella2G);
            this.grbTab3.Controls.Add(this.dpVaricella2D);
            this.grbTab3.Controls.Add(this.label68);
            this.grbTab3.Controls.Add(this.dpMMRG);
            this.grbTab3.Controls.Add(this.dpMMRD);
            this.grbTab3.Controls.Add(this.label69);
            this.grbTab3.Controls.Add(this.label88);
            this.grbTab3.Controls.Add(this.label33);
            this.grbTab3.Controls.Add(this.label29);
            this.grbTab3.Controls.Add(this.label90);
            this.grbTab3.Controls.Add(this.label89);
            this.grbTab3.Controls.Add(this.label75);
            this.grbTab3.Controls.Add(this.label25);
            this.grbTab3.Controls.Add(this.label27);
            this.grbTab3.Controls.Add(this.label59);
            this.grbTab3.Controls.Add(this.label61);
            this.grbTab3.Controls.Add(this.label63);
            this.grbTab3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTab3.Location = new System.Drawing.Point(4, 1);
            this.grbTab3.Name = "grbTab3";
            this.grbTab3.Size = new System.Drawing.Size(445, 329);
            this.grbTab3.TabIndex = 3;
            this.grbTab3.TabStop = false;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(6, 87);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(117, 15);
            this.label70.TabIndex = 235;
            this.label70.Text = "DPT/DTaPBooster 1";
            // 
            // chkMMR2
            // 
            this.chkMMR2.AutoSize = true;
            this.chkMMR2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMMR2.Location = new System.Drawing.Point(323, 308);
            this.chkMMR2.Name = "chkMMR2";
            this.chkMMR2.Size = new System.Drawing.Size(15, 14);
            this.chkMMR2.TabIndex = 32;
            this.chkMMR2.UseVisualStyleBackColor = true;
            this.chkMMR2.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkOPVBooster2
            // 
            this.chkOPVBooster2.AutoSize = true;
            this.chkOPVBooster2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOPVBooster2.Location = new System.Drawing.Point(323, 281);
            this.chkOPVBooster2.Name = "chkOPVBooster2";
            this.chkOPVBooster2.Size = new System.Drawing.Size(15, 14);
            this.chkOPVBooster2.TabIndex = 29;
            this.chkOPVBooster2.UseVisualStyleBackColor = true;
            this.chkOPVBooster2.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkDPTBooster2
            // 
            this.chkDPTBooster2.AutoSize = true;
            this.chkDPTBooster2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDPTBooster2.Location = new System.Drawing.Point(323, 254);
            this.chkDPTBooster2.Name = "chkDPTBooster2";
            this.chkDPTBooster2.Size = new System.Drawing.Size(15, 14);
            this.chkDPTBooster2.TabIndex = 26;
            this.chkDPTBooster2.UseVisualStyleBackColor = true;
            this.chkDPTBooster2.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkHA2
            // 
            this.chkHA2.AutoSize = true;
            this.chkHA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHA2.Location = new System.Drawing.Point(323, 226);
            this.chkHA2.Name = "chkHA2";
            this.chkHA2.Size = new System.Drawing.Size(15, 14);
            this.chkHA2.TabIndex = 23;
            this.chkHA2.UseVisualStyleBackColor = true;
            this.chkHA2.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkTyphoid
            // 
            this.chkTyphoid.AutoSize = true;
            this.chkTyphoid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTyphoid.Location = new System.Drawing.Point(323, 202);
            this.chkTyphoid.Name = "chkTyphoid";
            this.chkTyphoid.Size = new System.Drawing.Size(15, 14);
            this.chkTyphoid.TabIndex = 20;
            this.chkTyphoid.UseVisualStyleBackColor = true;
            this.chkTyphoid.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkHA1
            // 
            this.chkHA1.AutoSize = true;
            this.chkHA1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHA1.Location = new System.Drawing.Point(323, 174);
            this.chkHA1.Name = "chkHA1";
            this.chkHA1.Size = new System.Drawing.Size(15, 14);
            this.chkHA1.TabIndex = 17;
            this.chkHA1.UseVisualStyleBackColor = true;
            this.chkHA1.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkOPVBooster
            // 
            this.chkOPVBooster.AutoSize = true;
            this.chkOPVBooster.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOPVBooster.Location = new System.Drawing.Point(323, 145);
            this.chkOPVBooster.Name = "chkOPVBooster";
            this.chkOPVBooster.Size = new System.Drawing.Size(15, 14);
            this.chkOPVBooster.TabIndex = 14;
            this.chkOPVBooster.UseVisualStyleBackColor = true;
            this.chkOPVBooster.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkHIBBooster
            // 
            this.chkHIBBooster.AutoSize = true;
            this.chkHIBBooster.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHIBBooster.Location = new System.Drawing.Point(323, 119);
            this.chkHIBBooster.Name = "chkHIBBooster";
            this.chkHIBBooster.Size = new System.Drawing.Size(15, 14);
            this.chkHIBBooster.TabIndex = 11;
            this.chkHIBBooster.UseVisualStyleBackColor = true;
            this.chkHIBBooster.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkDPTBooster1
            // 
            this.chkDPTBooster1.AutoSize = true;
            this.chkDPTBooster1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDPTBooster1.Location = new System.Drawing.Point(323, 91);
            this.chkDPTBooster1.Name = "chkDPTBooster1";
            this.chkDPTBooster1.Size = new System.Drawing.Size(15, 14);
            this.chkDPTBooster1.TabIndex = 8;
            this.chkDPTBooster1.UseVisualStyleBackColor = true;
            this.chkDPTBooster1.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkVaricella2
            // 
            this.chkVaricella2.AutoSize = true;
            this.chkVaricella2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkVaricella2.Location = new System.Drawing.Point(323, 65);
            this.chkVaricella2.Name = "chkVaricella2";
            this.chkVaricella2.Size = new System.Drawing.Size(15, 14);
            this.chkVaricella2.TabIndex = 5;
            this.chkVaricella2.UseVisualStyleBackColor = true;
            this.chkVaricella2.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // chkMMR
            // 
            this.chkMMR.AutoSize = true;
            this.chkMMR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMMR.Location = new System.Drawing.Point(323, 37);
            this.chkMMR.Name = "chkMMR";
            this.chkMMR.Size = new System.Drawing.Size(15, 14);
            this.chkMMR.TabIndex = 2;
            this.chkMMR.UseVisualStyleBackColor = true;
            this.chkMMR.CheckedChanged += new System.EventHandler(this.chkMMR_CheckedChanged);
            // 
            // dpDPTBooster2G
            // 
            this.dpDPTBooster2G.CustomFormat = "dd/MM/yyyy";
            this.dpDPTBooster2G.Enabled = false;
            this.dpDPTBooster2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPTBooster2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPTBooster2G.Location = new System.Drawing.Point(342, 249);
            this.dpDPTBooster2G.Name = "dpDPTBooster2G";
            this.dpDPTBooster2G.Size = new System.Drawing.Size(90, 22);
            this.dpDPTBooster2G.TabIndex = 27;
            // 
            // dpDPTBooster2D
            // 
            this.dpDPTBooster2D.CustomFormat = "dd/MM/yyyy";
            this.dpDPTBooster2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPTBooster2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPTBooster2D.Location = new System.Drawing.Point(210, 249);
            this.dpDPTBooster2D.Name = "dpDPTBooster2D";
            this.dpDPTBooster2D.Size = new System.Drawing.Size(90, 22);
            this.dpDPTBooster2D.TabIndex = 25;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(124, 249);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(48, 15);
            this.label31.TabIndex = 221;
            this.label31.Text = "5 Years";
            // 
            // dpTyphoidG
            // 
            this.dpTyphoidG.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoidG.Enabled = false;
            this.dpTyphoidG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoidG.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoidG.Location = new System.Drawing.Point(342, 195);
            this.dpTyphoidG.Name = "dpTyphoidG";
            this.dpTyphoidG.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoidG.TabIndex = 21;
            // 
            // dpTyphoidD
            // 
            this.dpTyphoidD.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoidD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoidD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoidD.Location = new System.Drawing.Point(210, 195);
            this.dpTyphoidD.Name = "dpTyphoidD";
            this.dpTyphoidD.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoidD.TabIndex = 19;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(124, 195);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(67, 15);
            this.label44.TabIndex = 218;
            this.label44.Text = "24 M(2Yrs)";
            // 
            // chkGivenOn3
            // 
            this.chkGivenOn3.AutoSize = true;
            this.chkGivenOn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGivenOn3.Location = new System.Drawing.Point(324, 10);
            this.chkGivenOn3.Name = "chkGivenOn3";
            this.chkGivenOn3.Size = new System.Drawing.Size(79, 17);
            this.chkGivenOn3.TabIndex = 0;
            this.chkGivenOn3.Text = "Given On";
            this.chkGivenOn3.UseVisualStyleBackColor = true;
            this.chkGivenOn3.CheckedChanged += new System.EventHandler(this.chkGivenOn1_CheckedChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(210, 10);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(67, 15);
            this.label46.TabIndex = 216;
            this.label46.Text = "Due Date";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.Transparent;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(124, 10);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(31, 15);
            this.label48.TabIndex = 215;
            this.label48.Text = "Age";
            // 
            // dpMMR2G
            // 
            this.dpMMR2G.CustomFormat = "dd/MM/yyyy";
            this.dpMMR2G.Enabled = false;
            this.dpMMR2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpMMR2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpMMR2G.Location = new System.Drawing.Point(339, 303);
            this.dpMMR2G.Name = "dpMMR2G";
            this.dpMMR2G.Size = new System.Drawing.Size(90, 22);
            this.dpMMR2G.TabIndex = 33;
            // 
            // dpMMR2D
            // 
            this.dpMMR2D.CustomFormat = "dd/MM/yyyy";
            this.dpMMR2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpMMR2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpMMR2D.Location = new System.Drawing.Point(210, 303);
            this.dpMMR2D.Name = "dpMMR2D";
            this.dpMMR2D.Size = new System.Drawing.Size(90, 22);
            this.dpMMR2D.TabIndex = 31;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(124, 303);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(59, 15);
            this.label50.TabIndex = 212;
            this.label50.Text = "4-5 Years";
            // 
            // dpOPVBooster2G
            // 
            this.dpOPVBooster2G.CustomFormat = "dd/MM/yyyy";
            this.dpOPVBooster2G.Enabled = false;
            this.dpOPVBooster2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPVBooster2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPVBooster2G.Location = new System.Drawing.Point(339, 276);
            this.dpOPVBooster2G.Name = "dpOPVBooster2G";
            this.dpOPVBooster2G.Size = new System.Drawing.Size(90, 22);
            this.dpOPVBooster2G.TabIndex = 30;
            // 
            // dpOPVBooster2D
            // 
            this.dpOPVBooster2D.CustomFormat = "dd/MM/yyyy";
            this.dpOPVBooster2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPVBooster2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPVBooster2D.Location = new System.Drawing.Point(210, 276);
            this.dpOPVBooster2D.Name = "dpOPVBooster2D";
            this.dpOPVBooster2D.Size = new System.Drawing.Size(90, 22);
            this.dpOPVBooster2D.TabIndex = 28;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(124, 276);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(48, 15);
            this.label52.TabIndex = 209;
            this.label52.Text = "5 Years";
            // 
            // dpHA2G
            // 
            this.dpHA2G.CustomFormat = "dd/MM/yyyy";
            this.dpHA2G.Enabled = false;
            this.dpHA2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHA2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHA2G.Location = new System.Drawing.Point(342, 222);
            this.dpHA2G.Name = "dpHA2G";
            this.dpHA2G.Size = new System.Drawing.Size(90, 22);
            this.dpHA2G.TabIndex = 24;
            // 
            // dpHA2D
            // 
            this.dpHA2D.CustomFormat = "dd/MM/yyyy";
            this.dpHA2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHA2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHA2D.Location = new System.Drawing.Point(210, 222);
            this.dpHA2D.Name = "dpHA2D";
            this.dpHA2D.Size = new System.Drawing.Size(90, 22);
            this.dpHA2D.TabIndex = 22;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(124, 222);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(67, 15);
            this.label54.TabIndex = 206;
            this.label54.Text = "24 M(2Yrs)";
            // 
            // dpHA1G
            // 
            this.dpHA1G.CustomFormat = "dd/MM/yyyy";
            this.dpHA1G.Enabled = false;
            this.dpHA1G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHA1G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHA1G.Location = new System.Drawing.Point(342, 168);
            this.dpHA1G.Name = "dpHA1G";
            this.dpHA1G.Size = new System.Drawing.Size(90, 22);
            this.dpHA1G.TabIndex = 18;
            // 
            // dpHA1D
            // 
            this.dpHA1D.CustomFormat = "dd/MM/yyyy";
            this.dpHA1D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHA1D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHA1D.Location = new System.Drawing.Point(210, 168);
            this.dpHA1D.Name = "dpHA1D";
            this.dpHA1D.Size = new System.Drawing.Size(90, 22);
            this.dpHA1D.TabIndex = 16;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(124, 168);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(65, 15);
            this.label56.TabIndex = 203;
            this.label56.Text = "18 Months";
            // 
            // dpOPVBoosterG
            // 
            this.dpOPVBoosterG.CustomFormat = "dd/MM/yyyy";
            this.dpOPVBoosterG.Enabled = false;
            this.dpOPVBoosterG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPVBoosterG.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPVBoosterG.Location = new System.Drawing.Point(342, 141);
            this.dpOPVBoosterG.Name = "dpOPVBoosterG";
            this.dpOPVBoosterG.Size = new System.Drawing.Size(90, 22);
            this.dpOPVBoosterG.TabIndex = 15;
            // 
            // dpOPVBoosterD
            // 
            this.dpOPVBoosterD.CustomFormat = "dd/MM/yyyy";
            this.dpOPVBoosterD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpOPVBoosterD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpOPVBoosterD.Location = new System.Drawing.Point(210, 141);
            this.dpOPVBoosterD.Name = "dpOPVBoosterD";
            this.dpOPVBoosterD.Size = new System.Drawing.Size(90, 22);
            this.dpOPVBoosterD.TabIndex = 13;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(124, 141);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(65, 15);
            this.label58.TabIndex = 200;
            this.label58.Text = "18 Months";
            // 
            // dpHIBBoosterG
            // 
            this.dpHIBBoosterG.CustomFormat = "dd/MM/yyyy";
            this.dpHIBBoosterG.Enabled = false;
            this.dpHIBBoosterG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHIBBoosterG.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHIBBoosterG.Location = new System.Drawing.Point(342, 114);
            this.dpHIBBoosterG.Name = "dpHIBBoosterG";
            this.dpHIBBoosterG.Size = new System.Drawing.Size(90, 22);
            this.dpHIBBoosterG.TabIndex = 12;
            // 
            // dpHIBBoosterD
            // 
            this.dpHIBBoosterD.CustomFormat = "dd/MM/yyyy";
            this.dpHIBBoosterD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHIBBoosterD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHIBBoosterD.Location = new System.Drawing.Point(210, 114);
            this.dpHIBBoosterD.Name = "dpHIBBoosterD";
            this.dpHIBBoosterD.Size = new System.Drawing.Size(90, 22);
            this.dpHIBBoosterD.TabIndex = 10;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(124, 114);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(65, 15);
            this.label60.TabIndex = 197;
            this.label60.Text = "18 Months";
            // 
            // dpDPTBooster1G
            // 
            this.dpDPTBooster1G.CustomFormat = "dd/MM/yyyy";
            this.dpDPTBooster1G.Enabled = false;
            this.dpDPTBooster1G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPTBooster1G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPTBooster1G.Location = new System.Drawing.Point(342, 87);
            this.dpDPTBooster1G.Name = "dpDPTBooster1G";
            this.dpDPTBooster1G.Size = new System.Drawing.Size(90, 22);
            this.dpDPTBooster1G.TabIndex = 9;
            // 
            // dpDPTBooster1D
            // 
            this.dpDPTBooster1D.CustomFormat = "dd/MM/yyyy";
            this.dpDPTBooster1D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpDPTBooster1D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpDPTBooster1D.Location = new System.Drawing.Point(210, 87);
            this.dpDPTBooster1D.Name = "dpDPTBooster1D";
            this.dpDPTBooster1D.Size = new System.Drawing.Size(90, 22);
            this.dpDPTBooster1D.TabIndex = 7;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(124, 87);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(65, 15);
            this.label62.TabIndex = 194;
            this.label62.Text = "18 Months";
            // 
            // dpVaricella2G
            // 
            this.dpVaricella2G.CustomFormat = "dd/MM/yyyy";
            this.dpVaricella2G.Enabled = false;
            this.dpVaricella2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpVaricella2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpVaricella2G.Location = new System.Drawing.Point(342, 60);
            this.dpVaricella2G.Name = "dpVaricella2G";
            this.dpVaricella2G.Size = new System.Drawing.Size(90, 22);
            this.dpVaricella2G.TabIndex = 6;
            // 
            // dpVaricella2D
            // 
            this.dpVaricella2D.CustomFormat = "dd/MM/yyyy";
            this.dpVaricella2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpVaricella2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpVaricella2D.Location = new System.Drawing.Point(210, 60);
            this.dpVaricella2D.Name = "dpVaricella2D";
            this.dpVaricella2D.Size = new System.Drawing.Size(90, 22);
            this.dpVaricella2D.TabIndex = 4;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(124, 60);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(65, 15);
            this.label68.TabIndex = 191;
            this.label68.Text = "15 Months";
            // 
            // dpMMRG
            // 
            this.dpMMRG.CustomFormat = "dd/MM/yyyy";
            this.dpMMRG.Enabled = false;
            this.dpMMRG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpMMRG.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpMMRG.Location = new System.Drawing.Point(342, 33);
            this.dpMMRG.Name = "dpMMRG";
            this.dpMMRG.Size = new System.Drawing.Size(90, 22);
            this.dpMMRG.TabIndex = 3;
            // 
            // dpMMRD
            // 
            this.dpMMRD.CustomFormat = "dd/MM/yyyy";
            this.dpMMRD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpMMRD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpMMRD.Location = new System.Drawing.Point(210, 33);
            this.dpMMRD.Name = "dpMMRD";
            this.dpMMRD.Size = new System.Drawing.Size(90, 22);
            this.dpMMRD.TabIndex = 1;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(124, 33);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(65, 15);
            this.label69.TabIndex = 188;
            this.label69.Text = "15 Months";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(6, 60);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(64, 15);
            this.label88.TabIndex = 142;
            this.label88.Text = "Varicella 2";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 33);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(38, 15);
            this.label33.TabIndex = 141;
            this.label33.Text = "MMR";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 114);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(72, 15);
            this.label29.TabIndex = 133;
            this.label29.Text = "HIB Booster";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(6, 222);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(81, 15);
            this.label90.TabIndex = 129;
            this.label90.Text = "Hepatitis ‘A’ 2";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(6, 168);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(81, 15);
            this.label89.TabIndex = 128;
            this.label89.Text = "Hepatitis ‘A’ 1";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.Transparent;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(6, 10);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(99, 15);
            this.label75.TabIndex = 124;
            this.label75.Text = "Vaccine Name";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 195);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(50, 15);
            this.label25.TabIndex = 113;
            this.label25.Text = "Typhoid";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 141);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 15);
            this.label27.TabIndex = 109;
            this.label27.Text = "OPV Booster / IPV";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(6, 303);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(94, 15);
            this.label59.TabIndex = 85;
            this.label59.Text = "MMR 2nd Dose";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(6, 276);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(103, 15);
            this.label61.TabIndex = 81;
            this.label61.Text = "OPV Booster / IPV";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(6, 249);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(116, 15);
            this.label63.TabIndex = 77;
            this.label63.Text = "DPT / DTaP Booster";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.grbTab4);
            this.tabPage4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage4.ImageIndex = 4;
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(450, 333);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Vaccine Tab4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // grbTab4
            // 
            this.grbTab4.Controls.Add(this.label72);
            this.grbTab4.Controls.Add(this.label94);
            this.grbTab4.Controls.Add(this.label103);
            this.grbTab4.Controls.Add(this.chkTBooster2);
            this.grbTab4.Controls.Add(this.chkTyphoid5);
            this.grbTab4.Controls.Add(this.chkTyphoid4);
            this.grbTab4.Controls.Add(this.chkTBooster1);
            this.grbTab4.Controls.Add(this.chkTyphoid3);
            this.grbTab4.Controls.Add(this.chkTyphoid2);
            this.grbTab4.Controls.Add(this.chkHBB);
            this.grbTab4.Controls.Add(this.chkVaricellaBooster);
            this.grbTab4.Controls.Add(this.dpTyphoid5G);
            this.grbTab4.Controls.Add(this.dpTyphoid5D);
            this.grbTab4.Controls.Add(this.label73);
            this.grbTab4.Controls.Add(this.chkGivenOn4);
            this.grbTab4.Controls.Add(this.label74);
            this.grbTab4.Controls.Add(this.label93);
            this.grbTab4.Controls.Add(this.dpTBooster2G);
            this.grbTab4.Controls.Add(this.dpTBooster2D);
            this.grbTab4.Controls.Add(this.label96);
            this.grbTab4.Controls.Add(this.dpTyphoid4G);
            this.grbTab4.Controls.Add(this.dpTyphoid4D);
            this.grbTab4.Controls.Add(this.label97);
            this.grbTab4.Controls.Add(this.dpTBooster1G);
            this.grbTab4.Controls.Add(this.dpTBooster1D);
            this.grbTab4.Controls.Add(this.label98);
            this.grbTab4.Controls.Add(this.dpTyphoid3G);
            this.grbTab4.Controls.Add(this.dpTyphoid3D);
            this.grbTab4.Controls.Add(this.label99);
            this.grbTab4.Controls.Add(this.dpTyphoid2G);
            this.grbTab4.Controls.Add(this.dpTyphoid2D);
            this.grbTab4.Controls.Add(this.label100);
            this.grbTab4.Controls.Add(this.dpHBBG);
            this.grbTab4.Controls.Add(this.dpHBBD);
            this.grbTab4.Controls.Add(this.label101);
            this.grbTab4.Controls.Add(this.dpVaricellaBoosterG);
            this.grbTab4.Controls.Add(this.dpVaricellaBoosterD);
            this.grbTab4.Controls.Add(this.label102);
            this.grbTab4.Controls.Add(this.label91);
            this.grbTab4.Controls.Add(this.label92);
            this.grbTab4.Controls.Add(this.label57);
            this.grbTab4.Controls.Add(this.label53);
            this.grbTab4.Controls.Add(this.label55);
            this.grbTab4.Controls.Add(this.label49);
            this.grbTab4.Controls.Add(this.label45);
            this.grbTab4.Controls.Add(this.label51);
            this.grbTab4.Controls.Add(this.label47);
            this.grbTab4.Location = new System.Drawing.Point(2, -2);
            this.grbTab4.Name = "grbTab4";
            this.grbTab4.Size = new System.Drawing.Size(445, 333);
            this.grbTab4.TabIndex = 283;
            this.grbTab4.TabStop = false;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(86, 259);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(212, 15);
            this.label72.TabIndex = 319;
            this.label72.Text = ": 1 dose annually after 6 months";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.ForeColor = System.Drawing.Color.Red;
            this.label94.Location = new System.Drawing.Point(16, 304);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(371, 15);
            this.label94.TabIndex = 332;
            this.label94.Text = "See Next Tab for IMMUNIZATION SCHEDULE IN ADULTS";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.BackColor = System.Drawing.Color.Transparent;
            this.label103.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(4, 10);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(99, 15);
            this.label103.TabIndex = 331;
            this.label103.Text = "Vaccine Name";
            // 
            // chkTBooster2
            // 
            this.chkTBooster2.AutoSize = true;
            this.chkTBooster2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTBooster2.Location = new System.Drawing.Point(327, 226);
            this.chkTBooster2.Name = "chkTBooster2";
            this.chkTBooster2.Size = new System.Drawing.Size(15, 14);
            this.chkTBooster2.TabIndex = 23;
            this.chkTBooster2.UseVisualStyleBackColor = true;
            this.chkTBooster2.CheckedChanged += new System.EventHandler(this.chkVaricellaBooster_CheckedChanged);
            // 
            // chkTyphoid5
            // 
            this.chkTyphoid5.AutoSize = true;
            this.chkTyphoid5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTyphoid5.Location = new System.Drawing.Point(327, 202);
            this.chkTyphoid5.Name = "chkTyphoid5";
            this.chkTyphoid5.Size = new System.Drawing.Size(15, 14);
            this.chkTyphoid5.TabIndex = 20;
            this.chkTyphoid5.UseVisualStyleBackColor = true;
            this.chkTyphoid5.CheckedChanged += new System.EventHandler(this.chkVaricellaBooster_CheckedChanged);
            // 
            // chkTyphoid4
            // 
            this.chkTyphoid4.AutoSize = true;
            this.chkTyphoid4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTyphoid4.Location = new System.Drawing.Point(327, 174);
            this.chkTyphoid4.Name = "chkTyphoid4";
            this.chkTyphoid4.Size = new System.Drawing.Size(15, 14);
            this.chkTyphoid4.TabIndex = 17;
            this.chkTyphoid4.UseVisualStyleBackColor = true;
            this.chkTyphoid4.CheckedChanged += new System.EventHandler(this.chkVaricellaBooster_CheckedChanged);
            // 
            // chkTBooster1
            // 
            this.chkTBooster1.AutoSize = true;
            this.chkTBooster1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTBooster1.Location = new System.Drawing.Point(327, 145);
            this.chkTBooster1.Name = "chkTBooster1";
            this.chkTBooster1.Size = new System.Drawing.Size(15, 14);
            this.chkTBooster1.TabIndex = 14;
            this.chkTBooster1.UseVisualStyleBackColor = true;
            this.chkTBooster1.CheckedChanged += new System.EventHandler(this.chkVaricellaBooster_CheckedChanged);
            // 
            // chkTyphoid3
            // 
            this.chkTyphoid3.AutoSize = true;
            this.chkTyphoid3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTyphoid3.Location = new System.Drawing.Point(327, 119);
            this.chkTyphoid3.Name = "chkTyphoid3";
            this.chkTyphoid3.Size = new System.Drawing.Size(15, 14);
            this.chkTyphoid3.TabIndex = 11;
            this.chkTyphoid3.UseVisualStyleBackColor = true;
            this.chkTyphoid3.CheckedChanged += new System.EventHandler(this.chkVaricellaBooster_CheckedChanged);
            // 
            // chkTyphoid2
            // 
            this.chkTyphoid2.AutoSize = true;
            this.chkTyphoid2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTyphoid2.Location = new System.Drawing.Point(327, 91);
            this.chkTyphoid2.Name = "chkTyphoid2";
            this.chkTyphoid2.Size = new System.Drawing.Size(15, 14);
            this.chkTyphoid2.TabIndex = 8;
            this.chkTyphoid2.UseVisualStyleBackColor = true;
            this.chkTyphoid2.CheckedChanged += new System.EventHandler(this.chkVaricellaBooster_CheckedChanged);
            // 
            // chkHBB
            // 
            this.chkHBB.AutoSize = true;
            this.chkHBB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkHBB.Location = new System.Drawing.Point(327, 65);
            this.chkHBB.Name = "chkHBB";
            this.chkHBB.Size = new System.Drawing.Size(15, 14);
            this.chkHBB.TabIndex = 5;
            this.chkHBB.UseVisualStyleBackColor = true;
            this.chkHBB.CheckedChanged += new System.EventHandler(this.chkVaricellaBooster_CheckedChanged);
            // 
            // chkVaricellaBooster
            // 
            this.chkVaricellaBooster.AutoSize = true;
            this.chkVaricellaBooster.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkVaricellaBooster.Location = new System.Drawing.Point(327, 37);
            this.chkVaricellaBooster.Name = "chkVaricellaBooster";
            this.chkVaricellaBooster.Size = new System.Drawing.Size(15, 14);
            this.chkVaricellaBooster.TabIndex = 2;
            this.chkVaricellaBooster.UseVisualStyleBackColor = true;
            this.chkVaricellaBooster.CheckedChanged += new System.EventHandler(this.chkVaricellaBooster_CheckedChanged);
            // 
            // dpTyphoid5G
            // 
            this.dpTyphoid5G.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoid5G.Enabled = false;
            this.dpTyphoid5G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoid5G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoid5G.Location = new System.Drawing.Point(346, 195);
            this.dpTyphoid5G.Name = "dpTyphoid5G";
            this.dpTyphoid5G.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoid5G.TabIndex = 21;
            // 
            // dpTyphoid5D
            // 
            this.dpTyphoid5D.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoid5D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoid5D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoid5D.Location = new System.Drawing.Point(211, 195);
            this.dpTyphoid5D.Name = "dpTyphoid5D";
            this.dpTyphoid5D.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoid5D.TabIndex = 19;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(125, 202);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(55, 15);
            this.label73.TabIndex = 316;
            this.label73.Text = "14 Years";
            // 
            // chkGivenOn4
            // 
            this.chkGivenOn4.AutoSize = true;
            this.chkGivenOn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGivenOn4.Location = new System.Drawing.Point(328, 10);
            this.chkGivenOn4.Name = "chkGivenOn4";
            this.chkGivenOn4.Size = new System.Drawing.Size(79, 17);
            this.chkGivenOn4.TabIndex = 0;
            this.chkGivenOn4.Text = "Given On";
            this.chkGivenOn4.UseVisualStyleBackColor = true;
            this.chkGivenOn4.CheckedChanged += new System.EventHandler(this.chkGivenOn1_CheckedChanged);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.Transparent;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(211, 10);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(67, 15);
            this.label74.TabIndex = 314;
            this.label74.Text = "Due Date";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.BackColor = System.Drawing.Color.Transparent;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(125, 10);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(31, 15);
            this.label93.TabIndex = 313;
            this.label93.Text = "Age";
            // 
            // dpTBooster2G
            // 
            this.dpTBooster2G.CustomFormat = "dd/MM/yyyy";
            this.dpTBooster2G.Enabled = false;
            this.dpTBooster2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTBooster2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTBooster2G.Location = new System.Drawing.Point(346, 223);
            this.dpTBooster2G.Name = "dpTBooster2G";
            this.dpTBooster2G.Size = new System.Drawing.Size(90, 22);
            this.dpTBooster2G.TabIndex = 24;
            // 
            // dpTBooster2D
            // 
            this.dpTBooster2D.CustomFormat = "dd/MM/yyyy";
            this.dpTBooster2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTBooster2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTBooster2D.Location = new System.Drawing.Point(211, 223);
            this.dpTBooster2D.Name = "dpTBooster2D";
            this.dpTBooster2D.Size = new System.Drawing.Size(90, 22);
            this.dpTBooster2D.TabIndex = 22;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(125, 230);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(55, 15);
            this.label96.TabIndex = 310;
            this.label96.Text = "16 Years";
            // 
            // dpTyphoid4G
            // 
            this.dpTyphoid4G.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoid4G.Enabled = false;
            this.dpTyphoid4G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoid4G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoid4G.Location = new System.Drawing.Point(346, 168);
            this.dpTyphoid4G.Name = "dpTyphoid4G";
            this.dpTyphoid4G.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoid4G.TabIndex = 18;
            // 
            // dpTyphoid4D
            // 
            this.dpTyphoid4D.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoid4D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoid4D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoid4D.Location = new System.Drawing.Point(211, 168);
            this.dpTyphoid4D.Name = "dpTyphoid4D";
            this.dpTyphoid4D.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoid4D.TabIndex = 16;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(125, 175);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(55, 15);
            this.label97.TabIndex = 307;
            this.label97.Text = "11 Years";
            // 
            // dpTBooster1G
            // 
            this.dpTBooster1G.CustomFormat = "dd/MM/yyyy";
            this.dpTBooster1G.Enabled = false;
            this.dpTBooster1G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTBooster1G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTBooster1G.Location = new System.Drawing.Point(346, 141);
            this.dpTBooster1G.Name = "dpTBooster1G";
            this.dpTBooster1G.Size = new System.Drawing.Size(90, 22);
            this.dpTBooster1G.TabIndex = 15;
            // 
            // dpTBooster1D
            // 
            this.dpTBooster1D.CustomFormat = "dd/MM/yyyy";
            this.dpTBooster1D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTBooster1D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTBooster1D.Location = new System.Drawing.Point(211, 141);
            this.dpTBooster1D.Name = "dpTBooster1D";
            this.dpTBooster1D.Size = new System.Drawing.Size(90, 22);
            this.dpTBooster1D.TabIndex = 13;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(125, 148);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(55, 15);
            this.label98.TabIndex = 304;
            this.label98.Text = "10 Years";
            // 
            // dpTyphoid3G
            // 
            this.dpTyphoid3G.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoid3G.Enabled = false;
            this.dpTyphoid3G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoid3G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoid3G.Location = new System.Drawing.Point(346, 114);
            this.dpTyphoid3G.Name = "dpTyphoid3G";
            this.dpTyphoid3G.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoid3G.TabIndex = 12;
            // 
            // dpTyphoid3D
            // 
            this.dpTyphoid3D.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoid3D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoid3D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoid3D.Location = new System.Drawing.Point(211, 114);
            this.dpTyphoid3D.Name = "dpTyphoid3D";
            this.dpTyphoid3D.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoid3D.TabIndex = 10;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(125, 121);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(48, 15);
            this.label99.TabIndex = 301;
            this.label99.Text = "8 Years";
            // 
            // dpTyphoid2G
            // 
            this.dpTyphoid2G.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoid2G.Enabled = false;
            this.dpTyphoid2G.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoid2G.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoid2G.Location = new System.Drawing.Point(346, 87);
            this.dpTyphoid2G.Name = "dpTyphoid2G";
            this.dpTyphoid2G.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoid2G.TabIndex = 9;
            // 
            // dpTyphoid2D
            // 
            this.dpTyphoid2D.CustomFormat = "dd/MM/yyyy";
            this.dpTyphoid2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpTyphoid2D.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpTyphoid2D.Location = new System.Drawing.Point(211, 87);
            this.dpTyphoid2D.Name = "dpTyphoid2D";
            this.dpTyphoid2D.Size = new System.Drawing.Size(90, 22);
            this.dpTyphoid2D.TabIndex = 7;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(125, 94);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(48, 15);
            this.label100.TabIndex = 298;
            this.label100.Text = "5 Years";
            // 
            // dpHBBG
            // 
            this.dpHBBG.CustomFormat = "dd/MM/yyyy";
            this.dpHBBG.Enabled = false;
            this.dpHBBG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHBBG.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHBBG.Location = new System.Drawing.Point(346, 60);
            this.dpHBBG.Name = "dpHBBG";
            this.dpHBBG.Size = new System.Drawing.Size(90, 22);
            this.dpHBBG.TabIndex = 6;
            // 
            // dpHBBD
            // 
            this.dpHBBD.CustomFormat = "dd/MM/yyyy";
            this.dpHBBD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpHBBD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpHBBD.Location = new System.Drawing.Point(211, 60);
            this.dpHBBD.Name = "dpHBBD";
            this.dpHBBD.Size = new System.Drawing.Size(90, 22);
            this.dpHBBD.TabIndex = 4;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(125, 67);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(58, 15);
            this.label101.TabIndex = 295;
            this.label101.Text = "After 5Yrs";
            // 
            // dpVaricellaBoosterG
            // 
            this.dpVaricellaBoosterG.CustomFormat = "dd/MM/yyyy";
            this.dpVaricellaBoosterG.Enabled = false;
            this.dpVaricellaBoosterG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpVaricellaBoosterG.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpVaricellaBoosterG.Location = new System.Drawing.Point(346, 33);
            this.dpVaricellaBoosterG.Name = "dpVaricellaBoosterG";
            this.dpVaricellaBoosterG.Size = new System.Drawing.Size(90, 22);
            this.dpVaricellaBoosterG.TabIndex = 3;
            // 
            // dpVaricellaBoosterD
            // 
            this.dpVaricellaBoosterD.CustomFormat = "dd/MM/yyyy";
            this.dpVaricellaBoosterD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpVaricellaBoosterD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpVaricellaBoosterD.Location = new System.Drawing.Point(211, 33);
            this.dpVaricellaBoosterD.Name = "dpVaricellaBoosterD";
            this.dpVaricellaBoosterD.Size = new System.Drawing.Size(90, 22);
            this.dpVaricellaBoosterD.TabIndex = 1;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(125, 40);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(56, 15);
            this.label102.TabIndex = 292;
            this.label102.Text = "4-5Years";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(4, 40);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(99, 15);
            this.label91.TabIndex = 291;
            this.label91.Text = "Varicella Booster";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(4, 67);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(111, 15);
            this.label92.TabIndex = 290;
            this.label92.Text = "Hepatitis B Booster";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(4, 94);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(60, 15);
            this.label57.TabIndex = 289;
            this.label57.Text = "Typhoid 2";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(4, 148);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(80, 15);
            this.label53.TabIndex = 288;
            this.label53.Text = "Tdap Booster";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(4, 121);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(60, 15);
            this.label55.TabIndex = 287;
            this.label55.Text = "Typhoid 3";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(4, 202);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(60, 15);
            this.label49.TabIndex = 284;
            this.label49.Text = "Typhoid 5";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(4, 259);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(57, 15);
            this.label45.TabIndex = 286;
            this.label45.Text = "Influenza";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(4, 175);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(60, 15);
            this.label51.TabIndex = 283;
            this.label51.Text = "Typhoid 4";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(4, 230);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(80, 15);
            this.label47.TabIndex = 285;
            this.label47.Text = "Tdap Booster";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.grbTab5);
            this.tabPage5.ImageIndex = 2;
            this.tabPage5.Location = new System.Drawing.Point(4, 27);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(450, 333);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // grbTab5
            // 
            this.grbTab5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("grbTab5.BackgroundImage")));
            this.grbTab5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.grbTab5.Location = new System.Drawing.Point(1, -5);
            this.grbTab5.Name = "grbTab5";
            this.grbTab5.Size = new System.Drawing.Size(447, 341);
            this.grbTab5.TabIndex = 0;
            this.grbTab5.TabStop = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "syringe.png");
            this.imageList1.Images.SetKeyName(1, "syringe (2).png");
            this.imageList1.Images.SetKeyName(2, "imgonline-com-ua-resize-pZHsUCFQPXLe.png");
            this.imageList1.Images.SetKeyName(3, "vaccine (3).png");
            this.imageList1.Images.SetKeyName(4, "vaccine.png");
            // 
            // dgPatients
            // 
            this.dgPatients.AllowUserToAddRows = false;
            this.dgPatients.AllowUserToDeleteRows = false;
            this.dgPatients.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgPatients.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPatients.BackgroundColor = System.Drawing.Color.Lavender;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPatients.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgPatients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPatients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ChildName,
            this.FilePath});
            this.dgPatients.Location = new System.Drawing.Point(465, 85);
            this.dgPatients.MultiSelect = false;
            this.dgPatients.Name = "dgPatients";
            this.dgPatients.ReadOnly = true;
            this.dgPatients.RowHeadersVisible = false;
            this.dgPatients.RowHeadersWidth = 15;
            this.dgPatients.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgPatients.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgPatients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPatients.Size = new System.Drawing.Size(386, 437);
            this.dgPatients.TabIndex = 21;
            this.dgPatients.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPatients_CellClick);
            this.dgPatients.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPatients_CellDoubleClick);
            this.dgPatients.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgPatients_CellMouseDown);
            this.dgPatients.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgPatients_ColumnHeaderMouseClick);
            // 
            // ChildName
            // 
            this.ChildName.DataPropertyName = "ChildName";
            this.ChildName.FillWeight = 65.98985F;
            this.ChildName.HeaderText = "Child Name";
            this.ChildName.MinimumWidth = 20;
            this.ChildName.Name = "ChildName";
            this.ChildName.ReadOnly = true;
            this.ChildName.ToolTipText = "Child Name";
            // 
            // FilePath
            // 
            this.FilePath.DataPropertyName = "FilePath";
            this.FilePath.FillWeight = 134.0102F;
            this.FilePath.HeaderText = "File Path";
            this.FilePath.MinimumWidth = 20;
            this.FilePath.Name = "FilePath";
            this.FilePath.ReadOnly = true;
            this.FilePath.ToolTipText = "File Path";
            // 
            // grbSearch
            // 
            this.grbSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbSearch.BackColor = System.Drawing.Color.Transparent;
            this.grbSearch.Controls.Add(this.btnSearch);
            this.grbSearch.Controls.Add(this.txtSearch);
            this.grbSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSearch.ForeColor = System.Drawing.Color.Blue;
            this.grbSearch.Location = new System.Drawing.Point(462, 24);
            this.grbSearch.Name = "grbSearch";
            this.grbSearch.Size = new System.Drawing.Size(388, 40);
            this.grbSearch.TabIndex = 18;
            this.grbSearch.TabStop = false;
            this.grbSearch.Text = "Search";
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.BackColor = System.Drawing.Color.Teal;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.Location = new System.Drawing.Point(356, 14);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(25, 22);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(6, 14);
            this.txtSearch.MaxLength = 50;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(348, 22);
            this.txtSearch.TabIndex = 19;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.Transparent;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.ForeColor = System.Drawing.Color.Red;
            this.label76.Location = new System.Drawing.Point(7, 1);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(247, 26);
            this.label76.TabIndex = 55;
            this.label76.Text = "VACCINATION CARD";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.Transparent;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.ForeColor = System.Drawing.Color.Blue;
            this.label77.Location = new System.Drawing.Point(251, 5);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(312, 17);
            this.label77.TabIndex = 59;
            this.label77.Text = "(Immunization Schedule for Healthy Baby)";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClose.Image = global::PMSApp.Properties.Resources.Close_16x16;
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(144, 525);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(59, 25);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "Close";
            this.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClear.Image = global::PMSApp.Properties.Resources.Cleaner_16x16;
            this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.Location = new System.Drawing.Point(74, 525);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(59, 25);
            this.btnClear.TabIndex = 12;
            this.btnClear.Text = "Clear";
            this.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(10, 525);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(59, 25);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEmail
            // 
            this.btnEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEmail.Enabled = false;
            this.btnEmail.Image = global::PMSApp.Properties.Resources.email_16;
            this.btnEmail.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnEmail.Location = new System.Drawing.Point(731, 525);
            this.btnEmail.Name = "btnEmail";
            this.btnEmail.Size = new System.Drawing.Size(59, 25);
            this.btnEmail.TabIndex = 30;
            this.btnEmail.Text = "Mail";
            this.btnEmail.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEmail.UseVisualStyleBackColor = true;
            this.btnEmail.Click += new System.EventHandler(this.btnEmail_Click);
            // 
            // btnClear2
            // 
            this.btnClear2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClear2.Image = global::PMSApp.Properties.Resources.Cleaner_16x16;
            this.btnClear2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear2.Location = new System.Drawing.Point(792, 524);
            this.btnClear2.Name = "btnClear2";
            this.btnClear2.Size = new System.Drawing.Size(59, 25);
            this.btnClear2.TabIndex = 31;
            this.btnClear2.Text = "Clear";
            this.btnClear2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear2.UseVisualStyleBackColor = true;
            this.btnClear2.Click += new System.EventHandler(this.btnClear2_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.Enabled = false;
            this.btnDelete.Image = global::PMSApp.Properties.Resources.Delete_16x16;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnDelete.Location = new System.Drawing.Point(664, 525);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(62, 25);
            this.btnDelete.TabIndex = 29;
            this.btnDelete.Text = "Delete";
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEdit.Enabled = false;
            this.btnEdit.Image = global::PMSApp.Properties.Resources.Edit20x20;
            this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.Location = new System.Drawing.Point(536, 525);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(59, 25);
            this.btnEdit.TabIndex = 27;
            this.btnEdit.Text = "Edit";
            this.btnEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnOpen.Enabled = false;
            this.btnOpen.Image = ((System.Drawing.Image)(resources.GetObject("btnOpen.Image")));
            this.btnOpen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOpen.Location = new System.Drawing.Point(468, 525);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(59, 25);
            this.btnOpen.TabIndex = 26;
            this.btnOpen.Text = "Open";
            this.btnOpen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPrint.Enabled = false;
            this.btnPrint.Image = global::PMSApp.Properties.Resources.print18;
            this.btnPrint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPrint.Location = new System.Drawing.Point(600, 525);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(59, 25);
            this.btnPrint.TabIndex = 28;
            this.btnPrint.Text = "Print";
            this.btnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.ForeColor = System.Drawing.Color.Red;
            this.lblCount.Location = new System.Drawing.Point(465, 65);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(60, 15);
            this.lblCount.TabIndex = 69;
            this.lblCount.Text = "lblCount";
            // 
            // frmVaccinationCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(852, 551);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEmail);
            this.Controls.Add(this.btnClear2);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.label77);
            this.Controls.Add(this.grbSearch);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgPatients);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "frmVaccinationCard";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PMS :: Vaccination Card";
            this.Load += new System.EventHandler(this.frmVaccinationCard_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.grbTab1.ResumeLayout(false);
            this.grbTab1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.grbTab2.ResumeLayout(false);
            this.grbTab2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.grbTab3.ResumeLayout(false);
            this.grbTab3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.grbTab4.ResumeLayout(false);
            this.grbTab4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgPatients)).EndInit();
            this.grbSearch.ResumeLayout(false);
            this.grbSearch.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblCont;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.ComboBox cmbSex;
        private System.Windows.Forms.Label lblSex;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.Label lblPN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblKgs;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMName;
        internal System.Windows.Forms.DateTimePicker dpDOB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox grbTab1;
        internal System.Windows.Forms.DateTimePicker dpOPV3G;
        internal System.Windows.Forms.DateTimePicker dpOPV3D;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        internal System.Windows.Forms.DateTimePicker dpDPT2G;
        internal System.Windows.Forms.DateTimePicker dpDPT2D;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        internal System.Windows.Forms.DateTimePicker dpPCV1Given;
        internal System.Windows.Forms.DateTimePicker dpPCV1Due;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        internal System.Windows.Forms.DateTimePicker dpHB2Given;
        internal System.Windows.Forms.DateTimePicker dpHB2Due;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        internal System.Windows.Forms.DateTimePicker dpDPT1Given;
        internal System.Windows.Forms.DateTimePicker dpDPT1Due;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        internal System.Windows.Forms.DateTimePicker dpOPV2Given;
        internal System.Windows.Forms.DateTimePicker dpOPV2Due;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        internal System.Windows.Forms.DateTimePicker dpOPV1Given;
        internal System.Windows.Forms.DateTimePicker dpOPV1Due;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        internal System.Windows.Forms.DateTimePicker dpHB1Given;
        internal System.Windows.Forms.DateTimePicker dpHB1Due;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        internal System.Windows.Forms.DateTimePicker dpBGCGiven;
        internal System.Windows.Forms.DateTimePicker dpBGCDue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox grbTab2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox grbTab3;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.DataGridView dgPatients;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label75;
        internal System.Windows.Forms.GroupBox grbSearch;
        internal System.Windows.Forms.Button btnSearch;
        internal System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        internal System.Windows.Forms.Button btnClose;
        internal System.Windows.Forms.Button btnClear;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Button btnEmail;
        internal System.Windows.Forms.Button btnClear2;
        internal System.Windows.Forms.Button btnDelete;
        internal System.Windows.Forms.Button btnEdit;
        internal System.Windows.Forms.Button btnOpen;
        internal System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.DataGridViewTextBoxColumn ChildName;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilePath;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.CheckBox chkGivenOn1;
        private System.Windows.Forms.ImageList imageList1;
        internal System.Windows.Forms.DateTimePicker dpRotarix1G;
        internal System.Windows.Forms.DateTimePicker dpRotarix1D;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        internal System.Windows.Forms.DateTimePicker dpHIB1Given;
        internal System.Windows.Forms.DateTimePicker dpHIB1Due;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.CheckBox chkOPV3;
        private System.Windows.Forms.CheckBox chkDPT2;
        private System.Windows.Forms.CheckBox chkRotarix1;
        private System.Windows.Forms.CheckBox chkPCV1;
        private System.Windows.Forms.CheckBox chkHIB1;
        private System.Windows.Forms.CheckBox chkHB2;
        private System.Windows.Forms.CheckBox chkDPT1;
        private System.Windows.Forms.CheckBox chkOPV2;
        private System.Windows.Forms.CheckBox chkOPV1;
        private System.Windows.Forms.CheckBox chkHB1;
        private System.Windows.Forms.CheckBox chkBCG;
        private System.Windows.Forms.CheckBox chkPCVBooster;
        private System.Windows.Forms.CheckBox chkVaricella1;
        private System.Windows.Forms.CheckBox chkMeasles;
        private System.Windows.Forms.CheckBox chkPCV3;
        private System.Windows.Forms.CheckBox chkRotarix2;
        private System.Windows.Forms.CheckBox chkPCV2;
        private System.Windows.Forms.CheckBox chkHIB3;
        private System.Windows.Forms.CheckBox chkHB3;
        private System.Windows.Forms.CheckBox chkDPT3;
        private System.Windows.Forms.CheckBox chkOPV4;
        private System.Windows.Forms.CheckBox chkHIB2;
        internal System.Windows.Forms.DateTimePicker dpMeaslesG;
        internal System.Windows.Forms.DateTimePicker dpMeaslesD;
        private System.Windows.Forms.Label label20;
        internal System.Windows.Forms.DateTimePicker dpRotarix2G;
        internal System.Windows.Forms.DateTimePicker dpRotarix2D;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox chkGivenOn2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label28;
        internal System.Windows.Forms.DateTimePicker dpPCVBoosterG;
        internal System.Windows.Forms.DateTimePicker dpPCVBoosterD;
        private System.Windows.Forms.Label label30;
        internal System.Windows.Forms.DateTimePicker dpVaricella1G;
        internal System.Windows.Forms.DateTimePicker dpVaricella1D;
        private System.Windows.Forms.Label label32;
        internal System.Windows.Forms.DateTimePicker dpPCV3G;
        internal System.Windows.Forms.DateTimePicker dpPCV3D;
        private System.Windows.Forms.Label label34;
        internal System.Windows.Forms.DateTimePicker dpPCV2G;
        internal System.Windows.Forms.DateTimePicker dpPCV2D;
        private System.Windows.Forms.Label label36;
        internal System.Windows.Forms.DateTimePicker dpHIB3G;
        internal System.Windows.Forms.DateTimePicker dpHIB3D;
        private System.Windows.Forms.Label label38;
        internal System.Windows.Forms.DateTimePicker dpHB3G;
        internal System.Windows.Forms.DateTimePicker dpHB3D;
        private System.Windows.Forms.Label label40;
        internal System.Windows.Forms.DateTimePicker dpDPT3G;
        internal System.Windows.Forms.DateTimePicker dpDPT3D;
        private System.Windows.Forms.Label label42;
        internal System.Windows.Forms.DateTimePicker dpOPV4G;
        internal System.Windows.Forms.DateTimePicker dpOPV4D;
        private System.Windows.Forms.Label label81;
        internal System.Windows.Forms.DateTimePicker dpHIB2G;
        internal System.Windows.Forms.DateTimePicker dpHIB2D;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.CheckBox chkMMR2;
        private System.Windows.Forms.CheckBox chkOPVBooster2;
        private System.Windows.Forms.CheckBox chkDPTBooster2;
        private System.Windows.Forms.CheckBox chkHA2;
        private System.Windows.Forms.CheckBox chkTyphoid;
        private System.Windows.Forms.CheckBox chkHA1;
        private System.Windows.Forms.CheckBox chkOPVBooster;
        private System.Windows.Forms.CheckBox chkHIBBooster;
        private System.Windows.Forms.CheckBox chkDPTBooster1;
        private System.Windows.Forms.CheckBox chkVaricella2;
        private System.Windows.Forms.CheckBox chkMMR;
        internal System.Windows.Forms.DateTimePicker dpDPTBooster2G;
        internal System.Windows.Forms.DateTimePicker dpDPTBooster2D;
        private System.Windows.Forms.Label label31;
        internal System.Windows.Forms.DateTimePicker dpTyphoidG;
        internal System.Windows.Forms.DateTimePicker dpTyphoidD;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.CheckBox chkGivenOn3;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label48;
        internal System.Windows.Forms.DateTimePicker dpMMR2G;
        internal System.Windows.Forms.DateTimePicker dpMMR2D;
        private System.Windows.Forms.Label label50;
        internal System.Windows.Forms.DateTimePicker dpOPVBooster2G;
        internal System.Windows.Forms.DateTimePicker dpOPVBooster2D;
        private System.Windows.Forms.Label label52;
        internal System.Windows.Forms.DateTimePicker dpHA2G;
        internal System.Windows.Forms.DateTimePicker dpHA2D;
        private System.Windows.Forms.Label label54;
        internal System.Windows.Forms.DateTimePicker dpHA1G;
        internal System.Windows.Forms.DateTimePicker dpHA1D;
        private System.Windows.Forms.Label label56;
        internal System.Windows.Forms.DateTimePicker dpOPVBoosterG;
        internal System.Windows.Forms.DateTimePicker dpOPVBoosterD;
        private System.Windows.Forms.Label label58;
        internal System.Windows.Forms.DateTimePicker dpHIBBoosterG;
        internal System.Windows.Forms.DateTimePicker dpHIBBoosterD;
        private System.Windows.Forms.Label label60;
        internal System.Windows.Forms.DateTimePicker dpDPTBooster1G;
        internal System.Windows.Forms.DateTimePicker dpDPTBooster1D;
        private System.Windows.Forms.Label label62;
        internal System.Windows.Forms.DateTimePicker dpVaricella2G;
        internal System.Windows.Forms.DateTimePicker dpVaricella2D;
        private System.Windows.Forms.Label label68;
        internal System.Windows.Forms.DateTimePicker dpMMRG;
        internal System.Windows.Forms.DateTimePicker dpMMRD;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.GroupBox grbTab4;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.CheckBox chkTBooster2;
        private System.Windows.Forms.CheckBox chkTyphoid5;
        private System.Windows.Forms.CheckBox chkTyphoid4;
        private System.Windows.Forms.CheckBox chkTBooster1;
        private System.Windows.Forms.CheckBox chkTyphoid3;
        private System.Windows.Forms.CheckBox chkTyphoid2;
        private System.Windows.Forms.CheckBox chkHBB;
        private System.Windows.Forms.CheckBox chkVaricellaBooster;
        private System.Windows.Forms.Label label72;
        internal System.Windows.Forms.DateTimePicker dpTyphoid5G;
        internal System.Windows.Forms.DateTimePicker dpTyphoid5D;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.CheckBox chkGivenOn4;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label93;
        internal System.Windows.Forms.DateTimePicker dpTBooster2G;
        internal System.Windows.Forms.DateTimePicker dpTBooster2D;
        private System.Windows.Forms.Label label96;
        internal System.Windows.Forms.DateTimePicker dpTyphoid4G;
        internal System.Windows.Forms.DateTimePicker dpTyphoid4D;
        private System.Windows.Forms.Label label97;
        internal System.Windows.Forms.DateTimePicker dpTBooster1G;
        internal System.Windows.Forms.DateTimePicker dpTBooster1D;
        private System.Windows.Forms.Label label98;
        internal System.Windows.Forms.DateTimePicker dpTyphoid3G;
        internal System.Windows.Forms.DateTimePicker dpTyphoid3D;
        private System.Windows.Forms.Label label99;
        internal System.Windows.Forms.DateTimePicker dpTyphoid2G;
        internal System.Windows.Forms.DateTimePicker dpTyphoid2D;
        private System.Windows.Forms.Label label100;
        internal System.Windows.Forms.DateTimePicker dpHBBG;
        internal System.Windows.Forms.DateTimePicker dpHBBD;
        private System.Windows.Forms.Label label101;
        internal System.Windows.Forms.DateTimePicker dpVaricellaBoosterG;
        internal System.Windows.Forms.DateTimePicker dpVaricellaBoosterD;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox grbTab5;
        private System.Windows.Forms.Label label94;
    }
}