﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace PMSApp
{
    public static class EmailNotification
    {
        public static void eMailNotification(string strPatientName, string strToMail, string strFilePath)
        {
            try
            {
                string strFromMail = System.Configuration.ConfigurationManager.AppSettings["FROMMAIL"].ToString();
                string strPwd = System.Configuration.ConfigurationManager.AppSettings["EMAILPASSWORD"].ToString();
                string strSMTPPort = System.Configuration.ConfigurationManager.AppSettings["SMTPPORT"].ToString();
                string strSMTPHost = System.Configuration.ConfigurationManager.AppSettings["SMTPHOST"].ToString();

                //WriteLog("Sending email.......");


                string mailBody = "";
                mailBody += "<html><head></head>";
                mailBody += "<body bgcolor='#EEE8D6' text='#848484'>";
                mailBody += "<div style='background: #EEE8D6;'><br />";
                mailBody += "<table style='font-family: arial, helvetica, sans-serif; font-size: 12px; color: #848484; text-align: left; width: 650px;' border='0' cellspacing='0' cellpadding='0' align='center'>";
                mailBody += "<tbody>";
                mailBody += "<tr><td style='color: #ffffff;' height='120' align='center' bgcolor='#233E60'>";
                mailBody += "<table style='font-family: arial, helvetica, sans-serif; font-size: 14px; color: #e9eaed; text-align: left; line-height: 30px; width: 600px;' border='0' cellspacing='0' cellpadding='0'>";
                mailBody += "<tbody><tr><td style='color: #fff;' align='left'><span style='font-size: 34px;'>Sri Sai Kalpana Clinic</span><br />";
                mailBody += "</tr></tbody></table></td></tr>";
                mailBody += "<tr><td bgcolor='#FFFFFF'>";
                mailBody += "<table style='font-family: arial, helvetica, sans-serif; font-size: 14px; color: #848484; text-align: left; line-height: 30px; width: 650px;' border='0' cellspacing='0' cellpadding='0'>";
                mailBody += "<tbody><tr><td width='25'></td>";
                mailBody += "<td><strong>Dear " + strPatientName + ",</strong><br />";
                mailBody += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please find your regular health checkup details at Sri Sai Kalpana Clinic with Dr.Venkata Ramana Arella as attached.</td>";
                mailBody += "<td width='25'></td>";
                mailBody += "<td width='232' height='235'>";
                mailBody += "<img src='cid:PMSEmail' alt='Image' width='232' height='235' /></td>";
                mailBody += "</tr></tbody></table></td></tr>";
                mailBody += "<tr><td style='font-size: 0px;' height='3'></td></tr>";
                mailBody += "<tr><td align='center' valign='top' bgcolor='#FFFFFF'>";
                mailBody += "<table style='font-family: arial, helvetica, sans-serif; font-size: 14px; color: #848484; text-align: left; width: 600px;' border='0' cellspacing='0' cellpadding='0'>";
                mailBody += "<tbody><tr><td colspan='5' height='30'></td></tr>";
                mailBody += "<tr><td width='180' height='36' align='center' valign='middle' bgcolor='#E9EAED'>";
                mailBody += "<table style='font-family: arial, helvetica, sans-serif; font-size: 14px; color: #848484; text-align: left;' border='0' cellspacing='0' cellpadding='0'>";
                mailBody += "<tbody><tr><td style='padding-left: 15px;'>Regards,<strong>Sri Sai Kalpana Clinic</strong></td></tr></tbody>";
                mailBody += "</table></td><td></td></tr>";
                mailBody += "<tr><td colspan='5' height='30'> </td></tr>";
                mailBody += "</tbody></table></td></tr>";
                mailBody += "</tbody></table><br/></div>";
                mailBody += "</body></html>";

                //string MailBody = "";
                //MailBody = "Dear  " + strPatientName + ",<br/>";
                //MailBody += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                ////MailBody += "<b style='word-spacing:704px;'";
                //MailBody += "Please find your regular health checkup details at Sri Sai Kalpana Clinic with Dr.Venkata Ramana Arella as attached.<br/><br/>";
                //MailBody += "Should you require any further assistance please contact the Dr.Venkata Ramana Arella.";
                //MailBody += "<br/><br/>Regards,<br/>Sri Sai Kalpana Clinic.";


                using (MailMessage msg = new MailMessage())
                {
                    msg.From = new MailAddress(strFromMail);
                    msg.To.Add(new MailAddress(strToMail));
                    msg.Priority = MailPriority.High;
                    msg.Subject = "Sri Sai Kalpana Clinic";

                    msg.IsBodyHtml = true;
                    // Create HTML view
                    AlternateView htmlView = AlternateView.CreateAlternateViewFromString(mailBody.ToString(), new System.Net.Mime.ContentType("text/html"));
                    //// Set ContentId property.
                    LinkedResource _pmsImg = new LinkedResource(System.AppDomain.CurrentDomain.BaseDirectory + @"\Images\PMSEmail.png");
                    _pmsImg.ContentId = "PMSEmail"; //Value of ContentId property must be the same as the src attribute of image tag in email body.  
                    _pmsImg.ContentType.Name = "Happy Health.jpg";
                    htmlView.LinkedResources.Add(_pmsImg);
                    msg.AlternateViews.Add(htmlView);

                    msg.Body = mailBody;
                    msg.Attachments.Clear();
                    msg.Attachments.Add(new Attachment(strFilePath));

                    msg.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

                    using (SmtpClient sc = new SmtpClient())
                    {
                        sc.Host = strSMTPHost;
                        sc.Port = Convert.ToInt16(strSMTPPort);
                        sc.UseDefaultCredentials = false;
                        sc.Timeout = 3000000;
                        sc.Credentials = new System.Net.NetworkCredential(strFromMail, strPwd);
                        if (strSMTPHost.ToLower().Contains("gmail"))
                            sc.EnableSsl = true;

                        sc.Send(msg);
                    }

                    GC.Collect();

                    //WriteLog("Mail Successfully Sent on:" + DateTime.Now.ToString());

                    //System.Threading.Thread.Sleep(100);
                }
            }
            catch (Exception ex)
            {
                WriteLog("eMailNotification()-->" + ex.Message);
                //System.Threading.Thread.Sleep(100);
            }
        }

        private static void WriteLog(string strError)
        {
            try
            {
                string AppPath = AppDomain.CurrentDomain.BaseDirectory;
                string strLog = @"LOG\";
                string strFilePath = AppPath + strLog;

                if (!(Directory.Exists(strFilePath)))
                {
                    Directory.CreateDirectory(strFilePath);
                }
                string fn = string.Format("{0}{1}.txt", strFilePath, DateTime.Now.ToString("ddMMyyyy"));
                FileStream fs = new FileStream(fn, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);

                StreamWriter writer = new StreamWriter(fs);
                //writer.Write("[ " + DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString() + " ]");
                //writer.WriteLine(strError);
                //   writer.WriteLine("--------------------------------------------------------------------------");
                writer.WriteLine(string.Format("[ {0} ] {1}", DateTime.Now.ToString("HH:mm:ss"), strError));
                writer.Close();
                fs.Close();
            }
            finally
            {
                //nothing
            }
        }

    }
}
