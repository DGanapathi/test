﻿namespace PMSApp
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            this.gbLogin = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblPwd = new System.Windows.Forms.Label();
            this.txtPwd = new System.Windows.Forms.TextBox();
            this.pbHeader = new System.Windows.Forms.PictureBox();
            this.pbLocImg = new System.Windows.Forms.PictureBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.pbUsersImg = new System.Windows.Forms.PictureBox();
            this.Ttip = new System.Windows.Forms.ToolTip(this.components);
            this.chkRemember = new System.Windows.Forms.CheckBox();
            this.gbLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLocImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsersImg)).BeginInit();
            this.SuspendLayout();
            // 
            // gbLogin
            // 
            this.gbLogin.Controls.Add(this.chkRemember);
            this.gbLogin.Controls.Add(this.btnCancel);
            this.gbLogin.Controls.Add(this.btnLogin);
            this.gbLogin.Controls.Add(this.txtUserID);
            this.gbLogin.Controls.Add(this.lblUserID);
            this.gbLogin.Controls.Add(this.lblPwd);
            this.gbLogin.Controls.Add(this.txtPwd);
            this.gbLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbLogin.Location = new System.Drawing.Point(142, 79);
            this.gbLogin.Name = "gbLogin";
            this.gbLogin.Size = new System.Drawing.Size(272, 165);
            this.gbLogin.TabIndex = 1;
            this.gbLogin.TabStop = false;
            this.gbLogin.Text = "Login";
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Image = global::PMSApp.Properties.Resources.C_1;
            this.btnCancel.Location = new System.Drawing.Point(182, 129);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(80, 30);
            this.btnCancel.TabIndex = 4;
            this.Ttip.SetToolTip(this.btnCancel, "Close");
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            this.btnCancel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnCancel_MouseDown);
            this.btnCancel.MouseLeave += new System.EventHandler(this.btnCancel_MouseLeave);
            this.btnCancel.MouseHover += new System.EventHandler(this.btnCancel_MouseHover);
            // 
            // txtUserID
            // 
            this.txtUserID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserID.Location = new System.Drawing.Point(86, 44);
            this.txtUserID.MaxLength = 50;
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(171, 20);
            this.txtUserID.TabIndex = 0;
            this.Ttip.SetToolTip(this.txtUserID, "Enter your user id here");
            this.txtUserID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtUserID_KeyDown);
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserID.Location = new System.Drawing.Point(4, 48);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(60, 16);
            this.lblUserID.TabIndex = 2;
            this.lblUserID.Text = "User ID";
            // 
            // lblPwd
            // 
            this.lblPwd.AutoSize = true;
            this.lblPwd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPwd.Location = new System.Drawing.Point(4, 83);
            this.lblPwd.Name = "lblPwd";
            this.lblPwd.Size = new System.Drawing.Size(76, 16);
            this.lblPwd.TabIndex = 4;
            this.lblPwd.Text = "Password";
            // 
            // txtPwd
            // 
            this.txtPwd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPwd.Location = new System.Drawing.Point(86, 79);
            this.txtPwd.MaxLength = 50;
            this.txtPwd.Name = "txtPwd";
            this.txtPwd.PasswordChar = '*';
            this.txtPwd.Size = new System.Drawing.Size(171, 20);
            this.txtPwd.TabIndex = 1;
            this.Ttip.SetToolTip(this.txtPwd, "Enter your password here");
            this.txtPwd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPwd_KeyDown);
            // 
            // pbHeader
            // 
            this.pbHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pbHeader.Image = global::PMSApp.Properties.Resources.topheader;
            this.pbHeader.Location = new System.Drawing.Point(0, 0);
            this.pbHeader.Name = "pbHeader";
            this.pbHeader.Size = new System.Drawing.Size(419, 50);
            this.pbHeader.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbHeader.TabIndex = 3;
            this.pbHeader.TabStop = false;
            // 
            // pbLocImg
            // 
            this.pbLocImg.BackColor = System.Drawing.Color.Transparent;
            this.pbLocImg.Image = global::PMSApp.Properties.Resources.images;
            this.pbLocImg.Location = new System.Drawing.Point(0, 92);
            this.pbLocImg.Name = "pbLocImg";
            this.pbLocImg.Size = new System.Drawing.Size(140, 145);
            this.pbLocImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLocImg.TabIndex = 2;
            this.pbLocImg.TabStop = false;
            // 
            // btnLogin
            // 
            this.btnLogin.Image = global::PMSApp.Properties.Resources.L_1;
            this.btnLogin.Location = new System.Drawing.Point(86, 129);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(80, 30);
            this.btnLogin.TabIndex = 3;
            this.Ttip.SetToolTip(this.btnLogin, "Click here to login");
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            this.btnLogin.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnLogin_MouseDown);
            this.btnLogin.MouseLeave += new System.EventHandler(this.btnLogin_MouseLeave);
            this.btnLogin.MouseHover += new System.EventHandler(this.btnLogin_MouseHover);
            // 
            // pbUsersImg
            // 
            this.pbUsersImg.BackColor = System.Drawing.Color.Transparent;
            this.pbUsersImg.Image = global::PMSApp.Properties.Resources.user_access_512;
            this.pbUsersImg.Location = new System.Drawing.Point(324, 52);
            this.pbUsersImg.Name = "pbUsersImg";
            this.pbUsersImg.Size = new System.Drawing.Size(60, 52);
            this.pbUsersImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbUsersImg.TabIndex = 10;
            this.pbUsersImg.TabStop = false;
            // 
            // Ttip
            // 
            this.Ttip.AutomaticDelay = 100;
            this.Ttip.AutoPopDelay = 2000;
            this.Ttip.ForeColor = System.Drawing.Color.Maroon;
            this.Ttip.InitialDelay = 100;
            this.Ttip.IsBalloon = true;
            this.Ttip.ReshowDelay = 20;
            // 
            // chkRemember
            // 
            this.chkRemember.AutoSize = true;
            this.chkRemember.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRemember.Location = new System.Drawing.Point(86, 103);
            this.chkRemember.Name = "chkRemember";
            this.chkRemember.Size = new System.Drawing.Size(154, 19);
            this.chkRemember.TabIndex = 2;
            this.chkRemember.Text = "Remember Credentials";
            this.chkRemember.UseVisualStyleBackColor = true;
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(419, 269);
            this.Controls.Add(this.pbUsersImg);
            this.Controls.Add(this.pbHeader);
            this.Controls.Add(this.pbLocImg);
            this.Controls.Add(this.gbLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GPApps :: PMS Login";
            this.Load += new System.EventHandler(this.frmLogin_Load);
            this.gbLogin.ResumeLayout(false);
            this.gbLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHeader)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLocImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsersImg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox gbLogin;
        internal System.Windows.Forms.Button btnCancel;
        internal System.Windows.Forms.Button btnLogin;
        internal System.Windows.Forms.TextBox txtUserID;
        internal System.Windows.Forms.Label lblUserID;
        internal System.Windows.Forms.Label lblPwd;
        internal System.Windows.Forms.TextBox txtPwd;
        internal System.Windows.Forms.PictureBox pbLocImg;
        internal System.Windows.Forms.PictureBox pbHeader;
        internal System.Windows.Forms.PictureBox pbUsersImg;
        internal System.Windows.Forms.ToolTip Ttip;
        private System.Windows.Forms.CheckBox chkRemember;
    }
}