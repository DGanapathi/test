﻿using Spire.Doc;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmMCertificate : Form
    {
        string UncPath = Directory.GetParent(System.Configuration.ConfigurationManager.AppSettings["FilesPath"]).ToString() + Path.DirectorySeparatorChar + "PatientMedicalCerts";

        public frmMCertificate()
        {
            InitializeComponent();
        }
        //word document object
        Document document = null;

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                string pname = txtPName.Text.Trim();
                string reason = txtReason.Text.Trim();
                string dayOWeeks = txtDays.Text.Trim();
                string issueDate = dtpIssueDt.Text.Trim();
                if (string.IsNullOrEmpty(pname) || string.IsNullOrEmpty(reason) || string.IsNullOrEmpty(dayOWeeks))
                {
                    MessageBox.Show("Please enter patient name, reason and rest days/weeks.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if(chkResume.Checked && dtpSince.Value >= dtpFrom.Value)
                {
                    MessageBox.Show("Duty/attendance date should be greater than sick date.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                //initialize word object
                document = new Document();
                //close if the template is already opened
                if (GloabalFunctions.closeOpenedWord(GloabalFunctions.MCTemplatePath))
                    System.Threading.Thread.Sleep(100);
                document.LoadFromFile(GloabalFunctions.MCTemplatePath);
                //get strings to replace
                Dictionary<string, string> dictReplace = GetReplaceDictionary();
                //Replace text
                foreach (KeyValuePair<string, string> kvp in dictReplace)
                {
                    document.Replace(kvp.Key, kvp.Value, true, true);
                }
                //Save doc file.

                //UncPath = Directory.GetParent(UncPath).ToString();

                if (!Directory.Exists(UncPath))
                    Directory.CreateDirectory(UncPath);

                string docxPath = UncPath + "\\" + pname + "_" + dtpIssueDt.Value.ToString("ddMMyyyy") + ".docx";
                if (File.Exists(docxPath))
                {
                    MessageBox.Show("Medical Certificate already exists with name: \r\n" + docxPath, "GPApps :: PMS", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    return;
                }


                document.SaveToFile(docxPath, FileFormat.Docx);
                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    string pdfPath = docxPath.Replace(".docx", ".pdf");
                //    //Convert to PDF
                //    document.SaveToFile(pdfPath, FileFormat.PDF);
                //}
                document.Close();
                                
                if (MessageBox.Show("Medical Certificate saved successfully. \r\n Do you want to give print?.", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    GloabalFunctions.printFile(docxPath);

                //if (!string.IsNullOrEmpty(strEmail) && GloabalFunctions.isValidMail(strEmail) && emailNotification.ToLower() == "yes")
                //{
                //    EmailNotification.eMailNotification(strPName, strEmail, pdfPath);
                //    //System.Threading.Thread.Sleep(100);
                //}

                clearControls();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnBillPrint_Click()-->" + ex.Message);
            }
        }

        Dictionary<string, string> GetReplaceDictionary()
        {
            try
            {
                string pname = txtPName.Text.Trim();
                string reason = txtReason.Text.Trim();
                string dayOrWeeks = txtDays.Text.Trim();
                string issueDate = dtpIssueDt.Text.Trim();

                string reson = txtReason.Text.Trim();
                string sinceDate = dtpSince.Text.Trim();
                string fitMsg = "He / She has been examined by me and is found to be fit to resume normal duties / attendance from";
                string fromDate = dtpFrom.Text.Trim() + ".";
                if(!chkResume.Checked)
                {
                    fitMsg = "";
                    fromDate = "";
                }
                Dictionary<string, string> replaceDict = new Dictionary<string, string>();

                replaceDict.Add("#date#", issueDate);
                replaceDict.Add("#pname#", pname);
                replaceDict.Add("#sufReason#", reson);

                replaceDict.Add("#sdt#", sinceDate);
                replaceDict.Add("#days#", dayOrWeeks);
                replaceDict.Add("#fitmsg#", fitMsg);
                replaceDict.Add("#fdt#", fromDate);
                
                return replaceDict;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("frmMCert_GetReplaceDictionary()-->" + ex.Message);
                return null;
            }
        }


        private void clearControls()
        {
            txtPName.Text = "";
            txtReason.Text = "";
            txtDays.Text = "";
            dtpIssueDt.Text= DateTime.Now.Date.ToString();
            dtpSince.Text= DateTime.Now.Date.ToString();
            dtpFrom.Text= DateTime.Now.Date.ToString();
        }
        private void btnClear2_Click(object sender, EventArgs e)
        {
            clearControls();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        private void frmMCertificate_Load(object sender, EventArgs e)
        {
            txtPName.Text = !string.IsNullOrEmpty(frmHome.patientNameForMail) ? frmHome.patientNameForMail.ToUpper() : string.Empty;
        }

        private void chkResume_CheckedChanged(object sender, EventArgs e)
        {
            if (chkResume.Checked)
            {
                dtpFrom.Enabled = true;
                label6.Enabled = true;
                label7.Enabled = true;
            }
            else
            {
                dtpFrom.Enabled = false;
                label6.Enabled = false;
                label7.Enabled = false;
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                GloabalFunctions.BrowseFileToPrint(UncPath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("MC-Browse_Click()-->" + ex.Message);
            }
        }
    }
}
