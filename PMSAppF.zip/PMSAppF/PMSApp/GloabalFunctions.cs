﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace PMSApp
{
  public static class GloabalFunctions
    {
        //Template file path
        public static string PMSTemplatePath = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\PMSTemplate.docx";
        public static string PMSTemplatePathA4 = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\PMSTemplateA4.docx";
        public static string RevisitTemplatePath = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\RevisitTemplate.docx";
        public static string BlankTemplatePath = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\PMSTemplateBlank.docx";
        public static string InvestigationsTemplatePath = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\InvestigationsTemplate.docx";
        public static string BillTemplatePath = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\BillTemplate.docx";
        public static string MCTemplatePath = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\MCTemplate.docx";
        public static string MFCTemplatePath = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\MFCTemplate.docx";
        public static string VaccinationCardTemplatePath = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\VaccinationCard.docx";
        public static string LabReportsTemplatePath = Application.StartupPath + Path.DirectorySeparatorChar + @"\Templates\LabReportsTemplate.docx";
        
        public static string AddressesExcelPath = Application.StartupPath + Path.DirectorySeparatorChar + @"\ExelFiles\Addresses.xlsx";
        public static string ClinicalDiagnosisExcelPath = Application.StartupPath + Path.DirectorySeparatorChar + @"\ExelFiles\ClinicalDiagnosis.xlsx";
        public static string EmailsExcelPath = Application.StartupPath + Path.DirectorySeparatorChar + @"\ExelFiles\Emails.xlsx";
        public static string InvestigationsExcelPath = Application.StartupPath + Path.DirectorySeparatorChar + @"\ExelFiles\Investigations.xlsx";
        public static string MedicineListExcelPath = Application.StartupPath + Path.DirectorySeparatorChar + @"\ExelFiles\MedicineList.xlsx";
        public static string OccupationsExcelPath = Application.StartupPath + Path.DirectorySeparatorChar + @"\ExelFiles\Occupations.xlsx";
        public static string SymptomsExcelPath = Application.StartupPath + Path.DirectorySeparatorChar + @"\ExelFiles\Symptoms.xlsx";

        public static void WriteLog(string strError)
        {
            try
            {
                string AppPath = AppDomain.CurrentDomain.BaseDirectory;
                string strLog = @"LOG\";
                string strFilePath = AppPath + strLog;

                if (!(Directory.Exists(strFilePath)))
                {
                    Directory.CreateDirectory(strFilePath);
                }
                string fn = string.Format("{0}{1}.txt", strFilePath, DateTime.Now.ToString("ddMMyyyy"));
                FileStream fs = new FileStream(fn, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);

                StreamWriter writer = new StreamWriter(fs);
                //writer.Write("[ " + DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString() + " ]");
                //writer.WriteLine(strError);
                //   writer.WriteLine("--------------------------------------------------------------------------");
                writer.WriteLine(string.Format("[ {0} ] {1}", DateTime.Now.ToString("HH:mm:ss"), strError));
                writer.Close();
                fs.Close();
            }
            finally
            {
                //nothing
            }
        }

        public static bool closeOpenedWord(string fPath)
        {
            bool retVal = false;
            FileStream fs = null;
            try
            {
                if (File.Exists(fPath))
                    fs = new FileStream(fPath, FileMode.Open, FileAccess.Read);
            }
            catch (Exception ex)
            {
                retVal = true;
                string fileName = Path.GetFileNameWithoutExtension(fPath).ToUpper().Trim();
                Process[] oProcess = Process.GetProcessesByName("WINWORD");
                foreach (Process item in oProcess)
                {
                    if (item.MainWindowTitle.ToUpper().Contains(fileName))
                        item.Kill();
                }
                //WriteLog("closeOpenWord()-->" + ex.Message);
            }
            finally
            {
                if (fs != null)
                    fs.Close();
            }
            return retVal;
        }

        public static bool closeOpenedExcel(string fPath)
        {
            bool retVal = false;
            FileStream fs = null;
            try
            {
                fs = new FileStream(fPath, FileMode.Open, FileAccess.Read);
            }
            catch (Exception ex)
            {
                retVal = true;
                string fileName = Path.GetFileNameWithoutExtension(fPath).ToUpper().Trim();
                Process[] oProcess = Process.GetProcessesByName("EXCEL");
                foreach (Process item in oProcess)
                {
                    if (item.MainWindowTitle.ToUpper().Contains(fileName))
                        item.Kill();
                }
                //WriteLog("closeOpenedExcel()-->" + ex.Message);
            }
            finally
            {
                if (fs != null)
                    fs.Close();
            }
            return retVal;
        }

        public static void ToViewFile(string fileName)
        {
            try
            {
                System.Diagnostics.Process.Start(fileName);
            }
            catch (Exception ex)
            {
                WriteLog("ToViewFile()-->" + ex.Message);
            }
        }

        public static void printFile(string strFilePath)
        {
            Process p = null;
            try
            {
                //Using below code we can print any document
                ProcessStartInfo info = new ProcessStartInfo(strFilePath);
                info.Verb = "Print";
                info.CreateNoWindow = true;
                info.WindowStyle = ProcessWindowStyle.Hidden;
                p = new Process();
                p.StartInfo = info;
                p.Start();

                //p.WaitForInputIdle();
                //System.Threading.Thread.Sleep(3000);
                //p.WaitForExit();
                //if (false == p.CloseMainWindow())
                //{
                //    p.Kill();
                //}

                do
                {
                    if (!p.HasExited)
                    {
                        // Refresh the current process property values.
                        p.Refresh();
                    }

                } while (!p.WaitForExit(1000));
            }
            catch (Exception ex)
            {
                WriteLog("printFile()-->" + ex.Message);
            }
            finally
            {
                if (p != null)
                {
                    p.Close();
                }
            }
        }

        public static bool isValidMail(string strMail)
        {
            bool retVal = false;
            try
            {
                //Regex rEmail = new Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9] [\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
                Regex rEmail = new Regex(@"^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,3})$");
                if (strMail.Length > 0)
                {
                    if (rEmail.IsMatch(strMail))
                        retVal = true;
                }
            }
            catch (Exception ex)
            {
                WriteLog("isValidMail()-->" + ex.Message);
            }
            return retVal;
        }

        public static bool BrowseFileToPrint(string UncPath)
        {
            try
            {
                UncPath = UncPath.Replace("\\\\", "\\");
                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                if (!Directory.Exists(UncPath))
                    Directory.CreateDirectory(UncPath);
                openFileDialog1.InitialDirectory = UncPath;
                openFileDialog1.Title = "Browse file to print";
                openFileDialog1.CheckFileExists = true;
                openFileDialog1.CheckPathExists = true;
                openFileDialog1.DefaultExt = "docx";

                openFileDialog1.Filter = "Documests & PDFs |*.docx;*.doc;*.pdf";
                openFileDialog1.RestoreDirectory = true;
                openFileDialog1.ReadOnlyChecked = true;
                openFileDialog1.ShowReadOnly = true;
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog1.FileName;
                    printFile(filePath);
                }
            }
            catch (Exception ex)
            {
                WriteLog("browseFileToPrint()-->" + ex.Message);
            }
            return true;
        }
    }
}
