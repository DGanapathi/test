﻿using Spire.Doc;
using Spire.Doc.Documents;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmLabReports : Form
    {
        string UncPath = Directory.GetParent(System.Configuration.ConfigurationManager.AppSettings["FilesPath"]).ToString() + Path.DirectorySeparatorChar + "PatientLabReports";
        //word document object
        Document document = null;
        AutoCompleteStringCollection UnitsCollection = new AutoCompleteStringCollection();
        AutoCompleteStringCollection LabNamesCollection = new AutoCompleteStringCollection();

        public frmLabReports()
        {
            InitializeComponent();
            txtSearch.ForeColor = Color.LightGray;
            txtSearch.Text = "Enter Patient Name";
            this.txtSearch.Leave += new System.EventHandler(this.txtSearch_Leave);
            this.txtSearch.Enter += new System.EventHandler(this.txtSearch_Enter);

            txtValue.ForeColor = Color.LightGray;
            txtValue.Text = "Value";
            this.txtValue.Leave += new System.EventHandler(this.txtValue_Leave);
            this.txtValue.Enter += new System.EventHandler(this.txtValue_Enter);

            txtUnits.ForeColor = Color.LightGray;
            txtUnits.Text = "Units";
            this.txtUnits.Leave += new System.EventHandler(this.txtUnits_Leave);
            this.txtUnits.Enter += new System.EventHandler(this.txtUnits_Enter);


            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
        }
        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "Enter Patient Name";
                txtSearch.Font = new Font(txtSearch.Font, FontStyle.Italic);
                txtSearch.ForeColor = Color.Gray;
            }
        }

        private void txtSearch_Enter(object sender, EventArgs e)
        {
            if (txtSearch.Text == "Enter Patient Name")
            {
                txtSearch.Text = "";
                txtSearch.Font = new Font(txtSearch.Font, FontStyle.Regular);
                txtSearch.ForeColor = Color.Black;
            }
        }

        private void txtValue_Leave(object sender, EventArgs e)
        {
            if (txtValue.Text == "")
            {
                txtValue.Text = "Value";
                txtValue.Font = new Font(txtValue.Font, FontStyle.Italic);
                txtValue.ForeColor = Color.Gray;
            }
        }

        private void txtValue_Enter(object sender, EventArgs e)
        {
            if (txtValue.Text == "Value")
            {
                txtValue.Text = "";
                txtValue.Font = new Font(txtValue.Font, FontStyle.Regular);
                txtValue.ForeColor = Color.Black;
            }
        }
        private void txtUnits_Leave(object sender, EventArgs e)
        {
            if (txtUnits.Text == "")
            {
                txtUnits.Text = "Units";
                txtUnits.Font = new Font(txtUnits.Font, FontStyle.Italic);
                txtUnits.ForeColor = Color.Gray;
            }
        }

        private void txtUnits_Enter(object sender, EventArgs e)
        {
            if (txtUnits.Text == "Units")
            {
                txtUnits.Text = "";
                txtUnits.Font = new Font(txtUnits.Font, FontStyle.Regular);
                txtUnits.ForeColor = Color.Black;
            }
        }


        private AutoCompleteStringCollection getAutoCompleteCollection(string path)
        {
            AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            try
            {
                string connString = "";
                if (!File.Exists(path))
                {
                    GloabalFunctions.WriteLog("File not exists: " + path);
                    return null;
                }

                if (GloabalFunctions.closeOpenedExcel(path))
                    System.Threading.Thread.Sleep(100);
                string strFileType = Path.GetExtension(path).ToLower();
                string sheetName = "";
                string sheetName2 = "";
                string sheetName3 = "";
                if (strFileType.Trim() == ".xls")
                {
                    //connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=Excel 8.0;";
                }
                else if (strFileType.Trim() == ".xlsx")
                {
                    //connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
                    connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 12.0;";
                }

                //Get the name of the First Sheet.
                //using (OleDbConnection con = new OleDbConnection(connString))
                //{
                //    using (OleDbCommand cmd = new OleDbCommand())
                //    {
                //        cmd.Connection = con;
                //        con.Open();
                //        DataTable dtExcelSchema = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                //        sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                //        sheetName2 = dtExcelSchema.Rows[1]["TABLE_NAME"].ToString();
                //        sheetName3 = dtExcelSchema.Rows[2]["TABLE_NAME"].ToString();
                //        con.Close();
                //    }
                //}

                sheetName = "Investigations$";
                sheetName2 = "Units$";
                sheetName3 = "LabNames$";

                //Read Data from the First Sheet.
                using (OleDbConnection con = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmd = new OleDbCommand())
                    {
                        using (OleDbDataAdapter oda = new OleDbDataAdapter())
                        {
                            //string query = "SELECT [UserName],[Education],[Location] FROM [Sheet1$]";
                            DataTable dt = new DataTable();
                            cmd.CommandText = "SELECT * From [" + sheetName + "]";
                            cmd.Connection = con;
                            con.Open();
                            oda.SelectCommand = cmd;
                            oda.Fill(dt);
                            //DataSet ds = new DataSet();
                            //da.Fill(ds);
                            //con.Close();

                            if (dt != null && dt.Rows.Count > 0)
                            {
                                //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (dr[0] != DBNull.Value)
                                        MyCollection.Add(dr[0].ToString().Trim());
                                }
                            }

                            dt = new DataTable();
                            cmd.CommandText = "SELECT * From [" + sheetName2 + "]";
                            oda.SelectCommand = cmd;
                            oda.Fill(dt);
                            con.Close();

                            if (dt != null && dt.Rows.Count > 0)
                            {
                                //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (dr[0] != DBNull.Value)
                                        UnitsCollection.Add(dr[0].ToString().Trim());
                                }
                            }

                            dt = new DataTable();
                            cmd.CommandText = "SELECT * From [" + sheetName3 + "]";
                            oda.SelectCommand = cmd;
                            oda.Fill(dt);
                            con.Close();

                            if (dt != null && dt.Rows.Count > 0)
                            {
                                //AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (dr[0] != DBNull.Value)
                                        LabNamesCollection.Add(dr[0].ToString().Trim());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getAutoCompleteCollection()-->" + ex.Message);
                return null;
            }
            return MyCollection;
        }

        private void getRequiredInvestigations()
        {
            try
            {
                if (!File.Exists(GloabalFunctions.InvestigationsExcelPath))
                {
                    MessageBox.Show("Investigations list: " + Path.GetFileName(GloabalFunctions.InvestigationsExcelPath) + " not exists" + "\r\n" + "Please place Investigations list file.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (GloabalFunctions.closeOpenedExcel(GloabalFunctions.InvestigationsExcelPath))
                    System.Threading.Thread.Sleep(100);
                AutoCompleteStringCollection MyCollection = getAutoCompleteCollection(GloabalFunctions.InvestigationsExcelPath);
                if (MyCollection != null && MyCollection.Count > 0)
                {
                    txtInvReq.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtInvReq.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtInvReq.AutoCompleteCustomSource = MyCollection;
                }

                if (UnitsCollection != null && UnitsCollection.Count > 0)
                {
                    txtUnits.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtUnits.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtUnits.AutoCompleteCustomSource = UnitsCollection;
                }

                if (LabNamesCollection != null && LabNamesCollection.Count > 0)
                {
                    txtLabName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtLabName.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtLabName.AutoCompleteCustomSource = LabNamesCollection;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getRequiredInvestigations()-->" + ex.Message);
            }
        }

        private void getData(string searchOn, string searchText)
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("PatientName");
                dt.Columns.Add("FilePath");
                string myDir = UncPath + "\\" + searchOn;
                myDir=myDir.Replace("\\\\","\\");
                if (Directory.Exists(myDir) && (Directory.GetFiles(myDir, "*.doc", SearchOption.AllDirectories).Count() > 0 || Directory.GetFiles(myDir, "*.docx", SearchOption.AllDirectories).Count() > 0))
                {
                    List<string> lstFiles = Directory.GetFiles(myDir, "*.*", SearchOption.AllDirectories).Where(file => new string[] { ".doc", ".docx" }.Contains(Path.GetExtension(file))).ToList();

                    DataRow dr;

                    foreach (string strFile in lstFiles)
                    {
                        if (!string.IsNullOrEmpty(searchText))
                        {
                            if (!Path.GetFileNameWithoutExtension(strFile).ToLower().Contains(searchText.ToLower()))
                                continue;
                        }
                        if (File.GetAttributes(strFile).HasFlag(FileAttributes.Hidden))
                            continue;

                        dr = dt.NewRow();
                        dr["PatientName"] = Path.GetFileNameWithoutExtension(strFile);
                        dr["FilePath"] = strFile;
                        dt.Rows.Add(dr);
                    }
                    dt.CaseSensitive = false;
                    //DataRow[] dtrow;
                    //dtrow = dt.Select("PatientName LIKE  '%" + searchText + "%'");
                    //dgPatients.AutoGenerateColumns = false;

                    dgPatients.DataSource = dt;
                }
                else
                {
                    //dgPatients.DataSource = null;
                    dgPatients.DataSource = dt;
                }
                dgPatients.ClearSelection();

                btnDelete.Enabled = false;
                btnPrint.Enabled = false;
                btnOpen.Enabled = false;
                btnEdit.Enabled = false;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("getData()-->" + ex.Message);
            }
        }

        private void frmInvestigations_Load(object sender, EventArgs e)
        {
            txtPName.Text = !string.IsNullOrEmpty(frmHome.patientNameForMail) ? frmHome.patientNameForMail.ToUpper() : string.Empty;
            getRequiredInvestigations();
            cmbSex.SelectedIndex = 0;
            string mFolder = DateTime.Now.ToString("MMM") + "-" + DateTime.Now.Year.ToString("D4");
            if (!Directory.Exists(UncPath + "\\" + mFolder))
                Directory.CreateDirectory(UncPath + "\\" + mFolder);
            getData(mFolder, "");

            //DataTable dt = new DataTable();
            //dt.Columns.Add("PatientName");
            //dt.Columns.Add("Date");
            //dt.Columns.Add("FilePath");

            //DataRow dr = dt.NewRow();
            //dr["PatientName"] = "VENKATA RAMANA";
            //dr["Date"] = "20/12/2019";
            //dr["FilePath"] = @"D:/LabReports/Jan2018/test.docx";
            //dt.Rows.Add(dr);
            //dr = dt.NewRow();
            //dr["PatientName"] = "VENKATA RAMANA";
            //dr["Date"] = "20/12/2019";
            //dr["FilePath"] = @"D:/LabReports/Jan2018/test.docx";
            //dt.Rows.Add(dr);
            //dr = dt.NewRow();
            //dr["PatientName"] = "VENKATA RAMANA";
            //dr["Date"] = "20/12/2019";
            //dr["FilePath"] = @"D:/LabReports/Jan2018/test.docx";
            //dt.Rows.Add(dr);

            //dgPatients.DataSource = dt;

        }
        private void btnAddSymptom_Click(object sender, EventArgs e)
        {
            string strTxt = txtInvReq.Text.Trim();
            string bullet = "\u2022";
                        
            if (!string.IsNullOrEmpty(strTxt))
            {
                if (strTxt.Length == 1)
                    strTxt = char.ToUpper(strTxt[0]).ToString();
                else if (strTxt.Length > 1)
                    strTxt = char.ToUpper(strTxt[0]) + strTxt.Substring(1);

                string val = txtValue.Text.Trim();
                if (!string.IsNullOrEmpty(val) && val !="Value")
                {
                    int indx = strTxt.LastIndexOf(':');
                    if (indx>0)
                        strTxt = strTxt.Remove(indx, 1).Insert(indx, ": " + val + " ");
                    else
                        strTxt = strTxt + ": " + val;
                }

                string unit = txtUnits.Text.Trim();
                if (!string.IsNullOrEmpty(unit) && unit !="Units")
                {
                    strTxt = strTxt + " " + unit;
                }
                strTxt = bullet + " " + strTxt;
                txtData.AppendText(strTxt + Environment.NewLine);
                txtInvReq.Text = "";
                txtValue.Text = "Value";
                txtValue.Font = new Font(txtValue.Font, FontStyle.Italic);
                txtValue.ForeColor = Color.Gray;

                txtUnits.Text = "Units";
                txtUnits.Font = new Font(txtUnits.Font, FontStyle.Italic);
                txtUnits.ForeColor = Color.Gray;
            }
        }
        Dictionary<string, string> GetReplaceDictionary()
        {
            try
            {
                string strPName = txtPName.Text.Trim();
                string strAge = txtAge.Text.Trim();
                if (string.IsNullOrEmpty(strAge))
                    strAge = "0";
                strAge = strAge + "Y";
                string strAgeM = txtMonth.Text.Trim();
                string strAgeD = txtDays.Text.Trim();
                if (!string.IsNullOrEmpty(strAgeM))
                    strAge = strAge + ", " + strAgeM + "M";
                if (!string.IsNullOrEmpty(strAgeD))
                    strAge = strAge + ", " + strAgeD + "D";

                string strSex = cmbSex.Text.Trim();
                if (strSex == "Female")
                    strSex = "F";
                else if (strSex == "Male")
                    strSex = "M";
                else if (strSex == "Trans")
                    strSex = "TG";
                else
                    strSex = "";
                string pid = txtPID.Text.Trim();
                string labname = txtLabName.Text.Trim();
                string testdate = dtpTestDt.Text.Trim();
                string reportdata = txtData.Text.Trim() + Environment.NewLine;

                //string strDate = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"); // DateTime.Now.Day.ToString("D2") + "/" + DateTime.Now.Month.ToString("D2") + "/" + DateTime.Now.Year.ToString("D4");

                Dictionary<string, string> replaceDict = new Dictionary<string, string>();

                replaceDict.Add("#pname#", strPName + " ");
                replaceDict.Add("#age#", strAge + " ");
                replaceDict.Add("#sex#", strSex);

                replaceDict.Add("#pid#", pid + " ");
                replaceDict.Add("#labname#", labname + " ");
                replaceDict.Add("#testdate#", testdate);

                replaceDict.Add("#reportdata#", reportdata);

                return replaceDict;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("LabReports-GetReplaceDictionary()-->" + ex.Message);
                return null;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string pname = txtPName.Text.Trim();
                string strSex = cmbSex.Text.Trim();
                string labReportData = txtData.Text.Trim();

                if (string.IsNullOrEmpty(pname))
                {
                    MessageBox.Show("Please enter patient name.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (strSex == "- Select -")
                {
                    MessageBox.Show("Please select gender.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (string.IsNullOrEmpty(labReportData))
                {
                    MessageBox.Show("Please enter lab reports.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                string monthFolder = DateTime.Now.ToString("MMM") + "-" + DateTime.Now.Year.ToString("D4");

                if (!Directory.Exists(UncPath + "\\" + monthFolder))
                    Directory.CreateDirectory(UncPath + "\\" + monthFolder);

                string docxPath = UncPath + "\\" + monthFolder + "\\" + pname + "_" + DateTime.Now.Day.ToString("D2") + ".docx";
                
                //initialize word object
                document = new Document();
                //close if the template is already opened
                if (GloabalFunctions.closeOpenedWord(GloabalFunctions.LabReportsTemplatePath))
                    System.Threading.Thread.Sleep(100);
                document.LoadFromFile(GloabalFunctions.LabReportsTemplatePath);
                //get strings to replace
                Dictionary<string, string> dictReplace = GetReplaceDictionary();
                //Replace text
                foreach (KeyValuePair<string, string> kvp in dictReplace)
                {
                    document.Replace(kvp.Key, kvp.Value, true, true);
                }
                //Save doc file.

                if (File.Exists(docxPath))
                {
                    DialogResult res = MessageBox.Show("Patient lab report file already exists.\r\n" + "Click Yes to override No to save another file.", "GPApps :: PMS", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (res == DialogResult.Yes)
                    {
                        if (GloabalFunctions.closeOpenedWord(docxPath))
                            System.Threading.Thread.Sleep(100);

                        File.Delete(docxPath);
                    }
                    else if (res == DialogResult.No)
                    {
                        docxPath = UncPath + "\\" + pname + "_" + DateTime.Now.Day.ToString("D2") + "_1" + ".docx";
                        if (File.Exists(docxPath))
                        docxPath = UncPath + "\\" + pname + "_" + DateTime.Now.Day.ToString("D2") + "_2" + ".docx";
                        if (GloabalFunctions.closeOpenedWord(docxPath))
                            System.Threading.Thread.Sleep(100);
                    }
                    else
                        return;
                }

                document.SaveToFile(docxPath, FileFormat.Docx);
                document.Close();
                
                if (MessageBox.Show("Patient lab report data saved successfully. \r\n Do you want to give print?.", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    GloabalFunctions.printFile(docxPath);

                clearControls();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnLRSave_Click()-->" + ex.Message);
            }
        }
        private void clearControls()
        {
            //txtPName.Text = "";
            txtAge.Text = "";
            txtMonth.Text = "";
            txtDays.Text = "";
            cmbSex.SelectedIndex = 0;
            txtInvReq.Text = "";
            txtPID.Text = "";
            txtData.Text = "";
            txtLabName.Text = "";
            dtpTestDt.Text = DateTime.Now.Date.ToString();
            string searchOn = DateTime.Now.ToString("MMM") + "-" + DateTime.Now.Year.ToString("D4");
            getData(searchOn, "");

            txtValue.Text = "Value";
            txtValue.Font = new Font(txtValue.Font, FontStyle.Italic);
            txtValue.ForeColor = Color.Gray;

            txtUnits.Text = "Units";
            txtUnits.Font = new Font(txtUnits.Font, FontStyle.Italic);
            txtUnits.ForeColor = Color.Gray;


        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            clearControls();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1 || (sender as TextBox).Name == "txtAge"))
            {
                e.Handled = true;
            }
        }

        private void txtMonth_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                {
                    e.Handled = true;
                }

                //if (!string.IsNullOrEmpty(txtMonth.Text))
                //{
                //    string mm = txtMonth.Text.Trim() + "" + e.KeyChar.ToString();
                //    if (Convert.ToInt16(mm) > 11)
                //        e.Handled = true;
                //}
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        //private void txtChliDiagnosis_TextChanged(object sender, EventArgs e)
        //{
        //    if (!string.IsNullOrEmpty(txtChliDiagnosis.Text) && !Char.IsUpper(txtChliDiagnosis.Text, 0))
        //    {
        //        txtChliDiagnosis.Text = Char.ToUpper(txtChliDiagnosis.Text[0]) + txtChliDiagnosis.Text.Substring(1);
        //        txtChliDiagnosis.Select(txtChliDiagnosis.Text.Length, 1);
        //    }
        //}

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                GloabalFunctions.BrowseFileToPrint(UncPath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("Inv-Browse_Click()-->" + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                if (MessageBox.Show("Are you sure you want to delete?", "GPApps :: PMS", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.No)
                    return;
                if (File.Exists(filePath))
                {
                    GloabalFunctions.closeOpenedWord(filePath);
                    File.Delete(filePath);
                    string searchOn = dtpSearch.Text.Trim();
                    string searchText = txtSearch.Text.Trim().ToLower();
                    if (searchText == "enter patient name")
                        searchText = "";
                    getData(searchOn, searchText);
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnDelete_Click()-->" + ex.Message);
                MessageBox.Show(ex.Message, "GPApps :: PMS");
            }
        }
        
        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();

                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Patient file not exists at this location." + "\r\n" + filePath, "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                editPatientFile(filePath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnEdit_Click()-->" + ex.Message);
            }
        }
        private bool editPatientFile(string strFilePath)
        {
            bool retVal = false;
            try
            {
                //Create word document
                Document document = new Document();
                document.LoadFromFile(strFilePath);

                if (document.Sections.Count > 0)
                {
                    foreach (Section sec in document.Sections)
                    {
                        if (sec.Paragraphs.Count > 0)
                        {
                            string txtPara = "";
                            string strTemp = "";
                            string[] tempArr = new string[2];

                            //Getting patient name, age, add,...
                            foreach (Paragraph prgp in sec.Paragraphs)
                            {
                                txtPara = prgp.Text;
                                if (txtPara.Contains("Patient Name:"))
                                {
                                    tempArr = Regex.Split(txtPara, "Age:");
                                    txtPName.Text = tempArr[0].Replace("Patient Name:", "").Trim();
                                    strTemp = tempArr[1].Trim();
                                    tempArr = Regex.Split(strTemp, "Sex:");
                                    string age = tempArr[0].Trim();
                                    if (!string.IsNullOrEmpty(age) && age.Contains("M"))
                                    {
                                        txtAge.Text = age.Substring(0, age.IndexOf('Y'));
                                        string m = age.Substring(age.IndexOf('Y') + 2).Trim();
                                        txtMonth.Text = m.Substring(0, m.IndexOf('M')).Trim();
                                        if (m.Contains("D"))
                                            txtDays.Text = m.Substring(m.IndexOf('M') + 2).Replace("D", "").Trim();
                                    }
                                    else if (!age.Contains("M") && age.Contains("D"))
                                    {
                                        txtMonth.Text = "";
                                        txtAge.Text = age.Substring(0, age.IndexOf('Y'));
                                        txtDays.Text = age.Substring(age.IndexOf('Y') + 2).Replace("D", "").Trim();
                                    }
                                    else
                                    {
                                        txtAge.Text = age.Replace("Y", "").Trim();
                                        txtMonth.Text = "";
                                        txtDays.Text = "";
                                    }

                                    string sex = tempArr[1].Trim();
                                    if (sex.ToUpper() == "TRANS")
                                        cmbSex.SelectedIndex = 3;
                                    else if (sex.ToUpper() == "M")
                                        cmbSex.SelectedIndex = 2;
                                    else if (sex.ToUpper() == "F")
                                        cmbSex.SelectedIndex = 1;
                                    else
                                        cmbSex.SelectedIndex = 0;
                                }
                                else if (txtPara.Trim().Contains("PID:"))
                                {
                                    tempArr = Regex.Split(txtPara, "Lab Name:");
                                    txtPID.Text = tempArr[0].Trim().Replace("PID:", "").Trim();

                                    strTemp = tempArr[1].Trim();
                                    tempArr = Regex.Split(strTemp, "Test Date:");
                                    txtLabName.Text = tempArr[0].Trim();
                                    dtpTestDt.Value = ConvertDate(tempArr[1].Trim());
                                }
                            }
                        }
                        if (sec.Tables.Count > 0 && sec.Tables[0].Rows.Count > 0)
                        {
                            //Getting C/o & Rx details
                            StringBuilder sbCo = new StringBuilder();
                            StringBuilder sbRx = new StringBuilder();
                            Table table = sec.Tables[0] as Table;
                            if (table != null && table.Rows.Count > 0)
                            {
                                TableRow tr1 = table.Rows[1];
                                if (tr1 != null && tr1.Cells.Count > 0 && tr1.Cells.Count == 1)
                                {
                                    TableCell tc1 = tr1.Cells[0];
                                    if (tc1.Paragraphs.Count > 0)
                                    {
                                        foreach (Paragraph pr in tc1.Paragraphs)
                                        {
                                            string strTxt = pr.Text;
                                            sbCo.AppendLine(strTxt);
                                        }
                                        txtData.Text = Convert.ToString(sbCo);
                                    }
                                }
                            }
                        }
                    }
                }

                document.Close();
                retVal = true;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("editPatientFile()-->" + ex.Message);
                retVal = false;
            }
            return retVal;
        }
        public bool blConvertDate = true;
        public DateTime ConvertDate(string s)//Convert String to Date 
        {
            DateTime time = DateTime.Now;
            try
            {
                blConvertDate = true;
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
                DateTime time2 = Convert.ToDateTime(s);
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
                time = Convert.ToDateTime(time2);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("ConvertDate()-->" + ex.Message);
                blConvertDate = false;
            }
            return time;
        }
        private void btnOpen_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                GloabalFunctions.ToViewFile(filePath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnOpen_Click()-->" + ex.Message);
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count != 1)
                    return;
                string filePath = dgPatients.SelectedRows[0].Cells[1].Value.ToString().Trim();
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Patient file not exists at this location." + "\r\n" + filePath, "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                GloabalFunctions.printFile(filePath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnPrint_Click()-->" + ex.Message);
            }
        }

        private void btnClear2_Click(object sender, EventArgs e)
        {
            dtpSearch.Value = DateTime.Now.Date;
            dgPatients.ClearSelection();
            txtSearch.Text = "Enter Patient Name";
            txtSearch.Font = new Font(txtSearch.Font, FontStyle.Italic);
            txtSearch.ForeColor = Color.Gray;
            btnDelete.Enabled = false;
            btnPrint.Enabled = false;
            btnOpen.Enabled = false;
            btnEdit.Enabled = false;
            getData(dtpSearch.Text.Trim(), "");

        }

        private void dgPatients_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            dgPatients.ClearSelection();
            btnDelete.Enabled = false;
            btnPrint.Enabled = false;
            btnOpen.Enabled = false;
            btnEdit.Enabled = false;
        }

        private void dgPatients_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgPatients.SelectedRows.Count == 0)
                    return;
                btnDelete.Enabled = true;
                btnPrint.Enabled = true;
                btnOpen.Enabled = true;
                btnEdit.Enabled = true;
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("dgPatients_CellClick()-->" + ex.Message);
            }
        }
        private void dgPatients_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex > -1)
            {
                dgPatients.ClearSelection();
                dgPatients.Rows[e.RowIndex].Selected = true;
                btnDelete.Enabled = true;
                btnPrint.Enabled = true;
                btnOpen.Enabled = true;
                btnEdit.Enabled = true;
            }
        }

        private void dgPatients_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                btnOpen.PerformClick();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("dgPatients_CellDoubleClick()-->" + ex.Message);
            }
        }

        private void dgPatients_MouseDown(object sender, MouseEventArgs e)
        {
            //if (e.Button == MouseButtons.Right)
            //{
            //    DataGridView.HitTestInfo ht;
            //    ht = dgPatients.HitTest(e.X, e.Y);
            //    dgPatients.ContextMenuStrip = null;

            //    if (ht.Type == DataGridViewHitTestType.RowHeader || ht.Type == DataGridViewHitTestType.Cell)
            //        dgPatients.ContextMenuStrip = contextMenuStrip1;
            //}
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string searchOn = dtpSearch.Text;
                string searchText = txtSearch.Text.Trim().ToLower();
                if (searchText == "enter patient name")
                    searchText = "";
                    if (chkSearchAll.Checked && !string.IsNullOrEmpty(txtSearch.Text) && txtSearch.Text.Trim().ToLower() != "enter patient name")
                        searchOn = "";
                    getData(searchOn, searchText);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("btnSearch_Click()-->" + ex.Message);
            }
        }

        private void chkSearchAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtSearch.Text) && txtSearch.Text.Trim().ToLower() != "enter patient name")
                {
                    btnSearch.PerformClick();
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("chkSearchAll_CheckedChanged()-->" + ex.Message);
            }
        }
    }
}
