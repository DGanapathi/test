﻿using Spire.Doc;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PMSApp
{
    public partial class frmEmail : Form
    {
        public frmEmail()
        {
            InitializeComponent();
        }

        private void frmEmail_Load(object sender, EventArgs e)
        {
            try
            {
                txtPName.Text = frmHome.patientNameForMail.ToUpper();
                if (frmHome.emailCollForNotification != null && frmHome.emailCollForNotification.Count > 0)
                {
                    txtEmail.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtEmail.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtEmail.AutoCompleteCustomSource = frmHome.emailCollForNotification;
                }
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("frmEmail_Load()-->" + ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEmail_Click(object sender, EventArgs e)
        {
            try
            {
                string strEmail = txtEmail.Text.Trim();
                string strPName = txtPName.Text.Trim();
                string docxPath = frmHome.filepathForMail;
                if (string.IsNullOrEmpty(strEmail))
                {
                    MessageBox.Show("Please enter valid Email ID.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (!GloabalFunctions.isValidMail(strEmail))
                {
                    MessageBox.Show("Please enter valid Email ID.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                string pdfPath = docxPath.Replace(".docx", ".pdf");
                if (File.Exists(pdfPath))
                {
                    File.Delete(pdfPath);
                    System.Threading.Thread.Sleep(500);
                }
                //Load Document
                Document document = new Document();
                document.LoadFromFile(docxPath);

                //Convert Word to PDF
                document.SaveToFile(pdfPath, FileFormat.PDF);

                document.Close();

                EmailNotification.eMailNotification(strPName, strEmail, pdfPath);
                MessageBox.Show("Mail sent successfully.", "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //System.Threading.Thread.Sleep(100);
                if (File.Exists(pdfPath))
                    File.Delete(pdfPath);
                this.Close();
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("frmEmail_btnEmail_Click()-->" + ex.Message);
                MessageBox.Show("Mail sending faild: " + ex.Message, "GPApps :: PMS", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                string UncPath = Directory.GetParent(System.Configuration.ConfigurationManager.AppSettings["FilesPath"]).ToString();
                string strToDay = DateTime.Now.Day.ToString("D2") + "-" + DateTime.Now.Month.ToString("D2") + "-" + DateTime.Now.Year.ToString("D4");
                UncPath = UncPath + +Path.DirectorySeparatorChar + strToDay;
                GloabalFunctions.BrowseFileToPrint(UncPath);
            }
            catch (Exception ex)
            {
                GloabalFunctions.WriteLog("PFC-Browse_Click()-->" + ex.Message);
            }
        }
    }
}
